"""
캐릭터 정의 모듈
각 캐릭터의 스탯-시작 무기-특성을 정의합니다.
"""

# -- 캐릭터 정의 ------------------------------------------
# apply(player) 함수: 게임 시작 직후 Player 인스턴스에 적용
CHARACTERS = [
    {
        'id':     'vega',
        'name':   'VEGA',
        'title':  '파일럿',
        'desc':   '균형 잡힌 표준 파일럿.\n모든 상황에 대응 가능.',
        'traits': [
            'PERFECT 배율 +30% (2.3배)',
            '발사: PulseShot',
            '콤보 부스트 내장',
        ],
        # 스탯 바 표시용 (0.0~1.0)
        'stat_hp':     0.60,
        'stat_spd':    0.55,
        'stat_atk':    0.55,
        'stat_spec':   0.65,
        'stat_labels': ['HP', '속도', '공격', '특수'],
        # 실제 적용 함수
        'apply': lambda p: _apply_vega(p),
        # 색상 테마
        'color':        (100, 180, 255),
        'color_dark':   (30,  60, 110),
        'color_border': (80, 150, 220),
        # 심볼 (게임 내 그림 대신 텍스트 심볼로 표현)
        'symbol': 'V',
    },
    {
        'id':    'nova',
        'name':  'NOVA',
        'title': '레이더',
        'desc':  '극한의 화력을 추구하는\n공격형 파일럿.',
        'traits': [
            'HP -30%  데미지 +40%',
            '발사: 산탄(Spread)',
            '크리티컬 확률 2배',
        ],
        'stat_hp':     0.30,
        'stat_spd':    0.65,
        'stat_atk':    0.90,
        'stat_spec':   0.70,
        'stat_labels': ['HP', '속도', '공격', '특수'],
        'apply': lambda p: _apply_nova(p),
        'color':        (255, 120,  60),
        'color_dark':   (100,  30,  10),
        'color_border': (220,  90,  40),
        'symbol': 'N',
    },
    {
        'id':    'aegis',
        'name':  'AEGIS',
        'title': '수호자',
        'desc':  '두꺼운 장갑과 방어막으로\n버텨내는 방어형 파일럿.',
        'traits': [
            'HP +60%  속도 -20%',
            '발사: Homing',
            '쉴드 자동 재생 내장',
        ],
        'stat_hp':     0.95,
        'stat_spd':    0.35,
        'stat_atk':    0.40,
        'stat_spec':   0.60,
        'stat_labels': ['HP', '속도', '공격', '특수'],
        'apply': lambda p: _apply_aegis(p),
        'color':        (80, 220, 140),
        'color_dark':   (15,  70,  40),
        'color_border': (60, 180, 110),
        'symbol': 'A',
    },
]


def get_character(cid: str) -> dict:
    for c in CHARACTERS:
        if c['id'] == cid:
            return c
    return CHARACTERS[0]


# -- 캐릭터별 apply 함수 ----------------------------------
def _apply_vega(player):
    """균형형 - 기본 스탯, PERFECT 배율 소폭 강화"""
    from weapon import create_weapon
    player.weapons     = [create_weapon('pulse')]
    player.weapon_types = {'pulse'}
    # PERFECT 피해 배율을 내부 보정치로 저장 (rhythm 엔진이 읽음)
    player._char_perfect_bonus = 0.10   # PERFECT 데미지 +10%
    player._char_id = 'vega'


def _apply_nova(player):
    """공격형 - HP 낮음, 데미지-크리 강화, Spread 시작"""
    from settings import PLAYER_HP
    from weapon import create_weapon
    player.max_hp      = int(PLAYER_HP * 0.70)
    player.hp          = player.max_hp
    player.damage_mult = 1.40
    player.crit_chance = 0.10        # 기본 0.05 -> 2배
    player.crit_mult   = 2.5         # 크리 배율 강화
    player.weapons      = [create_weapon('spread')]
    player.weapon_types = {'spread'}
    player._char_id = 'nova'


def _apply_aegis(player):
    """방어형 - HP 높음, 속도 낮음, Homing 시작, 쉴드 리젠"""
    from settings import PLAYER_HP, PLAYER_SPEED
    from weapon import create_weapon
    player.max_hp      = int(PLAYER_HP * 1.60)
    player.hp          = player.max_hp
    player.speed       = PLAYER_SPEED * 0.80
    player.shield_regen = True
    player.weapons      = [create_weapon('homing')]
    player.weapon_types = {'homing'}
    player._char_id = 'aegis'
