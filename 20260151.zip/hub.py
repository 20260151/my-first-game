"""
hub.py - PULSE DRIVE 허브 월드 (격납고)
Hades의 Crossroads처럼 런 사이에 자유롭게 돌아다니며
강화하고 캐릭터를 선택한 뒤 출격하는 공간
"""

import os
import pygame
import math
from settings import *

# -----------------------------------------------------
# 거울 강화 (영구 패시브) 정의
# -----------------------------------------------------
MIRROR_UPGRADES = [
    {
        'id':        'mirror_hp',
        'name':      '강화 장갑',
        'icon':      'HP',
        'desc':      '런 시작 시 최대 HP +{val}',
        'max_level': 5,
        'costs':     [10, 20, 35, 55, 80],
        'values':    [10, 10, 15, 15, 20],
        'color':     (220, 80, 80),
    },
    {
        'id':        'mirror_reroll',
        'name':      '선행 보급',
        'icon':      'RR',
        'desc':      '런 시작 시 재굴림 횟수 +{val}',
        'max_level': 3,
        'costs':     [15, 30, 50],
        'values':    [1, 1, 1],
        'color':     (100, 180, 255),
    },
    {
        'id':        'mirror_crit',
        'name':      '정밀 조준',
        'icon':      'CR',
        'desc':      '크리티컬 확률 +{val}%',
        'max_level': 4,
        'costs':     [12, 25, 40, 60],
        'values':    [2, 2, 3, 3],
        'color':     (255, 220, 60),
    },
    {
        'id':        'mirror_exp',
        'name':      '전투 경험',
        'icon':      'XP',
        'desc':      'EXP 획득량 +{val}%',
        'max_level': 3,
        'costs':     [20, 40, 65],
        'values':    [10, 10, 15],
        'color':     (80, 220, 120),
    },
    {
        'id':        'mirror_boss_dmg',
        'name':      '대형 파괴자',
        'icon':      'BD',
        'desc':      '보스 상대 데미지 +{val}%',
        'max_level': 4,
        'costs':     [25, 45, 70, 100],
        'values':    [5, 5, 8, 7],
        'color':     (200, 100, 255),
    },
]
MIRROR_BY_ID = {u['id']: u for u in MIRROR_UPGRADES}

def get_mirror_total_value(uid, level):
    u = MIRROR_BY_ID.get(uid)
    if not u or level <= 0:
        return 0
    return sum(u['values'][:level])

def apply_mirror_upgrades(player, mirror_upgrades: dict, upgrade_menu):
    """런 시작 시 영구 업그레이드 전체 적용"""
    # HP
    lv = mirror_upgrades.get('mirror_hp', 0)
    if lv > 0:
        val = get_mirror_total_value('mirror_hp', lv)
        player.max_hp += val
        player.hp      = player.max_hp
    # 재굴림
    lv = mirror_upgrades.get('mirror_reroll', 0)
    bonus_reroll = get_mirror_total_value('mirror_reroll', lv)
    upgrade_menu.reset(rerolls=2 + bonus_reroll)
    # 크리티컬
    lv = mirror_upgrades.get('mirror_crit', 0)
    if lv > 0:
        val = get_mirror_total_value('mirror_crit', lv)
        player.crit_chance += val / 100
    # EXP
    lv = mirror_upgrades.get('mirror_exp', 0)
    if lv > 0:
        val = get_mirror_total_value('mirror_exp', lv)
        player.exp_mult *= (1 + val / 100)
    # 보스 데미지 (런타임에 참조할 속성)
    lv = mirror_upgrades.get('mirror_boss_dmg', 0)
    if lv > 0:
        val = get_mirror_total_value('mirror_boss_dmg', lv)
        player._boss_dmg_bonus = val / 100
    else:
        player._boss_dmg_bonus = 0.0


# -----------------------------------------------------
# HubPlayer - 허브 안에서 걸어다니는 플레이어 아바타
# -----------------------------------------------------
class HubPlayer:
    """
    허브 월드 플레이어 - AnimationSheet.png 스프라이트 기반
    +---------------------------------------+
    |  스프라이트 시트 구조 (24x24px, 8열x6행)  |
    |  Row 0 : 걷기 DOWN  (0~7)            |
    |  Row 1 : 걷기 LEFT  (0~7)            |
    |  Row 2 : 걷기 RIGHT (0~7)            |
    |  Row 3 : 걷기 UP    (0~7)            |
    |  Row 4 : 구르기 Roll (0~7)           |
    |  Row 5 : 대기 Idle  (0~1)            |
    +---------------------------------------+
    """

    # -- 스프라이트 파일 정보 --------------------------
    SHEET_PATH  = 'hub_player.png'   # assets/ 하위
    FRAME_W     = 24                 # 원본 프레임 가로
    FRAME_H     = 24                 # 원본 프레임 세로
    SHEET_COLS  = 8
    RENDER_SCALE = 3                 # 72x72px 으로 확대

    # -- 애니메이션 행 번호 ----------------------------
    ROW_DOWN  = 0
    ROW_LEFT  = 1
    ROW_RIGHT = 2
    ROW_UP    = 3
    ROW_ROLL  = 4
    ROW_IDLE  = 5

    # -- 애니메이션별 프레임 수 ------------------------
    WALK_FRAMES = 8
    ROLL_FRAMES = 8   # row4 전체
    IDLE_FRAMES = 2

    # -- 속도 -----------------------------------------
    WALK_SPEED = sx(3)
    ROLL_SPEED = sx(6)     # 구르기는 빠르게

    # -- 애니메이션 속도 (프레임 당 틱 수) ---------------
    WALK_TICK = 5    # 5틱마다 다음 스프라이트
    ROLL_TICK = 4
    IDLE_TICK = 25

    # -- 충돌 박스 (렌더 크기 기준) --------------------
    @property
    def W(self): return self.FRAME_W * self.RENDER_SCALE
    @property
    def H(self): return self.FRAME_H * self.RENDER_SCALE

    # -------------------------------------------------
    _sheet_cache = {}   # 클래스 레벨 캐시 (pygame init 후 한 번만 로드)
    _shadow_cache = {}

    def __init__(self, x, y):
        self.x = float(x)
        self.y = float(y)

        # 방향: 'down' | 'left' | 'right' | 'up'
        self._dir   = 'down'
        # 상태: 'idle' | 'walk' | 'roll'
        self._state = 'idle'

        self._frame_idx  = 0    # 현재 애니 프레임 인덱스
        self._tick       = 0    # 틱 카운터
        self._roll_ticks = 0    # 구르기 남은 틱

        self._frames = {}       # {(row, col): Surface}
        self._loaded = False

    # -- 스프라이트 로드 -------------------------------
    def _load_sprites(self):
        """최초 draw/update 시 한 번만 호출"""
        if self._loaded:
            return
        key = self.SHEET_PATH
        if key not in HubPlayer._sheet_cache:
            path = os.path.join(ASSETS_DIR, self.SHEET_PATH)
            try:
                # RGBA PNG -> convert_alpha()로 투명도 유지
                sheet = pygame.image.load(path).convert_alpha()
            except Exception as e:
                print(f'[HubPlayer] 스프라이트 로드 실패: {e}')
                sheet = None
            HubPlayer._sheet_cache[key] = sheet

        sheet = HubPlayer._sheet_cache[key]
        if sheet is None:
            self._loaded = True
            return

        fw, fh = self.FRAME_W, self.FRAME_H
        scale  = self.RENDER_SCALE

        for row in range(6):
            cols = self.IDLE_FRAMES if row == 5 else self.SHEET_COLS
            for col in range(cols):
                # RGBA 시트에서 프레임 잘라내기 (alpha 채널 그대로 사용)
                frame_surf = pygame.Surface((fw, fh), pygame.SRCALPHA)
                frame_surf.fill((0, 0, 0, 0))
                frame_surf.blit(sheet, (0, 0),
                                area=(col * fw, row * fh, fw, fh))

                # 픽셀아트 선명하게 확대
                scaled = pygame.transform.scale(
                    frame_surf,
                    (fw * scale, fh * scale)
                )
                self._frames[(row, col)] = scaled

        self._loaded = True

    # -- 현재 프레임 Surface 반환 ----------------------
    def _current_surface(self):
        if self._state == 'idle':
            row = self.ROW_DOWN
            col = self._frame_idx % self.IDLE_FRAMES
        elif self._state == 'roll':
            row = self.ROW_ROLL
            col = self._frame_idx % self.ROLL_FRAMES
        else:  # walk
            row = {
                'down' : self.ROW_DOWN,
                'left' : self.ROW_LEFT,
                'right': self.ROW_RIGHT,
                'up'   : self.ROW_UP,
            }[self._dir]
            col = self._frame_idx % self.WALK_FRAMES

        return self._frames.get((row, col))

    # -- 충돌 rect ------------------------------------

    @classmethod
    def _get_shadow_surface(cls):
        key = (ss(56), ss(14))
        surf = cls._shadow_cache.get(key)
        if surf is None:
            surf = pygame.Surface(key, pygame.SRCALPHA)
            pygame.draw.ellipse(surf, (0, 0, 0, 60), (0, 0, key[0], key[1]))
            cls._shadow_cache[key] = surf
        return surf

    @classmethod
    def _get_glow_surface(cls, color, radius):
        key = (color, radius)
        surf = cls._glow_cache.get(key)
        if surf is None:
            surf = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
            pygame.draw.circle(surf, (*color, 70), (radius, radius), radius)
            cls._glow_cache[key] = surf
        return surf

    @classmethod
    def _get_text_surface(cls, font, text, color):
        key = (id(font), text, color)
        surf = cls._text_cache.get(key)
        if surf is None:
            surf = font.render(text, True, color)
            cls._text_cache[key] = surf
        return surf

    @classmethod
    def _get_bubble_surface(cls, size, border_color):
        key = (size[0], size[1], border_color)
        surf = cls._bubble_cache.get(key)
        if surf is None:
            surf = pygame.Surface(size, pygame.SRCALPHA)
            surf.fill((20, 20, 40, 210))
            pygame.draw.rect(surf, border_color,
                             (0, 0, size[0], size[1]), 1, border_radius=ss(6))
            cls._bubble_cache[key] = surf
        return surf

    @property
    def rect(self):
        w, h = self.W, self.H
        return pygame.Rect(int(self.x) - w // 2,
                           int(self.y) - h // 2,
                           w, h)

    # -- 업데이트 -------------------------------------
    def update(self, keys, can_walk, world_rect):
        self._load_sprites()

        shift = keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]

        # -- 구르기 상태 처리 --------------------------
        if self._state == 'roll':
            self._roll_ticks -= 1
            self._tick += 1
            if self._tick >= self.ROLL_TICK:
                self._tick = 0
                self._frame_idx += 1

            # 구르기 중 이동 (현재 방향으로 빠르게)
            dx, dy = {
                'right': ( 1,  0),
                'left' : (-1,  0),
                'down' : ( 0,  1),
                'up'   : ( 0, -1),
            }[self._dir]
            self._move(dx, dy, self.ROLL_SPEED, can_walk, world_rect)

            # 구르기 종료
            if self._roll_ticks <= 0:
                self._state     = 'idle'
                self._frame_idx = 0
                self._tick      = 0
            return

        # -- 이동 입력 읽기 ----------------------------
        dx = dy = 0.0
        if keys[pygame.K_LEFT]  or keys[pygame.K_a]: dx -= 1
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]: dx += 1
        if keys[pygame.K_UP]    or keys[pygame.K_w]: dy -= 1
        if keys[pygame.K_DOWN]  or keys[pygame.K_s]: dy += 1

        moving = bool(dx or dy)

        # -- 방향 업데이트 (8방향 중 우선순위: 좌우 > 상하) -
        if   dx > 0: self._dir = 'right'
        elif dx < 0: self._dir = 'left'
        elif dy > 0: self._dir = 'down'
        elif dy < 0: self._dir = 'up'

        # -- Shift + 이동 -> 구르기 시작 ----------------
        if shift and moving:
            self._state      = 'roll'
            self._frame_idx  = 0
            self._tick       = 0
            self._roll_ticks = self.ROLL_FRAMES * self.ROLL_TICK
            return

        # -- 대각선 정규화 -----------------------------
        if dx != 0 and dy != 0:
            dx *= 0.707
            dy *= 0.707

        # -- 실제 이동 ---------------------------------
        if moving:
            self._move(dx, dy, self.WALK_SPEED, can_walk, world_rect)
            self._state = 'walk'
            self._tick += 1
            if self._tick >= self.WALK_TICK:
                self._tick = 0
                self._frame_idx = (self._frame_idx + 1) % self.WALK_FRAMES
        else:
            self._state = 'idle'
            self._tick += 1
            if self._tick >= self.IDLE_TICK:
                self._tick = 0
                self._frame_idx = (self._frame_idx + 1) % self.IDLE_FRAMES

    def _move(self, dx, dy, speed, can_walk, world_rect):
        w, h = self.W, self.H
        nx = max(world_rect.left  + w // 2,
                 min(world_rect.right  - w // 2, self.x + dx * speed))
        if can_walk(nx, self.y, w, h):
            self.x = nx

        ny = max(world_rect.top   + h // 2,
                 min(world_rect.bottom - h // 2, self.y + dy * speed))
        if can_walk(self.x, ny, w, h):
            self.y = ny

    # -- 그리기 ---------------------------------------
    def draw(self, surf, screen_x, screen_y, char_color=None):
        """char_color 인수는 하위 호환성 유지용 (미사용)"""
        self._load_sprites()

        frame = self._current_surface()
        if frame is None:
            # 스프라이트 없을 때 폴백: 흰 사각형
            pygame.draw.rect(surf, (200, 200, 220),
                             (int(screen_x) - self.W // 2,
                              int(screen_y) - self.H // 2,
                              self.W, self.H))
            return

        w, h = frame.get_size()
        # 그림자 (크기별 캐시 재사용)
        shadow_key = (w, max(4, h // 8))
        shad = self._shadow_cache.get(shadow_key)
        if shad is None:
            shad = pygame.Surface(shadow_key, pygame.SRCALPHA)
            pygame.draw.ellipse(shad, (0, 0, 0, 50),
                                (0, 0, shadow_key[0], shadow_key[1]))
            self._shadow_cache[shadow_key] = shad
        surf.blit(shad, (int(screen_x) - w // 2,
                         int(screen_y) + h // 2 - shad.get_height() // 2))

        # 구르기 중 반투명 잔상 효과
        if self._state == 'roll':
            ghost = frame.copy()
            ghost.set_alpha(80)
            offset = ss(8)
            dx_off, dy_off = {
                'right': (-offset, 0), 'left': (offset, 0),
                'down' : (0, -offset), 'up'  : (0, offset),
            }[self._dir]
            surf.blit(ghost,
                      (int(screen_x) - w // 2 + dx_off,
                       int(screen_y) - h // 2 + dy_off))

        # 메인 스프라이트
        surf.blit(frame,
                  (int(screen_x) - w // 2,
                   int(screen_y) - h // 2))


# -----------------------------------------------------
# HubNPC - 허브 내 NPC 캐릭터 (기존 HubStation 대체)
# -----------------------------------------------------
class HubNPC:
    """
    오브젝트 대신 NPC 캐릭터가 서서 상호작용하는 지점.
    업로드된 NPC 스프라이트 시트를 각 허브 NPC와 1:1로 연결해 사용한다.
    시트 형태가 제각각이어서 알파 영역을 기반으로 프레임을 자동 추출한다.
    """
    INTERACT_DIST = ss(110)

    NPC_SPRITES = {
        'launch':  dict(file='hub_npc_launch.png',  scale=3.0, y_offset=0),
        'mirror':  dict(file='hub_npc_mirror.png',  scale=3.0, y_offset=0),
        'history': dict(file='hub_npc_history.png', scale=2.4, y_offset=0),
        'options': dict(file='hub_npc_options.png', scale=3.0, y_offset=0, layout='vertical_strip', frame_count=9),
        'main':    dict(file='hub_npc_main.png',    scale=3.2, y_offset=0),
    }
    _sprite_cache = {}
    _shadow_cache = {}
    _glow_cache = {}
    _text_cache = {}
    _bubble_cache = {}

    # NPC별 시각 스타일 정의
    NPC_STYLES = {
        'launch':  dict(body=(80, 220, 140),  head=(140, 255, 180), label_color=(80, 255, 140),  symbol='E', title_line='출격 담당관'),
        'mirror':  dict(body=(100, 140, 255), head=(160, 180, 255), label_color=(160, 200, 255), symbol='M', title_line='강화 기술자'),
        'history': dict(body=(80,  200, 100), head=(120, 240, 140), label_color=(80,  220, 120), symbol='L', title_line='기록 보관관'),
        'options': dict(body=(180, 140, 80),  head=(230, 190, 120), label_color=(220, 180, 100), symbol='O', title_line='시스템 관리자'),
        'main':    dict(body=(160, 80,  80),  head=(220, 120, 120), label_color=(200, 100, 100), symbol='Q', title_line='귀환 담당관'),
    }

    # NPC 대사 (근접시 말풍선)
    NPC_DIALOGUES = {
        'launch':  "준비됐나요? 출격합니다!",
        'mirror':  "강화 항목을 선택하세요.",
        'history': "지난 기록을 확인하세요.",
        'options': "설정을 변경할 수 있어요.",
        'main':    "메인 메뉴로 돌아갑니다.",
    }

    def __init__(self, x, y, name, key, color, icon, desc):
        self.x    = x
        self.y    = y
        self.name = name
        self.key  = key
        self.color= color
        self.icon = icon
        self.desc = desc
        self._pulse    = 0.0
        self._bob      = 0.0   # 상하 흔들림 오프셋
        self._bob_dir  = 1
        self._sheet    = None
        self._frames   = []
        self._frame_idx= 0
        self._anim_tick= 0
        self._loaded   = False

    @staticmethod
    def _alpha_groups(axis_values, min_len=2):
        groups = []
        start = None
        for i, has_alpha in enumerate(axis_values):
            if has_alpha and start is None:
                start = i
            elif not has_alpha and start is not None:
                if i - start >= min_len:
                    groups.append((start, i - 1))
                start = None
        if start is not None and len(axis_values) - start >= min_len:
            groups.append((start, len(axis_values) - 1))
        return groups

    @classmethod
    def _extract_frames_from_layout(cls, sheet, *, scale=3.0, layout=None, frame_count=None):
        if layout not in ('vertical_strip', 'horizontal_strip') or not frame_count or frame_count < 2:
            return None

        w, h = sheet.get_size()
        frames = []

        if layout == 'vertical_strip':
            cell_h = h / frame_count
            for i in range(frame_count):
                y0 = int(round(i * cell_h))
                y1 = int(round((i + 1) * cell_h))
                if y1 <= y0:
                    continue
                bbox = None
                for yy in range(y0, y1):
                    for xx in range(w):
                        if sheet.get_at((xx, yy))[3] > 20:
                            if bbox is None:
                                bbox = [xx, yy, xx, yy]
                            else:
                                bbox[0] = min(bbox[0], xx)
                                bbox[1] = min(bbox[1], yy)
                                bbox[2] = max(bbox[2], xx)
                                bbox[3] = max(bbox[3], yy)
                if bbox is not None:
                    x0, yy0, x1, yy1 = bbox
                    frame = pygame.Surface((x1 - x0 + 3, yy1 - yy0 + 3), pygame.SRCALPHA)
                    frame.blit(sheet, (1 - x0, 1 - yy0))
                    frames.append(frame)
        else:
            cell_w = w / frame_count
            for i in range(frame_count):
                x0 = int(round(i * cell_w))
                x1 = int(round((i + 1) * cell_w))
                if x1 <= x0:
                    continue
                bbox = None
                for xx in range(x0, x1):
                    for yy in range(h):
                        if sheet.get_at((xx, yy))[3] > 20:
                            if bbox is None:
                                bbox = [xx, yy, xx, yy]
                            else:
                                bbox[0] = min(bbox[0], xx)
                                bbox[1] = min(bbox[1], yy)
                                bbox[2] = max(bbox[2], xx)
                                bbox[3] = max(bbox[3], yy)
                if bbox is not None:
                    xx0, y0, xx1, y1 = bbox
                    frame = pygame.Surface((xx1 - xx0 + 3, y1 - y0 + 3), pygame.SRCALPHA)
                    frame.blit(sheet, (1 - xx0, 1 - y0))
                    frames.append(frame)

        if not frames:
            return None

        scaled_frames = []
        for frame in frames:
            fw, fh = frame.get_size()
            scaled_frames.append(pygame.transform.scale(frame, (max(1, int(fw * scale)), max(1, int(fh * scale)))))
        return scaled_frames

    @classmethod
    def _extract_frames_from_sheet(cls, sheet, scale=3.0):
        w, h = sheet.get_size()
        alpha_cols = []
        alpha_rows = []
        for x in range(w):
            has_alpha = False
            for y in range(h):
                if sheet.get_at((x, y))[3] > 20:
                    has_alpha = True
                    break
            alpha_cols.append(has_alpha)
        for y in range(h):
            has_alpha = False
            for x in range(w):
                if sheet.get_at((x, y))[3] > 20:
                    has_alpha = True
                    break
            alpha_rows.append(has_alpha)

        col_groups = cls._alpha_groups(alpha_cols, min_len=2)
        row_groups = cls._alpha_groups(alpha_rows, min_len=2)
        frames = []

        # 가장 자연스러운 방향으로 셀 구성
        if len(row_groups) >= 2 and len(col_groups) >= 2:
            # 격자형 시트: 각 칸에서 실제 알파 bbox를 다시 타이트하게 추출
            for ry0, ry1 in row_groups:
                for cx0, cx1 in col_groups:
                    bbox = None
                    for yy in range(ry0, ry1 + 1):
                        for xx in range(cx0, cx1 + 1):
                            if sheet.get_at((xx, yy))[3] > 20:
                                if bbox is None:
                                    bbox = [xx, yy, xx, yy]
                                else:
                                    bbox[0] = min(bbox[0], xx)
                                    bbox[1] = min(bbox[1], yy)
                                    bbox[2] = max(bbox[2], xx)
                                    bbox[3] = max(bbox[3], yy)
                    if bbox is not None:
                        x0, y0, x1, y1 = bbox
                        frame = pygame.Surface((x1 - x0 + 3, y1 - y0 + 3), pygame.SRCALPHA)
                        frame.blit(sheet, (1 - x0, 1 - y0))
                        frames.append(frame)
        elif len(row_groups) >= 2:
            for ry0, ry1 in row_groups:
                bbox = None
                for yy in range(ry0, ry1 + 1):
                    for xx in range(w):
                        if sheet.get_at((xx, yy))[3] > 20:
                            if bbox is None:
                                bbox = [xx, yy, xx, yy]
                            else:
                                bbox[0] = min(bbox[0], xx)
                                bbox[1] = min(bbox[1], yy)
                                bbox[2] = max(bbox[2], xx)
                                bbox[3] = max(bbox[3], yy)
                if bbox is not None:
                    x0, y0, x1, y1 = bbox
                    frame = pygame.Surface((x1 - x0 + 3, y1 - y0 + 3), pygame.SRCALPHA)
                    frame.blit(sheet, (1 - x0, 1 - y0))
                    frames.append(frame)
        elif len(col_groups) >= 2:
            for cx0, cx1 in col_groups:
                bbox = None
                for xx in range(cx0, cx1 + 1):
                    for yy in range(h):
                        if sheet.get_at((xx, yy))[3] > 20:
                            if bbox is None:
                                bbox = [xx, yy, xx, yy]
                            else:
                                bbox[0] = min(bbox[0], xx)
                                bbox[1] = min(bbox[1], yy)
                                bbox[2] = max(bbox[2], xx)
                                bbox[3] = max(bbox[3], yy)
                if bbox is not None:
                    x0, y0, x1, y1 = bbox
                    frame = pygame.Surface((x1 - x0 + 3, y1 - y0 + 3), pygame.SRCALPHA)
                    frame.blit(sheet, (1 - x0, 1 - y0))
                    frames.append(frame)

        if not frames:
            frames = [sheet.copy()]

        scaled_frames = []
        for frame in frames:
            fw, fh = frame.get_size()
            scaled_frames.append(pygame.transform.scale(frame, (max(1, int(fw * scale)), max(1, int(fh * scale)))))
        return scaled_frames

    # -- 스프라이트 로드 (업로드된 NPC 시트 사용) --------
    def _load_sprites(self):
        if self._loaded:
            return

        cfg = self.NPC_SPRITES.get(self.key, {})
        filename = cfg.get('file')
        cache_key = (self.key, filename, cfg.get('scale', 3.0))
        cached = self._sprite_cache.get(cache_key)
        if cached is not None:
            self._frames = cached
            self._loaded = True
            return

        frames = []
        if filename:
            path = os.path.join(ASSETS_DIR, filename)
            try:
                sheet = pygame.image.load(path).convert_alpha()
                self._sheet = sheet
                frames = self._extract_frames_from_layout(
                    sheet,
                    scale=cfg.get('scale', 3.0),
                    layout=cfg.get('layout'),
                    frame_count=cfg.get('frame_count'),
                )
                if not frames:
                    frames = self._extract_frames_from_sheet(sheet, scale=cfg.get('scale', 3.0))
            except Exception as e:
                print(f'[HubNPC] 스프라이트 로드 실패({self.key}): {e}')

        self._frames = frames
        self._sprite_cache[cache_key] = frames
        self._loaded = True


    @classmethod
    def _get_shadow_surface(cls):
        key = (ss(56), ss(14))
        surf = cls._shadow_cache.get(key)
        if surf is None:
            surf = pygame.Surface(key, pygame.SRCALPHA)
            pygame.draw.ellipse(surf, (0, 0, 0, 60), (0, 0, key[0], key[1]))
            cls._shadow_cache[key] = surf
        return surf

    @classmethod
    def _get_glow_surface(cls, color, radius):
        key = (color, radius)
        surf = cls._glow_cache.get(key)
        if surf is None:
            surf = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
            pygame.draw.circle(surf, (*color, 70), (radius, radius), radius)
            cls._glow_cache[key] = surf
        return surf

    @classmethod
    def _get_text_surface(cls, font, text, color):
        key = (id(font), text, color)
        surf = cls._text_cache.get(key)
        if surf is None:
            surf = font.render(text, True, color)
            cls._text_cache[key] = surf
        return surf

    @classmethod
    def _get_bubble_surface(cls, size, border_color):
        key = (size[0], size[1], border_color)
        surf = cls._bubble_cache.get(key)
        if surf is None:
            surf = pygame.Surface(size, pygame.SRCALPHA)
            surf.fill((20, 20, 40, 210))
            pygame.draw.rect(surf, border_color,
                             (0, 0, size[0], size[1]), 1, border_radius=ss(6))
            cls._bubble_cache[key] = surf
        return surf

    @property
    def rect(self):
        s = ss(60)
        return pygame.Rect(int(self.x) - s//2, int(self.y) - s//2, s, s)

    def in_range(self, player: HubPlayer) -> bool:
        return math.hypot(player.x - self.x, player.y - self.y) < self.INTERACT_DIST

    def update(self):
        self._pulse = (self._pulse + 0.05) % (math.pi * 2)
        # 상하 bob
        self._bob += 0.04 * self._bob_dir
        if abs(self._bob) > 3:
            self._bob_dir *= -1
        # 애니 틱
        self._anim_tick += 1
        if self._anim_tick >= HubPlayer.IDLE_TICK:
            self._anim_tick = 0
            if self._frames:
                self._frame_idx = (self._frame_idx + 1) % len(self._frames)
            else:
                self._frame_idx = (self._frame_idx + 1) % HubPlayer.IDLE_FRAMES

    def draw(self, surf, near: bool, font_big, font_sm, camera=(0, 0)):
        self._load_sprites()
        cx = int(self.x - camera[0])
        cy = int(self.y - camera[1]) + int(self._bob)

        style = self.NPC_STYLES.get(self.key, {})
        label_col = style.get('label_color', self.color)

        # -- 지면 그림자 --------------------------------
        shad_s = self._get_shadow_surface()
        surf.blit(shad_s, (cx - shad_s.get_width()//2, cy + ss(34)))

        # -- NPC 스프라이트 or 폴백 폴리곤 ----------------
        frame = None
        if self._frames:
            frame = self._frames[self._frame_idx % len(self._frames)]
            fw = frame.get_width()
            fh = frame.get_height()
            y_offset = int(self.NPC_SPRITES.get(self.key, {}).get('y_offset', 0))
            surf.blit(frame, (cx - fw//2, cy - fh//2 + y_offset))
        else:
            # 폴백: 단순 사람 모양
            body_c = style.get('body', self.color)
            head_c = style.get('head', (220, 220, 220))
            head_r = ss(14)
            body_w = ss(22)
            body_h = ss(30)
            pygame.draw.circle(surf, head_c, (cx, cy - body_h//2 - head_r), head_r)
            pygame.draw.rect(surf, body_c,
                             (cx - body_w//2, cy - body_h//2, body_w, body_h),
                             border_radius=ss(4))

        # -- 근접 글로우 링 -----------------------------
        if near:
            glow_r = int(ss(38) + 5 * math.sin(self._pulse))
            glow_s = self._get_glow_surface(self.color, glow_r)
            surf.blit(glow_s, (cx - glow_r, cy - glow_r + ss(18)))

        # -- 이름 라벨 ----------------------------------
        if frame is not None:
            nw = frame.get_width()
            nh = frame.get_height()
        else:
            nw = HubPlayer.FRAME_W * HubPlayer.RENDER_SCALE
            nh = HubPlayer.FRAME_H * HubPlayer.RENDER_SCALE
        label_y = cy + nh // 2 + ss(4)
        name_surf = self._get_text_surface(font_big, self.name,
                                           (255, 255, 255) if near else label_col)
        surf.blit(name_surf, (cx - name_surf.get_width()//2, label_y))

        # -- 직함 --------------------------------------
        title_line = style.get('title_line', '')
        if title_line:
            title_surf = self._get_text_surface(font_sm, title_line,
                                            label_col if near else (120, 120, 140))
            surf.blit(title_surf, (cx - title_surf.get_width()//2,
                                   label_y + font_big.get_height() + ss(2)))

        # -- 말풍선 + 상호작용 힌트 ---------------------
        if near:
            dialogue = self.NPC_DIALOGUES.get(self.key, '[E] 상호작용')
            hint_y   = cy - nh // 2 - ss(48)

            # 말풍선 배경
            hint_surf = self._get_text_surface(font_sm, dialogue, (230, 230, 200))
            bubble_w  = hint_surf.get_width() + sx(16)
            bubble_h  = hint_surf.get_height() + sy(10)
            bubble_x  = cx - bubble_w // 2
            bubble_y  = hint_y

            bub = self._get_bubble_surface((bubble_w, bubble_h), label_col)
            surf.blit(bub, (bubble_x, bubble_y))
            surf.blit(hint_surf, (bubble_x + sx(8), bubble_y + sy(5)))

            # 꼬리 삼각형
            tip_x = cx
            tip_y = bubble_y + bubble_h
            pygame.draw.polygon(surf, label_col, [
                (tip_x - ss(6), tip_y),
                (tip_x + ss(6), tip_y),
                (tip_x, tip_y + ss(8)),
            ])

            # [E] 힌트
            e_hint = self._get_text_surface(font_sm, "[E] 상호작용", (200, 200, 100))
            surf.blit(e_hint, (cx - e_hint.get_width()//2,
                               label_y + font_big.get_height() + ss(20)))


# -----------------------------------------------------
# MirrorPanel - 거울 강화 UI 패널
# -----------------------------------------------------
class MirrorPanel:
    W = sx(460)
    H = sy(480)

    def __init__(self):
        self._ready = False

    def _init_fonts(self):
        if self._ready: return
        self.f_title = get_font(22, bold=True)
        self.f_item  = get_font(17, bold=True)
        self.f_desc  = get_font(14)
        self.f_cost  = get_font(15, bold=True)
        self.f_aether= get_font(18, bold=True)
        self._ready  = True

    def handle_event(self, event, save_data) -> str | None:
        """'close' 또는 upgrade_id 반환"""
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_ESCAPE, pygame.K_e, pygame.K_m):
                return 'close'
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mx, my = event.pos
            ox, oy = self._origin()
            # 닫기 버튼
            close_r = pygame.Rect(ox + self.W - sx(36), oy + sy(6),
                                  sx(30), sy(28))
            if close_r.collidepoint(mx, my):
                return 'close'
            # 업그레이드 버튼들
            for i, u in enumerate(MIRROR_UPGRADES):
                btn_r = self._btn_rect(i, ox, oy)
                if btn_r.collidepoint(mx, my):
                    return u['id']
        return None

    def _origin(self):
        return (WIDTH//2 - self.W//2, HEIGHT//2 - self.H//2)

    def _btn_rect(self, i, ox, oy):
        row_h = sy(72)
        y     = oy + sy(100) + i * row_h
        return pygame.Rect(ox + self.W - sx(120), y + sy(14),
                           sx(110), sy(34))

    def draw(self, surf, save_data):
        self._init_fonts()
        ox, oy = self._origin()
        aether = save_data.get('aether', 0)
        mirror = save_data.get('mirror_upgrades', {})

        # 배경
        bg = pygame.Surface((self.W, self.H), pygame.SRCALPHA)
        bg.fill((8, 8, 28, 230))
        surf.blit(bg, (ox, oy))
        pygame.draw.rect(surf, (60, 80, 160),
                         (ox, oy, self.W, self.H), 2, border_radius=ss(12))

        # 타이틀
        t = self.f_title.render("[ 거울 강화 ]", True, (160, 200, 255))
        surf.blit(t, (ox + self.W//2 - t.get_width()//2, oy + sy(14)))

        # 에테르 표시
        ae_t = self.f_aether.render(f"에테르  {aether}", True, (255, 215, 60))
        surf.blit(ae_t, (ox + sx(14), oy + sy(50)))

        # 구분선
        pygame.draw.line(surf, (60, 80, 160),
                         (ox + sx(10), oy + sy(82)),
                         (ox + self.W - sx(10), oy + sy(82)), 1)

        # 닫기 버튼
        close_r = pygame.Rect(ox + self.W - sx(36), oy + sy(6), sx(30), sy(28))
        pygame.draw.rect(surf, (80, 30, 30), close_r, border_radius=ss(4))
        cl = self.f_desc.render("X", True, (255, 120, 120))
        surf.blit(cl, (close_r.centerx - cl.get_width()//2,
                       close_r.centery - cl.get_height()//2))

        # 강화 항목
        row_h = sy(72)
        for i, u in enumerate(MIRROR_UPGRADES):
            y    = oy + sy(100) + i * row_h
            cur_lv = mirror.get(u['id'], 0)
            maxed  = cur_lv >= u['max_level']

            # 행 배경
            row_bg = pygame.Surface((self.W - sx(20), row_h - sy(6)),
                                    pygame.SRCALPHA)
            row_bg.fill((20, 20, 50, 160))
            surf.blit(row_bg, (ox + sx(10), y))
            pygame.draw.rect(surf, (40, 40, 80),
                             (ox + sx(10), y, self.W - sx(20), row_h - sy(6)),
                             1, border_radius=ss(6))

            # 아이콘 + 이름
            ic  = self.f_item.render(u['icon'], True, u['color'])
            nm  = self.f_item.render(u['name'], True,
                                     u['color'] if not maxed else (120, 120, 140))
            surf.blit(ic, (ox + sx(18), y + sy(8)))
            surf.blit(nm, (ox + sx(42), y + sy(8)))

            # 레벨 바
            total_w  = sx(140)
            bar_x    = ox + sx(18)
            bar_y    = y + sy(38)
            bar_h    = sy(10)
            filled_w = int(total_w * cur_lv / u['max_level'])
            pygame.draw.rect(surf, (30, 30, 60),
                             (bar_x, bar_y, total_w, bar_h), border_radius=ss(4))
            if filled_w > 0:
                pygame.draw.rect(surf, u['color'],
                                 (bar_x, bar_y, filled_w, bar_h),
                                 border_radius=ss(4))
            lv_t = self.f_desc.render(
                f"MAX" if maxed else f"Lv {cur_lv}/{u['max_level']}",
                True, (180,180,200) if not maxed else (255, 215, 60))
            surf.blit(lv_t, (bar_x + total_w + sx(8), bar_y - sy(1)))

            # 설명
            if cur_lv < u['max_level']:
                total_val = get_mirror_total_value(u['id'], cur_lv + 1) - \
                            get_mirror_total_value(u['id'], cur_lv)
                desc = u['desc'].format(val=total_val)
            else:
                desc = "최대 레벨 달성"
            desc_s = self.f_desc.render(desc, True, (140, 140, 160))
            surf.blit(desc_s, (ox + sx(18), y + sy(54)))

            # 업그레이드 버튼
            btn_r = self._btn_rect(i, ox, oy)
            if maxed:
                pygame.draw.rect(surf, (30, 30, 50), btn_r, border_radius=ss(6))
                bt = self.f_cost.render("완료", True, (80, 80, 100))
            else:
                cost = u['costs'][cur_lv]
                can  = aether >= cost
                col  = (40, 120, 60) if can else (50, 30, 30)
                pygame.draw.rect(surf, col, btn_r, border_radius=ss(6))
                border_c = (80, 200, 100) if can else (80, 50, 50)
                pygame.draw.rect(surf, border_c, btn_r, 1, border_radius=ss(6))
                bt = self.f_cost.render(
                    f"강화  {cost} 에테르", True,
                    (200, 255, 180) if can else (100, 80, 80))
            surf.blit(bt, (btn_r.centerx - bt.get_width()//2,
                           btn_r.centery - bt.get_height()//2))

        # ESC 힌트
        hint = self.f_desc.render("ESC / E / M  닫기", True, (80, 80, 100))
        surf.blit(hint, (ox + self.W//2 - hint.get_width()//2,
                         oy + self.H - sy(22)))


# -----------------------------------------------------
# RunHistoryPanel - 런 기록 패널
# -----------------------------------------------------
class RunHistoryPanel:
    W = sx(400)
    H = sy(400)

    def __init__(self):
        self._ready = False

    def _init_fonts(self):
        if self._ready: return
        self.f_title = get_font(20, bold=True)
        self.f_row   = get_font(14)
        self.f_head  = get_font(13, bold=True)
        self._ready  = True

    def handle_event(self, event) -> str | None:
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_ESCAPE, pygame.K_e, pygame.K_l):
                return 'close'
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            ox, oy = self._origin()
            close_r = pygame.Rect(ox + self.W - sx(36), oy + sy(6),
                                  sx(30), sy(28))
            if close_r.collidepoint(*event.pos):
                return 'close'
        return None

    def _origin(self):
        return (WIDTH//2 - self.W//2, HEIGHT//2 - self.H//2)

    def draw(self, surf, save_data):
        self._init_fonts()
        ox, oy = self._origin()
        history = save_data.get('run_history', [])

        bg = pygame.Surface((self.W, self.H), pygame.SRCALPHA)
        bg.fill((8, 18, 8, 230))
        surf.blit(bg, (ox, oy))
        pygame.draw.rect(surf, (60, 160, 80),
                         (ox, oy, self.W, self.H), 2, border_radius=ss(12))

        t = self.f_title.render("[ 런 기록 ]", True, (120, 255, 140))
        surf.blit(t, (ox + self.W//2 - t.get_width()//2, oy + sy(14)))

        # 닫기
        close_r = pygame.Rect(ox + self.W - sx(36), oy + sy(6), sx(30), sy(28))
        pygame.draw.rect(surf, (30, 80, 30), close_r, border_radius=ss(4))
        cl = self.f_head.render("X", True, (120, 255, 120))
        surf.blit(cl, (close_r.centerx - cl.get_width()//2,
                       close_r.centery - cl.get_height()//2))

        # 헤더
        hx = ox + sx(12)
        hy = oy + sy(50)
        cols = ['런', '점수', '레벨', '처치', '에테르']
        cws  = [sx(28), sx(90), sx(52), sx(52), sx(70)]
        cx_ = hx
        for col, cw in zip(cols, cws):
            h_s = self.f_head.render(col, True, (100, 200, 120))
            surf.blit(h_s, (cx_, hy))
            cx_ += cw
        pygame.draw.line(surf, (60, 120, 60),
                         (hx, hy + sy(20)),
                         (ox + self.W - sx(12), hy + sy(20)), 1)

        if not history:
            no_t = self.f_row.render("아직 기록이 없습니다", True, (80, 100, 80))
            surf.blit(no_t, (ox + self.W//2 - no_t.get_width()//2,
                              oy + self.H//2))
        else:
            for i, run in enumerate(history[:8]):
                ry  = hy + sy(30) + i * sy(38)
                alt = pygame.Surface((self.W - sx(24), sy(32)), pygame.SRCALPHA)
                alt.fill((20, 40, 20, 80) if i % 2 == 0 else (10, 20, 10, 60))
                surf.blit(alt, (hx, ry - sy(4)))

                vals = [
                    f"#{i+1}",
                    f"{run.get('score', 0):,}",
                    f"Lv{run.get('level', 0)}",
                    f"{run.get('kills', 0)}",
                    f"{run.get('aether', 0)}",
                ]
                cx_ = hx
                for val, cw in zip(vals, cws):
                    col_c = (200, 255, 200) if i == 0 else (140, 180, 140)
                    vs = self.f_row.render(val, True, col_c)
                    surf.blit(vs, (cx_, ry))
                    cx_ += cw

        hint = self.f_row.render("ESC / E / L  닫기", True, (60, 100, 60))
        surf.blit(hint, (ox + self.W//2 - hint.get_width()//2,
                         oy + self.H - sy(22)))


# -----------------------------------------------------
# HubWorld - 메인 허브 클래스
# -----------------------------------------------------
class HubWorld:
    """
    상태:
      'free'    - 자유 이동
      'mirror'  - 거울 강화 패널 열림
      'history' - 런 기록 패널 열림
    반환 액션:
      'launch'  - 출격 (런 시작)
      None      - 계속 허브
    """

    # -- NPC 배치: 맵 월드 좌표 (pixel*2 스케일)  ------------------
    # 맵 TMX: 40x20타일, 타일1칸=32px, scale=2 -> world 타일1칸=64px
    #
    # [출격]포탈 문 구조물 (TMX 벽 레이어 col16~21, row0~2) 기준
    #   문 중심 x = (16+22)/2 * 64 = 1216
    #   문 하단 y = 3*64=192 -> 바로 아래 row3 중심 y = 224
    #   -> (1216, 224)  <- 카메라 이동과 무관한 타일 절대 좌표
    #
    # [나머지]포탈 문을 앵커로 camera(255,94) 역산 후 동그라미 위치 변환
    STATION_WORLD = [
        # (world_x, world_y, name,     key,       color,           icon, desc)
        (1216, 224,  '출격',      'launch',  (80,  220, 140), 'E', '[E] 출격'),
        (862,  373,  '거울 강화', 'mirror',  (100, 140, 255), 'M', '[M] 영구 강화'),
        (1596, 355,  '런 기록',   'history', (80,  200, 100), 'L', '[L] 기록 확인'),
        (614,  958,  '옵션',      'options', (180, 140, 80),  'O', '[O] 옵션'),
        (1833, 962,  '메인 메뉴', 'main',    (160, 80,  80),  'Q', '[Q] 메뉴로'),
    ]
    PROP_DEFS = []

    def __init__(self, save_data):
        self.save_data   = save_data
        self._sub_state  = 'free'
        self._ready      = False
        self._aether_flash = 0
        self._reward_aether  = 0
        self._reward_visible = 0
        self._camera_x = 0
        self._camera_y = 0
        self._map_raw = None
        self._map_surface = None
        self._walkable_mask = None
        self._walkable_rect = pygame.Rect(0, 0, WIDTH, HEIGHT)
        self._map_scale = 2
        self._sfx_volume = 0.8
        self._ui_sounds = {}
        self._hud_cache = {}
        self._controls_cache = None
        self._bar_surfaces = {}
        self._load_map()

        self.hub_player = HubPlayer(*self._start_position())
        self.stations = self._build_stations()
        self.mirror_panel  = MirrorPanel()
        self.history_panel = RunHistoryPanel()
        self._sync_camera(force=True)

    def _load_map(self):
        map_path = os.path.join(ASSETS_DIR, 'hub_map.png')
        try:
            raw = pygame.image.load(map_path).convert()
        except Exception:
            raw = pygame.Surface((WIDTH, HEIGHT))
            raw.fill((40, 40, 48))
        self._map_raw = raw
        mw = max(raw.get_width() * self._map_scale, WIDTH + sx(160))
        mh = max(raw.get_height() * self._map_scale, HEIGHT + sy(120))
        self._map_surface = pygame.transform.scale(raw, (mw, mh))
        self._walkable_rect = pygame.Rect(0, 0, mw, mh)
        self._build_walkable_mask()

    def _build_walkable_mask(self):
        surf = self._map_surface
        mask = pygame.mask.Mask(surf.get_size(), False)
        w, h = surf.get_size()
        for y in range(h):
            for x in range(w):
                c = surf.get_at((x, y))[:3]
                if c != (0, 0, 0):
                    mask.set_at((x, y), 1)
        self._walkable_mask = mask

    def _start_position(self):
        x = self._walkable_rect.width * 0.5
        y = self._walkable_rect.height * 0.90
        return self._nearest_walkable(x, y)

    def _build_stations(self):
        stations = []
        for wx, wy, name, key, color, icon, desc in self.STATION_WORLD:
            fx, fy = self._nearest_walkable(float(wx), float(wy))
            stations.append(HubNPC(fx, fy, name, key, color, icon, desc))
        return stations

    def _nearest_walkable(self, x, y):
        x = int(max(0, min(self._walkable_rect.width - 1, x)))
        y = int(max(0, min(self._walkable_rect.height - 1, y)))
        if self._walkable_mask.get_at((x, y)):
            return float(x), float(y)
        max_r = int(max(self._walkable_rect.width, self._walkable_rect.height) * 0.25)
        for r in range(1, max_r, max(2, ss(6))):
            for dy in range(-r, r + 1, max(2, ss(6))):
                for dx in (-r, r):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < self._walkable_rect.width and 0 <= ny < self._walkable_rect.height and self._walkable_mask.get_at((nx, ny)):
                        return float(nx), float(ny)
            for dx in range(-r, r + 1, max(2, ss(6))):
                for dy in (-r, r):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < self._walkable_rect.width and 0 <= ny < self._walkable_rect.height and self._walkable_mask.get_at((nx, ny)):
                        return float(nx), float(ny)
        return float(self._walkable_rect.width * 0.5), float(self._walkable_rect.height * 0.85)

    def can_walk(self, cx, cy, w, h):
        if not self._walkable_mask:
            return True
        inset_x = max(2, w // 4)
        inset_y = max(2, h // 4)
        pts = [
            (int(cx), int(cy)),
            (int(cx - inset_x), int(cy - inset_y)),
            (int(cx + inset_x), int(cy - inset_y)),
            (int(cx - inset_x), int(cy + inset_y)),
            (int(cx + inset_x), int(cy + inset_y)),
        ]
        for px, py in pts:
            if not (0 <= px < self._walkable_rect.width and 0 <= py < self._walkable_rect.height):
                return False
            if not self._walkable_mask.get_at((px, py)):
                return False
        return True

    def _sync_camera(self, force=False):
        target_x = self.hub_player.x - WIDTH / 2
        target_y = self.hub_player.y - HEIGHT / 2
        max_x = max(0, self._walkable_rect.width - WIDTH)
        max_y = max(0, self._walkable_rect.height - HEIGHT)
        target_x = max(0, min(max_x, target_x))
        target_y = max(0, min(max_y, target_y))
        if force:
            self._camera_x = target_x
            self._camera_y = target_y
        else:
            self._camera_x += (target_x - self._camera_x) * 0.14
            self._camera_y += (target_y - self._camera_y) * 0.14

    def _world_to_screen(self, x, y):
        return int(x - self._camera_x), int(y - self._camera_y)

    def _init_fonts(self):
        if self._ready: return
        self.f_title   = get_font(26, bold=True)
        self.f_ui      = get_font(18, bold=True)
        self.f_sm      = get_font(14)
        self.f_station = get_font(17, bold=True)
        self.f_station_sm = get_font(13)
        self.f_reward  = get_font(20, bold=True)
        self._ready    = True

    def set_sfx_volume(self, volume):
        try:
            self._sfx_volume = max(0.0, min(1.0, float(volume)))
        except Exception:
            self._sfx_volume = 0.8
        for snd in self._ui_sounds.values():
            if snd is not None:
                snd.set_volume(self._sfx_volume)

    def _load_ui_sound(self, filename):
        if filename in self._ui_sounds:
            return self._ui_sounds[filename]
        path = os.path.join(ASSETS_DIR, filename)
        try:
            snd = pygame.mixer.Sound(path)
            snd.set_volume(self._sfx_volume)
        except Exception:
            snd = None
        self._ui_sounds[filename] = snd
        return snd

    def _play_click(self):
        snd = self._load_ui_sound('sfx_ui_click.wav')
        if snd is not None:
            snd.play()

    def _play_confirm(self):
        snd = self._load_ui_sound('sfx_ui_confirm.wav')
        if snd is not None:
            snd.play()

    def open(self, aether_earned=0):
        self._sub_state = 'free'
        self.hub_player = HubPlayer(*self._start_position())
        self._hud_cache.clear()
        self._sync_camera(force=True)
        if aether_earned > 0:
            self._reward_aether  = aether_earned
            self._reward_visible = 240

    def handle_event(self, event) -> str | None:
        if self._sub_state == 'mirror':
            result = self.mirror_panel.handle_event(event, self.save_data)
            if result == 'close':
                self._play_click()
                self._sub_state = 'free'
            elif result and result.startswith('mirror_'):
                upgraded = self._do_mirror_upgrade(result)
                if upgraded:
                    self._play_confirm()
                else:
                    self._play_click()
            return None

        if self._sub_state == 'history':
            result = self.history_panel.handle_event(event)
            if result == 'close':
                self._play_click()
                self._sub_state = 'free'
            return None

        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_e, pygame.K_RETURN):
                return self._interact_nearest()
            if event.key == pygame.K_m:
                self._play_click()
                self._sub_state = 'mirror'
                return None
            if event.key == pygame.K_l:
                self._play_click()
                self._sub_state = 'history'
                return None
            if event.key == pygame.K_o:
                self._play_click()
                return 'options'
            if event.key == pygame.K_q:
                self._play_click()
                return 'main'
        return None

    def _interact_nearest(self) -> str | None:
        nearest = None
        nearest_dist = 10**9
        for st in self.stations:
            dist = math.hypot(self.hub_player.x - st.x, self.hub_player.y - st.y)
            if dist < nearest_dist and dist < st.INTERACT_DIST:
                nearest_dist = dist
                nearest = st
        if nearest:
            return self._activate_station(nearest.key)
        return None

    def _activate_station(self, key) -> str | None:
        if key == 'mirror':
            self._play_click()
            self._sub_state = 'mirror'
            return None
        if key == 'history':
            self._play_click()
            self._sub_state = 'history'
            return None
        if key == 'launch':
            self._play_confirm()
            return 'launch'
        if key == 'options':
            self._play_click()
            return 'options'
        if key == 'main':
            self._play_click()
            return 'main'
        return None

    def _do_mirror_upgrade(self, uid):
        mirror = self.save_data.setdefault('mirror_upgrades', {})
        u      = MIRROR_BY_ID.get(uid)
        if not u:
            return False
        cur_lv = mirror.get(uid, 0)
        if cur_lv >= u['max_level']:
            return False
        cost   = u['costs'][cur_lv]
        if self.save_data.get('aether', 0) < cost:
            return False
        self.save_data['aether']  -= cost
        mirror[uid]                = cur_lv + 1
        from save import save as _save
        _save(self.save_data)
        return True

    def update(self, keys):
        if self._sub_state == 'free':
            self.hub_player.update(keys, self.can_walk, self._walkable_rect)
            self._sync_camera()
        for st in self.stations:
            st.update()
        if self._reward_visible > 0:
            self._reward_visible -= 1

    def draw(self, surf):
        self._init_fonts()
        self._draw_bg(surf)
        self._draw_stations(surf)
        self._draw_hub_player(surf)
        self._draw_hud(surf)
        if self._reward_visible > 0:
            self._draw_reward_banner(surf)
        if self._sub_state == 'mirror':
            self.mirror_panel.draw(surf, self.save_data)
        elif self._sub_state == 'history':
            self.history_panel.draw(surf, self.save_data)
        self._draw_controls(surf)


    def _get_overlay_bar(self, size, color, line_color, top=True):
        key = (size[0], size[1], color, line_color, top)
        cached = self._bar_surfaces.get(key)
        if cached is not None:
            return cached
        bar = pygame.Surface(size, pygame.SRCALPHA)
        bar.fill(color)
        y = size[1] - 1 if top else 0
        pygame.draw.line(bar, line_color, (0, y), (size[0], y), 1)
        self._bar_surfaces[key] = bar
        return bar

    def _get_hud_surfaces(self):
        aether = self.save_data.get('aether', 0)
        total = self.save_data.get('total_aether', 0)
        runs = self.save_data.get('total_runs', 0)
        key = (aether, total, runs)
        cached = self._hud_cache.get(key)
        if cached is not None:
            return cached
        title_s = self.f_title.render("[ PULSE DRIVE - 격납고 ]", True, (120, 180, 255))
        ae_s = self.f_ui.render(f"에테르  {aether}  ( 총 획득 {total} )", True, (255, 215, 60))
        run_s = self.f_sm.render(f"총 런 수: {runs}", True, (100, 120, 160))
        loc_s = self.f_sm.render("검은색 영역은 진입 불가", True, (150, 160, 200))
        cached = (title_s, ae_s, run_s, loc_s)
        self._hud_cache = {key: cached}
        return cached

    def _get_control_surfaces(self):
        if self._controls_cache is not None:
            return self._controls_cache
        hints = [
            "방향키/WASD  이동",
            "Shift+이동  구르기",
            "E/Enter  상호작용",
            "M  거울 강화",
            "L  런 기록",
            "Q  메인 메뉴",
        ]
        rendered = [self.f_sm.render(h, True, (80, 100, 140)) for h in hints]
        total_w = sum(s.get_width() + sx(30) for s in rendered) - sx(30)
        self._controls_cache = (rendered, total_w)
        return self._controls_cache

    def _draw_bg(self, surf):
        surf.fill((0, 0, 0))
        surf.blit(self._map_surface, (-int(self._camera_x), -int(self._camera_y)))

        bar = self._get_overlay_bar((WIDTH, sy(54)), (6, 10, 30, 200), (40, 60, 120), top=True)
        surf.blit(bar, (0, 0))

        bot = self._get_overlay_bar((WIDTH, sy(48)), (6, 10, 30, 200), (40, 60, 120), top=False)
        surf.blit(bot, (0, HEIGHT - sy(48)))

    def _draw_stations(self, surf):
        for st in self.stations:
            near = st.in_range(self.hub_player) and self._sub_state == 'free'
            st.draw(surf, near, self.f_station, self.f_station_sm, camera=(self._camera_x, self._camera_y))

    def _draw_hub_player(self, surf):
        px, py = self._world_to_screen(self.hub_player.x, self.hub_player.y)
        self.hub_player.draw(surf, px, py)

    def _draw_hud(self, surf):
        title_s, ae_s, run_s, loc = self._get_hud_surfaces()
        surf.blit(title_s, (WIDTH//2 - title_s.get_width()//2, sy(10)))
        surf.blit(ae_s, (sx(20), sy(12)))
        surf.blit(run_s, (WIDTH - run_s.get_width() - sx(20), sy(14)))
        surf.blit(loc, (sx(20), HEIGHT - sy(34)))

    def _draw_reward_banner(self, surf):
        ratio = self._reward_visible / 240
        if ratio > 0.75:
            alpha = int(255 * (1 - ratio) / 0.25)
        elif ratio < 0.5:
            alpha = int(255 * ratio / 0.5)
        else:
            alpha = 255

        bw, bh = sx(360), sy(60)
        bx = WIDTH//2 - bw//2
        by = HEIGHT - sy(90)

        banner = pygame.Surface((bw, bh), pygame.SRCALPHA)
        banner.fill((20, 16, 4, int(200 * alpha / 255)))
        pygame.draw.rect(banner, (200, 160, 0, alpha), (0, 0, bw, bh), 2, border_radius=ss(8))

        t1 = self.f_reward.render(f"+ {self._reward_aether}  에테르 획득!", True, (255, 215, 60))
        t1.set_alpha(alpha)
        banner.blit(t1, (bw//2 - t1.get_width()//2, bh//2 - t1.get_height()//2))
        surf.blit(banner, (bx, by))

    def _draw_controls(self, surf):
        if self._sub_state != 'free':
            return
        rendered, total_w = self._get_control_surfaces()
        hx = WIDTH//2 - total_w//2
        hy = HEIGHT - sy(32)
        for hs in rendered:
            surf.blit(hs, (hx, hy))
            hx += hs.get_width() + sx(30)
