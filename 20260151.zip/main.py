"""
PULSE DRIVE  -  main.py
실행: python main.py
의존: pip install pygame
"""

import pygame, sys, random, math
from pathlib import Path
from settings  import *
from save      import (load as load_save, update_best, load_options, save_options,
                       load_progress, calc_aether_reward, record_run)
from hub       import HubWorld, apply_mirror_upgrades
from characters import CHARACTERS
from particle  import ParticleManager
from rhythm    import RhythmEngine
from weapon    import Bullet, GuidedBullet, ClusterBullet
from enemy     import Enemy, SpawnManager
from boss      import Boss
from upgrade   import (UpgradeMenu, get_random_cards,
                       check_new_synergies, apply_synergy, SYNERGY_DISPLAY)
from player    import Player
from hud       import HUD
from ui        import MainMenu, GameOverScreen, PauseScreen, WarningScreen, OptionsScreen, CharacterSelect


# -----------------------------------------------------
# Space background image scroller
# -----------------------------------------------------
class SpaceBackground:
    def __init__(self):
        self._img    = None
        self._scroll = 0.0
        self._speed  = 0.4   # 천천히 스크롤
        self._load()

    def _load(self):
        try:
            raw       = pygame.image.load(IMG_BG_SPACE).convert()
            self._img = pygame.transform.scale(raw, (WIDTH, raw.get_height()))
        except Exception:
            self._img = None

    def update(self):
        if not self._img: return
        self._scroll = (self._scroll + self._speed) % self._img.get_height()

    def draw(self, surf):
        if not self._img:
            surf.fill(BG_COLOR)
            return
        ih = self._img.get_height()
        # 이미지를 세로로 두 번 그려서 끊김 없이 루프 스크롤
        y0 = int(self._scroll) - ih
        y1 = int(self._scroll)
        surf.blit(self._img, (0, y0))
        surf.blit(self._img, (0, y1))
_FPS_INV = 1.0 / 60   # 1/FPS 상수화 - 매 프레임 나눗셈 방지




class UISoundManager:
    """Lightweight UI SFX helper tied to the options SFX volume."""
    def __init__(self, sfx_volume=0.8):
        self._volume = 0.8
        self._sounds = {}
        self.set_volume(sfx_volume)

    def set_volume(self, volume):
        try:
            self._volume = max(0.0, min(1.0, float(volume)))
        except Exception:
            self._volume = 0.8
        for snd in self._sounds.values():
            if snd is not None:
                snd.set_volume(self._volume)

    def _load(self, filename):
        if filename in self._sounds:
            return self._sounds[filename]
        path = Path(ASSETS_DIR) / filename
        try:
            snd = pygame.mixer.Sound(str(path))
            snd.set_volume(self._volume)
        except Exception:
            snd = None
        self._sounds[filename] = snd
        return snd

    def play_click(self):
        snd = self._load('sfx_ui_click.wav')
        if snd is not None:
            snd.play()

    def play_confirm(self):
        snd = self._load('sfx_ui_confirm.wav')
        if snd is not None:
            snd.play()

class Game:
    S_MAIN    = 'main'
    S_HUB     = 'hub'       # 허브 월드 (격납고)
    S_SELECT  = 'select'
    S_PLAYING = 'playing'
    S_UPGRADE = 'upgrade'
    S_WARNING = 'warning'
    S_OVER    = 'gameover'
    S_RETURN  = 'return_to_hub'
    S_PAUSE   = 'pause'
    S_OPTIONS = 'options'
    WARNING_DUR = 150
    GAMEOVER_DUR = 180
    RETURN_DUR = 105

    def __init__(self):
        pygame.init()
        pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)

        # 내부 렌더링용 서피스 (항상 800x600)
        self.game_surf  = pygame.Surface((WIDTH, HEIGHT))
        # 실제 윈도우
        self.screen     = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
        self._fullscreen = False
        pygame.display.set_caption(TITLE)
        # 화면 스케일 변환 (전체화면-창 크기 변경 대응)
        self._screen_ox    = 0
        self._screen_oy    = 0
        self._screen_scale = 1.0
        self.clock  = pygame.time.Clock()

        self.save_data    = load_save()
        load_progress(self.save_data)          # 영구 진행 필드 초기화
        self.game_options = load_options()
        self.state        = self.S_MAIN
        self._pause_from  = self.S_MAIN  # 옵션 화면 닫힌 뒤 복귀 상태

        self.space_bg  = SpaceBackground()
        self.particles = ParticleManager()
        self.particles.init_fonts()
        self.rhythm    = RhythmEngine()
        self.ui_sfx    = UISoundManager(self.game_options.get('sfx_volume', 80) / 100)

        self.hud          = HUD()
        self.upgrade_menu = UpgradeMenu()
        self.main_menu    = MainMenu(self.save_data)
        self.gameover_ui  = GameOverScreen()
        self.pause_ui     = PauseScreen()
        self.warning_ui   = WarningScreen()
        self.options_ui   = OptionsScreen(self.game_options)
        self.char_select  = CharacterSelect(CHARACTERS)
        self.selected_char = CHARACTERS[0]   # 마지막으로 선택한 캐릭터

        # 허브 월드
        self.hub_world = HubWorld(self.save_data)
        self.hub_world.set_sfx_volume(self.game_options.get('sfx_volume', 80) / 100)

        # 저장된 볼륨 설정만 적용 (전체화면은 게임 시작 시 창 모드 고정)
        self._apply_volume()

        self._reset_runtime()

    # -------------------------------------------------
    # Fullscreen toggle
    # -------------------------------------------------
    def _toggle_fullscreen(self):
        self._fullscreen = not self._fullscreen
        if self._fullscreen:
            self.screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        else:
            self.screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
        # game_options와 동기화 - 옵션 UI 열 때 현재 상태 반영
        self.game_options['fullscreen'] = self._fullscreen
        # 스케일 값 즉시 갱신
        sw, sh = self.screen.get_size()
        scale  = min(sw / WIDTH, sh / HEIGHT)
        new_w  = int(WIDTH * scale)
        new_h  = int(HEIGHT * scale)
        self._screen_ox    = (sw - new_w) // 2
        self._screen_oy    = (sh - new_h) // 2
        self._screen_scale = scale

    # -------------------------------------------------
    # Apply game options
    # -------------------------------------------------
    def _apply_volume(self):
        """볼륨만 적용 - 초기화 시 전체화면 자동 적용 방지용"""
        vol = self.game_options.get('bgm_volume', 65) / 100
        self.rhythm.set_bgm_volume(vol)
        if hasattr(self, 'ui_sfx'):
            self.ui_sfx.set_volume(self.game_options.get('sfx_volume', 80) / 100)
        if hasattr(self, 'hub_world'):
            self.hub_world.set_sfx_volume(self.game_options.get('sfx_volume', 80) / 100)

    def _apply_options(self):
        """game_options 딕셔너리의 값을 실제 게임에 즉시 반영"""
        opts = self.game_options

        # BGM / SFX 볼륨
        self.rhythm.set_bgm_volume(opts['bgm_volume'] / 100)
        if hasattr(self, 'ui_sfx'):
            self.ui_sfx.set_volume(opts['sfx_volume'] / 100)
        if hasattr(self, 'hub_world'):
            self.hub_world.set_sfx_volume(opts['sfx_volume'] / 100)

        # 전체화면 - 조건 없이 항상 적용 (저장 시 확실히 반영)
        want_fs = opts.get('fullscreen', False)
        self._fullscreen = want_fs
        if want_fs:
            self.screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        else:
            self.screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
        # 스케일 값을 즉시 초기화 (다음 _draw() 전 클릭 대응)
        sw, sh = self.screen.get_size()
        scale  = min(sw / WIDTH, sh / HEIGHT)
        new_w  = int(WIDTH * scale)
        new_h  = int(HEIGHT * scale)
        self._screen_ox    = (sw - new_w) // 2
        self._screen_oy    = (sh - new_h) // 2
        self._screen_scale = scale

    # -------------------------------------------------
    # Runtime reset
    # -------------------------------------------------
    def _reset_runtime(self):
        self.player        = None
        self.boss          = None
        self.boss_index    = 0

        self.pbullets = pygame.sprite.Group()
        self.ebullets = pygame.sprite.Group()
        self.enemies  = pygame.sprite.Group()

        self.spawn_manager = None
        self.elapsed_frames = 0
        self.elapsed_secs   = 0.0

        self._shake_t = 0
        self._shake_i = 0
        self._warn_timer = 0
        self._return_timer = 0
        self._gameover_timer = 0
        self.syn_banners = []
        self._new_record = False
        self._last_aether_earned = 0
        self._boss_spawned_levels = set()
        self._levelup_pending = False
        # 페이즈2 전환 슬로우모션
        self._slowmo_timer  = 0   # 남은 슬로우모션 프레임
        self._phase2_banner = 0   # PHASE 2 텍스트 표시 프레임

    # -------------------------------------------------
    # Screen shake
    # -------------------------------------------------
    def shake(self, intensity, duration):
        self._shake_i = intensity
        self._shake_t = duration

    def _get_offset(self):
        if self._shake_t > 0:
            self._shake_t -= 1
            return (random.randint(-self._shake_i, self._shake_i),
                    random.randint(-self._shake_i, self._shake_i))
        return (0,0)

    # -------------------------------------------------
    # Mouse coordinate transform (screen -> game_surf)
    # -------------------------------------------------
    def _to_game_pos(self, sx_: int, sy_: int):
        """실제 스크린 좌표 -> game_surf 내부 좌표 변환"""
        if self._screen_scale <= 0:
            return sx_, sy_
        gx = int((sx_ - self._screen_ox) / self._screen_scale)
        gy = int((sy_ - self._screen_oy) / self._screen_scale)
        return gx, gy
    def _start_game(self):
        self._reset_runtime()

        # Reset rhythm engine
        self.rhythm.combo               = 0
        self.rhythm.max_combo           = 0
        self.rhythm.char_perf_bonus     = 0.0
        self.rhythm.score               = 0
        self.rhythm.total_shots         = 0
        self.rhythm.perfect_shots       = 0
        self.rhythm.good_shots          = 0
        self.rhythm.perfect_window_bonus = 0
        self.rhythm.rhythm_overload     = False
        self.rhythm.overbeat_count      = 0
        self.rhythm._combo_boost        = False
        self.rhythm._overclock_active   = False

        self.upgrade_menu.reset(rerolls=2)

        self.player = Player(
            bullet_group = self.pbullets,
            enemies_ref  = self.enemies,
            particles    = self.particles,
        )

        # -- 캐릭터 특성 적용 -------------------------
        if self.selected_char:
            self.selected_char['apply'](self.player)
        # 캐릭터 특성 -> rhythm 엔진 동기화
        bonus = getattr(self.player, '_char_perfect_bonus', 0.0)
        self.rhythm.char_perf_bonus = bonus
        # VEGA combo_boost 동기화 (rhythm._combo_boost가 실제 판정에 사용됨)
        if getattr(self.player, 'combo_boost', False):
            self.rhythm._combo_boost = True

        # -- 영구 강화(거울) 적용 ---------------------
        apply_mirror_upgrades(
            self.player,
            self.save_data.get('mirror_upgrades', {}),
            self.upgrade_menu,
        )
        self.spawn_manager = SpawnManager(
            self.player, self.enemies, self.ebullets)

        # -- 난이도 적용 ------------------------------
        diff = self.game_options.get('difficulty', 'normal')
        if diff == 'easy':
            self.player.max_hp = int(self.player.max_hp * 1.5)
            self.player.hp     = self.player.max_hp
            self.spawn_manager.difficulty_hp_mul   = 0.7
            self.spawn_manager.difficulty_spd_mul  = 0.85
        elif diff == 'hard':
            self.player.max_hp = int(self.player.max_hp * 0.8)
            self.player.hp     = self.player.max_hp
            self.spawn_manager.difficulty_hp_mul   = 1.3
            self.spawn_manager.difficulty_spd_mul  = 1.15
        else:  # normal
            self.spawn_manager.difficulty_hp_mul   = 1.0
            self.spawn_manager.difficulty_spd_mul  = 1.0

        self.state = self.S_PLAYING
        self.rhythm.start_bgm('normal')

    def _enter_hub(self, aether_earned=0):
        self.hub_world.open(aether_earned=aether_earned)
        self.rhythm.switch_to_hub_bgm()
        self.state = self.S_HUB

    def _enter_main(self):
        self.rhythm.stop_bgm()
        self.state = self.S_MAIN

    # -------------------------------------------------
    # Events
    # -------------------------------------------------
    def _handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()

            # F11 전체화면 토글
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_F11:
                    self._toggle_fullscreen()

            # 마우스 클릭 좌표를 game_surf 기준으로 변환
            if event.type == pygame.MOUSEBUTTONDOWN:
                gx, gy = self._to_game_pos(*event.pos)
                event = pygame.event.Event(
                    pygame.MOUSEBUTTONDOWN,
                    {'pos': (gx, gy), 'button': event.button}
                )

            if self.state == self.S_MAIN:
                result = self.main_menu.handle_event(event)
                if result == 'start':
                    self.ui_sfx.play_confirm()
                    # 메인 메뉴 -> 허브로 진입
                    self._enter_hub(aether_earned=0)
                elif result == 'options':
                    self.ui_sfx.play_click()
                    self._pause_from = self.S_MAIN
                    self.options_ui.open(self.game_options)
                    self.state = self.S_OPTIONS
                elif result == 'exit':
                    self.ui_sfx.play_click()
                    pygame.quit(); sys.exit()

            elif self.state == self.S_HUB:
                hub_result = self.hub_world.handle_event(event)
                if hub_result == 'launch':
                    self.char_select.open()
                    self.state = self.S_SELECT
                elif hub_result == 'options':
                    self._pause_from = self.S_HUB
                    self.options_ui.open(self.game_options)
                    self.state = self.S_OPTIONS
                elif hub_result == 'main':
                    self._enter_main()

            elif self.state == self.S_SELECT:
                sel = self.char_select.handle_event(event)
                if sel == 'confirm':
                    self.ui_sfx.play_confirm()
                    self.selected_char = self.char_select.get_selected()
                    self._start_game()
                elif sel == 'back':
                    self.ui_sfx.play_click()
                    # 격납고 출격 화면에서 뒤로 가면 메인이 아니라 허브로 복귀
                    self._enter_hub(aether_earned=0)

            elif self.state == self.S_OPTIONS:
                prev_opts = dict(self.options_ui.get_options())
                action = self.options_ui.handle_event(event)
                curr_opts = self.options_ui.get_options()
                if curr_opts != prev_opts:
                    self.ui_sfx.set_volume(curr_opts.get('sfx_volume', 80) / 100)
                    self.hub_world.set_sfx_volume(curr_opts.get('sfx_volume', 80) / 100)
                    self.ui_sfx.play_click()
                if action == 'save':
                    self.game_options = curr_opts
                    save_options(self.game_options)
                    self._apply_options()
                    self.ui_sfx.play_confirm()
                    self.state = self._pause_from
                elif action == 'cancel':
                    self.ui_sfx.play_click()
                    self.state = self._pause_from
                elif action == 'reset_done':
                    # 저장 데이터 초기화
                    from save import DEFAULT, save as save_data_fn
                    self.save_data = dict(DEFAULT)
                    load_progress(self.save_data)
                    save_data_fn(self.save_data)
                    self.main_menu.save_data  = self.save_data
                    self.hub_world.save_data  = self.save_data   # 허브도 갱신
                    # 옵션도 저장 후 복귀
                    self.game_options = self.options_ui.get_options()
                    save_options(self.game_options)
                    self._apply_options()
                    self.ui_sfx.play_confirm()
                    self.state = self._pause_from

            elif self.state == self.S_UPGRADE:
                result = self.upgrade_menu.handle_event(event)
                if result == 'reroll':
                    if self.upgrade_menu.rerolls > 0:
                        self.upgrade_menu.rerolls -= 1
                        self.upgrade_menu.set_cards(get_random_cards(self.player))
                elif isinstance(result, int):
                    card = self.upgrade_menu.cards[result]
                    if card['rarity'] == 'combo':
                        # 조합 카드: 소스 무기 제거 + 조합 무기 장착 + 이펙트
                        card['apply'](self.player, self)
                        self.particles.spawn_synergy(WIDTH//2, HEIGHT//2)
                        self.particles.add_flash((255,130,30), duration=18, alpha=80)
                    else:
                        self.player.apply_upgrade(card, self)
                        self._check_synergies()
                    self.state = self.S_PLAYING

            elif self.state == self.S_PLAYING:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.state = self.S_PAUSE
                    elif event.key == pygame.K_f:
                        self._activate_ult()
                    elif event.key == pygame.K_p:
                        self._force_player_death()
                    # SPACE fires AND triggers rhythm judgment
                    if event.key == pygame.K_SPACE:
                        self._player_fire()

            elif self.state == self.S_PAUSE:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.ui_sfx.play_click()
                        self.state = self.S_PLAYING
                    elif event.key == pygame.K_q:
                            self.ui_sfx.play_confirm()
                            self._enter_hub()
                pause_action = self.pause_ui.handle_event(event)
                if pause_action == 'options':
                    self.ui_sfx.play_click()
                    self._pause_from = self.S_PAUSE   # 옵션 닫은 뒤 돌아올 상태 기억
                    self.options_ui.open(self.game_options)
                    self.state = self.S_OPTIONS

            elif self.state == self.S_OVER:
                if event.type == pygame.KEYDOWN:
                    if event.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_ESCAPE):
                        self.ui_sfx.play_confirm()
                        self._return_timer = self.RETURN_DUR
                        self.state = self.S_RETURN
                    if event.key == pygame.K_q:
                        pygame.quit(); sys.exit()
                over_action = self.gameover_ui.handle_event(event)
                if over_action == 'return_hub':
                    self.ui_sfx.play_confirm()
                    self._return_timer = self.RETURN_DUR
                    self.state = self.S_RETURN

            elif self.state == self.S_RETURN:
                if event.type == pygame.KEYDOWN and event.key == pygame.K_q:
                    pygame.quit(); sys.exit()

    # -------------------------------------------------
    # -------------------------------------------------
    # Debug / immediate death
    # -------------------------------------------------
    def _force_player_death(self):
        """P키 입력 시 현재 런을 즉시 종료한다."""
        if self.state != self.S_PLAYING or self.player is None:
            return
        if self.player.hp <= 0:
            return
        self.player.hp = 0
        self._game_over()

    # -------------------------------------------------
    # 필살기 발동
    # -------------------------------------------------
    def _activate_ult(self):
        """F키 입력 시 호출 - 게이지 풀 충전 시 발동"""
        if not self.player or not self.player.is_ult_ready():
            return
        if self.player.activate_ult():
            # 1. 전체 적 탄막 소거 (파티클 이펙트 생성 후 제거)
            for b in list(self.ebullets):
                self.particles.spawn_explosion(
                    b.rect.centerx, b.rect.centery,
                    (80, 240, 220), count=3, speed=3, size=2, lifetime=18)
                b.kill()
            # 2. 화면 전체 청록 플래시
            self.particles.add_flash((80, 240, 220), duration=20, alpha=100)
            # 3. 중심 확산 링
            self.particles.spawn_ult_clear(
                self.player.rect.centerx, self.player.rect.centery)
            # 4. 화면 진동
            self.shake(8, 20)

    # Player fire with rhythm judgment
    # -------------------------------------------------
    def _player_fire(self):
        judgment, dmg_mult = self.rhythm.judge(self.particles)

        # BPM 비트 간격을 프레임으로 변환
        # beat_interval(ms) / 1000 * FPS
        bpm_frames = int(self.rhythm.beat_interval / 1000 * FPS)

        # Spawn PERFECT particle ring + 필살기 게이지 충전
        if judgment == 'PERFECT':
            self.particles.spawn_perfect(
                self.player.rect.centerx, self.player.rect.centery)
            self.player.charge_ult()

        # Overbeat explosion
        if self.player.overbeat and self.rhythm.overbeat_active:
            self.particles.spawn_overbeat(
                self.player.rect.centerx, self.player.rect.centery)

        self.player.fire_all(judgment, dmg_mult, bpm_frames)

    # -------------------------------------------------
    # Update (S_PLAYING)
    # -------------------------------------------------
    def _update(self):
        self.elapsed_frames += 1
        self.elapsed_secs   += _FPS_INV
        keys = pygame.key.get_pressed()

        self.space_bg.update()
        self.rhythm.update()
        self.player.update(keys)
        self.player.emit_engine(keys)

        # 오버클럭 상태를 rhythm 엔진에 매 프레임 동기화
        self.rhythm._overclock_active = self.player.oc_active

        # Update orbit / satellite drones
        for w in self.player.weapons:
            if w.wtype == 'orbit':
                w.update_drones(self.player, self.enemies,
                                self.particles, game_kill_cb=self._kill_enemy)
            elif w.wtype == 'satellite_drone':
                w.update_drones(self.player, self.enemies,
                                self.particles, self.pbullets,
                                game_kill_cb=self._kill_enemy)

        self.enemies .update()

        # 방향 전환 버스트 처리 (Gunship)
        for e in self.enemies:   # Group은 직접 이터레이션 가능
            if e._burst_pending:
                bx, by, col = e._burst_pending
                self.particles.spawn_explosion(
                    bx, by, col, count=6, speed=4, size=3, lifetime=20)
                e._burst_pending = None

        self.pbullets.update()
        self.ebullets.update()

        if self.boss is None:
            self.spawn_manager.update(self.player.player_level)

        if self.boss:
            if self.boss.is_alive():
                self.boss.update()
                if self.boss._burst_pending:
                    bx, by, col = self.boss._burst_pending
                    self.particles.spawn_explosion(
                        bx, by, col, count=12, speed=6, size=5, lifetime=25)
                    self.boss._burst_pending = None
                if self.boss.phase_changed:
                    self.shake(12, 50)
                    self.particles.add_flash(RED,   duration=25, alpha=120)
                    self.particles.add_flash((255,80,0), duration=12, alpha=60)
                    self.rhythm.switch_to_boss_bgm()
                    # 슬로우모션 45프레임(0.75초) + PHASE 2 배너 90프레임
                    self._slowmo_timer  = 45
                    self._phase2_banner = 90
                    self.boss.phase2_just_triggered = False
            elif self.boss.dying_anim:
                self.boss.update_death_anim()
                if not self.boss.dying_anim:   # 애니메이션 완료
                    self.boss = None
                    self.spawn_manager.paused = False
                    self.rhythm.switch_to_normal_bgm()
            else:
                self.boss = None
                self.spawn_manager.paused = False
                self.rhythm.switch_to_normal_bgm()

        self._collisions()
        self._check_boss_spawn()
        self.particles.update()
        self.rhythm.overbeat_active = False   # judge() 직후 1프레임만 True
        self.syn_banners = [(n, t-1) for n, t in self.syn_banners if t > 1]

        # 충돌 루프 중 발생한 레벨업을 안전하게 처리
        if self._levelup_pending and self.state == self.S_PLAYING:
            self._trigger_levelup()

        if self.player.hp <= 0:
            self._game_over()

    # -------------------------------------------------
    # Collisions
    # -------------------------------------------------
    def _collisions(self):
        p = self.player
        # 적/투사체 목록 스냅샷
        enemy_list   = list(self.enemies)
        ebullet_list = list(self.ebullets)

        # -- Player bullets -> enemies ------------------
        hits = pygame.sprite.groupcollide(self.enemies, self.pbullets, False, False)
        for enemy, bullets in hits.items():
            if not enemy.alive(): continue
            if enemy.dying: continue   # 파괴 애니메이션 중인 적 무시
            for bullet in bullets:
                if not enemy.alive(): break
                if enemy.dying: break  # 파괴 애니메이션 중인 적 무시
                if getattr(bullet, 'explosive_radius', 0) > 0:
                    self._do_explosion(bullet.rect.centerx, bullet.rect.centery,
                                       bullet.damage, bullet.explosive_radius)
                    bullet.kill(); continue
                if bullet.piercing:
                    eid = id(enemy)
                    if eid in bullet.hit_ids: continue
                    bullet.hit_ids.add(eid)
                else:
                    bullet.kill()

                dmg  = bullet.damage
                crit = random.random() < p.crit_chance
                if crit: dmg = int(dmg * p.crit_mult)
                self.particles.add_damage(enemy.rect.centerx, enemy.rect.top-4, dmg, crit)
                if enemy.take_damage(dmg):
                    self._kill_enemy(enemy)


        # -- Player bullets -> boss ---------------------
        if self.boss and self.boss.is_alive():
            for bullet in list(self.pbullets):
                if not self.boss.rect.colliderect(bullet.rect): continue
                if getattr(bullet, 'explosive_radius', 0) > 0:
                    self._do_explosion(bullet.rect.centerx, bullet.rect.centery,
                                       bullet.damage, bullet.explosive_radius)
                    bullet.kill()
                elif bullet.piercing:
                    bid = id(self.boss)
                    if bid in bullet.hit_ids: continue
                    bullet.hit_ids.add(bid)
                else:
                    bullet.kill()
                dmg  = bullet.damage
                crit = random.random() < p.crit_chance
                if crit: dmg = int(dmg*p.crit_mult)
                self.particles.add_damage(self.boss.rect.centerx,
                                          self.boss.rect.top, dmg, crit)
                if self.boss.take_damage(dmg):
                    self._kill_boss(); break

        # -- Enemy touch -> player ----------------------
        if p.inv_timer <= 0:
            for enemy in enemy_list:
                if enemy.dying: continue   # 파괴 애니메이션 중인 적 무시
                if p.rect.colliderect(enemy.rect):
                    if p.take_damage(enemy.touch_dmg):
                        self._kill_enemy(enemy)
                        self._game_over(); return
                    self._kill_enemy(enemy)   # 체력 감소 후 즉시 소멸
                    self.shake(4,20)
                    self.particles.add_flash(RED, duration=10, alpha=60)
                    break

        # -- Enemy bullets -> player --------------------
        if p.inv_timer <= 0:
            for bullet in ebullet_list:
                if p.rect.colliderect(bullet.rect):
                    bullet.kill()
                    if p.take_damage(bullet.damage):
                        self._game_over(); return
                    self.shake(4,20)
                    self.particles.add_flash(RED, duration=10, alpha=55)
                    break

    # -------------------------------------------------
    # Explosion helper
    # -------------------------------------------------
    def _do_explosion(self, x, y, dmg, radius, chain=True):
        self.particles.spawn_explosion(x,y,ORANGE,count=14,speed=6,size=6,lifetime=35)
        self.shake(4,14)
        for enemy in self.enemies:
            d = math.hypot(enemy.rect.centerx-x, enemy.rect.centery-y)
            if d <= radius:
                splash = max(1, int(dmg*(1-d/(radius+1))))
                self.particles.add_damage(enemy.rect.centerx, enemy.rect.top, splash)
                if enemy.take_damage(splash):
                    self._kill_enemy(enemy, chain=chain)

    # -------------------------------------------------
    # Kill helpers
    # -------------------------------------------------
    def _kill_enemy(self, enemy, chain=True):
        if enemy.dying: return   # 이미 처치 처리 중이면 무시
        if self.player.kill_explode and chain:
            self._do_explosion(enemy.rect.centerx, enemy.rect.centery,
                               15, 40, chain=False)
        self.rhythm.add_score(enemy.score)
        leveled = self.player.gain_exp(enemy.exp)
        self.player.total_kills += 1
        enemy.start_death_anim()   # 파괴 애니메이션 시작 (완료 시 자동 kill)
        if leveled:
            # 충돌 루프 중일 수 있으므로 pending 플래그로 안전하게 처리
            self._levelup_pending = True

    def _kill_boss(self):
        if not self.boss: return
        self.particles.add_flash(WHITE, duration=24, alpha=110)
        self.shake(6,28)
        self.rhythm.add_score(self.boss.score)
        leveled = self.player.gain_exp(self.boss.exp)
        self.player.boss_kills += 1
        self.player.heal(35)
        self.boss.start_death_anim()   # 파괴 애니메이션 시작 (완료 후 boss = None)
        # spawn_manager / BGM 복구는 애니메이션 완료 시 _update에서 처리
        if leveled:
            # 보스 처치 직후엔 state가 안정적이므로 즉시 레벨업 처리
            self._trigger_levelup()

    # -------------------------------------------------
    # Level-up / Synergy
    # -------------------------------------------------
    def _trigger_levelup(self):
        self.particles.spawn_levelup(
            self.player.rect.centerx, self.player.rect.centery)
        self.upgrade_menu.set_cards(get_random_cards(self.player))
        self.state = self.S_UPGRADE
        self._levelup_pending = False

    def _check_synergies(self):
        for sid in check_new_synergies(self.player):
            apply_synergy(sid, self.player)
            name = SYNERGY_DISPLAY.get(sid, sid)
            self.syn_banners.append((name, 180))
            self.particles.spawn_synergy(WIDTH//2, HEIGHT//2)

    # -------------------------------------------------
    # Boss spawn (level-based)
    # -------------------------------------------------
    def _check_boss_spawn(self):
        if self.boss is not None: return
        lv = self.player.player_level
        for bl in BOSS_SPAWN_LEVELS:
            if lv >= bl and bl not in self._boss_spawned_levels:
                self._boss_spawned_levels.add(bl)
                self._start_warning()
                return
        # Repeating every 5 levels after max boss
        if lv > BOSS_SPAWN_LEVELS[-1]:
            extra_step = (lv - BOSS_SPAWN_LEVELS[-1]) // 5
            key = f'repeat_{extra_step}'
            if key not in self._boss_spawned_levels:
                self._boss_spawned_levels.add(key)
                self._start_warning()

    def _start_warning(self):
        self._warn_timer = self.WARNING_DUR
        self.spawn_manager.paused = True
        self.state = self.S_WARNING
        # 경고 연출 중에도 사용자가 설정한 BGM 볼륨 유지
        self.rhythm.set_bgm_volume(self.game_options.get('bgm_volume', 65) / 100)

    def _spawn_boss(self):
        self.boss = Boss(self.boss_index, self.player,
                         self.ebullets, self.particles)
        self.boss_index += 1
        self.shake(8,32)
        self.particles.add_flash(RED, duration=22, alpha=75)
        self.rhythm.switch_to_boss_bgm()
        self.state = self.S_PLAYING

    # -------------------------------------------------
    # Game over
    # -------------------------------------------------
    def _game_over(self):
        old_best = self.save_data['best_score']
        acc = self.rhythm.get_accuracy()
        update_best(self.save_data, self.rhythm.score,
                    self.rhythm.max_combo, acc,
                    self.player.player_level, self.player.total_kills)
        self._new_record = (self.rhythm.score > old_best)

        # -- 에테르 보상 계산 + 기록 저장 --------------
        aether_earned = calc_aether_reward(
            score     = self.rhythm.score,
            level     = self.player.player_level,
            kills     = self.player.total_kills,
            boss_kills= self.player.boss_kills,
            accuracy  = acc,
        )
        self.save_data['aether']       = self.save_data.get('aether', 0) + aether_earned
        self.save_data['total_aether'] = self.save_data.get('total_aether', 0) + aether_earned
        record_run(
            self.save_data,
            score      = self.rhythm.score,
            level      = self.player.player_level,
            kills      = self.player.total_kills,
            boss_kills = self.player.boss_kills,
            accuracy   = acc,
            char_id    = getattr(self.player, '_char_id', 'vega'),
            aether_earned = aether_earned,
        )
        self._last_aether_earned = aether_earned

        self.rhythm.stop_bgm()
        self._gameover_timer = self.GAMEOVER_DUR
        self._return_timer = self.RETURN_DUR
        self.state = self.S_OVER

    # -------------------------------------------------
    # Draw
    # -------------------------------------------------
    def _draw(self):
        surf   = self.game_surf   # 항상 800x600에 그림
        offset = self._get_offset()
        self.space_bg.draw(surf)

        if self.state in (self.S_PLAYING, self.S_UPGRADE,
                          self.S_PAUSE, self.S_WARNING, self.S_OVER, self.S_RETURN):
            self._draw_world(offset)
            self.hud.draw(surf, self.player, self.rhythm,
                          self.elapsed_secs, self.boss, self.syn_banners)
            self.rhythm.draw(surf)

        # 호버 감지용 변환 마우스 좌표
        _gmouse = self._to_game_pos(*pygame.mouse.get_pos())

        if self.state == self.S_UPGRADE:
            self.upgrade_menu.draw(surf)
        elif self.state == self.S_WARNING:
            self.warning_ui.draw(surf, self._warn_timer, self.WARNING_DUR)
        elif self.state == self.S_RETURN:
            self.warning_ui.draw(
                surf, self._return_timer, self.RETURN_DUR,
                title="격납고 귀환",
                subtitle="귀환 시퀀스 진행 중...",
                title_color=LIGHT_BLUE,
                sub_color=(170, 220, 255),
                bar_bg=(8, 24, 48),
                bar_color=LIGHT_BLUE,
                blink=True,
            )
        elif self.state == self.S_MAIN:
            self.main_menu.draw(surf, _gmouse)
        elif self.state == self.S_HUB:
            self.hub_world.draw(surf)
        elif self.state == self.S_SELECT:
            self.char_select.draw(surf, _gmouse)
        elif self.state == self.S_OPTIONS:
            self.options_ui.draw(surf, _gmouse)
        elif self.state == self.S_OVER:
            self.gameover_ui.draw(surf, self.player, self.rhythm,
                                  self.elapsed_secs, self.save_data, self._new_record,
                                  mouse_pos=_gmouse)
        elif self.state == self.S_PAUSE:
            self.pause_ui.draw(surf, self.player, self.rhythm, _gmouse)

        # -- PHASE 2 전환 배너 --------------------------
        if self._phase2_banner > 0 and self.player is not None:
            self._phase2_banner -= 1
            self._draw_phase2_banner(surf, self._phase2_banner)

        # game_surf -> screen 비율 유지 스케일 업
        sw, sh = self.screen.get_size()
        scale  = min(sw / WIDTH, sh / HEIGHT)
        new_w  = int(WIDTH  * scale)
        new_h  = int(HEIGHT * scale)
        ox     = (sw - new_w) // 2
        oy     = (sh - new_h) // 2
        # 변환 파라미터 저장 (이벤트 핸들러에서 사용)
        self._screen_ox    = ox
        self._screen_oy    = oy
        self._screen_scale = scale
        self.screen.fill((0, 0, 0))
        # 목표 크기가 이전과 같으면 smoothscale 대신 scale (약 2배 빠름)
        # 전체화면 고정 해상도에서는 거의 항상 같은 크기
        if (new_w, new_h) == (WIDTH, HEIGHT):
            self.screen.blit(surf, (ox, oy))
        else:
            scaled = pygame.transform.scale(surf, (new_w, new_h))
            self.screen.blit(scaled, (ox, oy))
        pygame.display.flip()

    def _draw_phase2_banner(self, surf, remaining):
        """보스 페이즈2 전환 배너 - 슬라이드인 후 페이드아웃"""
        MAX   = 90
        ratio = remaining / MAX
        slide = min(1.0, (MAX - remaining) / 20) if remaining > MAX - 20 else 1.0
        alpha = int(255 * min(ratio * 2.5, 1.0))

        # 폰트 캐시 (최초 1회만 생성)
        if not hasattr(self, '_p2_font_big'):
            self._p2_font_big = get_font(52, bold=True)
            self._p2_font_sub = get_font(22, bold=True)

        bar_h = sy(88)
        bar_y = int(HEIGHT // 2 - bar_h // 2 - (1 - slide) * sy(120))
        bar_s = pygame.Surface((WIDTH, bar_h), pygame.SRCALPHA)
        bar_s.fill((120, 0, 0, int(alpha * 0.65)))
        surf.blit(bar_s, (0, bar_y))
        line_s = pygame.Surface((WIDTH, 3), pygame.SRCALPHA)
        line_s.fill((255, 80, 0, int(alpha * 0.9)))
        surf.blit(line_s, (0, bar_y))
        surf.blit(line_s, (0, bar_y + bar_h - 3))

        c_main = (255, int(80 * ratio), int(80 * ratio))
        c_sub  = (255, int(160 * ratio), int(80 * ratio))

        t1 = self._p2_font_big.render("!! PHASE 2", True, c_main)
        t2 = self._p2_font_sub.render("보스가 분노했다!", True, c_sub)
        for t in (t1, t2):
            t.set_alpha(alpha)
        surf.blit(t1, (WIDTH // 2 - t1.get_width() // 2, bar_y + sy(8)))
        surf.blit(t2, (WIDTH // 2 - t2.get_width() // 2,
                       bar_y + bar_h - t2.get_height() - sy(10)))

    def _draw_world(self, offset):
        surf   = self.game_surf
        ox, oy = offset
        for b in self.pbullets:
            surf.blit(b.image,(b.rect.x-ox, b.rect.y-oy))
        for b in self.ebullets:
            surf.blit(b.image,(b.rect.x-ox, b.rect.y-oy))
        for e in self.enemies:
            e.draw(surf, offset)

        if self.boss:   # is_alive() 뿐 아니라 dying_anim 중에도 그림
            self.boss.draw(surf, offset)

        for w in self.player.weapons:
            if w.wtype in ('orbit', 'satellite_drone'):
                w.draw_drones(surf, offset)

        self.player.draw(surf, offset)
        self.particles.draw_particles(surf, offset)
        self.particles.draw_damage_numbers(surf, offset)
        self.particles.draw_flashes(surf)
        self.particles.draw_perfect_wave(surf)

    # -------------------------------------------------
    # Main loop
    # -------------------------------------------------
    def run(self):
        while True:
            self._handle_events()

            if self.state == self.S_PLAYING:
                # 슬로우모션: 2프레임마다 1번만 update (속도 절반)
                if self._slowmo_timer > 0:
                    self._slowmo_timer -= 1
                    if self._slowmo_timer % 2 == 0:
                        self._update()
                else:
                    self._update()
            elif self.state == self.S_WARNING:
                self.space_bg.update()
                self.rhythm.update()
                self._warn_timer -= 1
                if self._warn_timer <= 0:
                    self._spawn_boss()
            elif self.state == self.S_OVER:
                self.space_bg.update()
            elif self.state == self.S_RETURN:
                self.space_bg.update()
                self._return_timer -= 1
                if self._return_timer <= 0:
                    aether = getattr(self, '_last_aether_earned', 0)
                    self._enter_hub(aether_earned=aether)
            elif self.state in (self.S_MAIN, self.S_PAUSE, self.S_OPTIONS):
                self.space_bg.update()
            elif self.state == self.S_HUB:
                keys = pygame.key.get_pressed()
                self.hub_world.update(keys)
            elif self.state == self.S_UPGRADE:
                self.space_bg.update()
            elif self.state == self.S_SELECT:
                self.space_bg.update()
                self.char_select.update()

            self._draw()
            self.clock.tick(FPS)


if __name__ == '__main__':
    Game().run()
