import pygame
import math
from settings import *


class HUD:
    def __init__(self):
        self.f_sm    = get_font(17)
        self.f_hp    = get_font(12, bold=True)
        self.f_md    = get_font(21, bold=True)
        self.f_xs    = get_font(14)
        self.f_syn   = get_font(15)
        self.f_score = get_font(22, bold=True)
        self.f_score_big = get_font(30, bold=True)

        self._pulse_t   = 0
        self._score_prev    = 0
        self._score_pop     = 0
        self._score_pop_max = 16
        self._score_fonts = {s: get_font(s, bold=True) for s in range(22, 32)}
        self._banner_font = get_font(22, bold=True)
        self._phase2_surf = None
        self.f_ult        = get_font(11, bold=True)   # 필살기 게이지 레이블
        self._ult_glow_surf = None   # 풀 충전 글로우 Surface 캐시

    def draw(self, surf, player, rhythm, elapsed_secs, boss=None, syn_banners=None):
        self._pulse_t += 1
        self._hp_bar(surf, player)
        self._exp_bar(surf, player)
        self._timer(surf, elapsed_secs)
        self._score(surf, rhythm)
        self._kills(surf, player)
        self._ult_bar(surf, player)
        self._synergies(surf, player)
        if boss and boss.is_alive():
            self._boss_bar(surf, boss)
            if boss.phase == 2:
                self._phase2_pulse(surf)
        if player.overclock and player.oc_active:
            self._overclock(surf)
        if syn_banners:
            self._banners(surf, syn_banners)

    # -- HP bar (top-left) ----------------------------
    def _hp_bar(self, surf, player):
        BW, BH = sx(210), sy(22)
        x, y   = sx(10), sy(10)
        ratio  = max(0, player.hp / player.max_hp)
        pygame.draw.rect(surf, DARK_RED, (x,y,BW,BH), border_radius=4)
        if ratio > 0:
            col = GREEN if ratio>0.5 else YELLOW if ratio>0.25 else RED
            fw  = int(BW * ratio)
            pygame.draw.rect(surf, col, (x,y,fw,BH), border_radius=4)
            hi_r, hi_g, hi_b = col
            hi = (min(255,hi_r+60), min(255,hi_g+60), min(255,hi_b+60), 100)
            # Surface 재사용 (크기 변할 때만 새로 생성)
            hi_key = (fw, BH//2)
            if getattr(self, '_hp_hi_surf', None) is None or self._hp_hi_surf.get_size() != hi_key:
                self._hp_hi_surf = pygame.Surface(hi_key, pygame.SRCALPHA)
            self._hp_hi_surf.fill(hi)
            surf.blit(self._hp_hi_surf, (x, y))
        border_col = (255,60,60) if ratio < 0.25 and (self._pulse_t//10)%2==0 else GRAY
        pygame.draw.rect(surf, border_col, (x,y,BW,BH), 1, border_radius=4)
        t = self.f_hp.render(f"HP  {player.hp} / {player.max_hp}", True, WHITE)
        ty = y + (BH - t.get_height()) // 2
        surf.blit(t, (x + sx(6), ty))

    # -- EXP bar (below HP) ---------------------------
    def _exp_bar(self, surf, player):
        BW, BH = sx(210), sy(7)
        x, y   = sx(10), sy(36)
        ratio  = player.exp / player.exp_needed if player.exp_needed else 0
        pygame.draw.rect(surf, (20,20,50), (x,y,BW,BH), border_radius=3)
        if ratio > 0:
            fw = int(BW * ratio)
            pygame.draw.rect(surf, BLUE, (x,y,fw,BH), border_radius=3)
            gw = min(sx(12), fw)
            gw_key = (gw, BH)
            if getattr(self, '_exp_glow_surf', None) is None or self._exp_glow_surf.get_size() != gw_key:
                self._exp_glow_surf = pygame.Surface(gw_key, pygame.SRCALPHA)
            self._exp_glow_surf.fill((180, 220, 255, 140))
            surf.blit(self._exp_glow_surf, (x + fw - gw, y))
        pygame.draw.rect(surf, GRAY, (x,y,BW,BH), 1, border_radius=3)
        lv = self.f_xs.render(f"Lv.{player.player_level}", True, LIGHT_BLUE)
        surf.blit(lv, (x + BW + sx(14), y - sy(3)))

    # -- Timer (top-center) ---------------------------
    def _timer(self, surf, elapsed):
        m, s = int(elapsed)//60, int(elapsed)%60
        t = self.f_md.render(f"{m:02d}:{s:02d}", True, WHITE)
        surf.blit(t, (WIDTH//2 - t.get_width()//2, sy(8)))

    # -- Score ----------------------------------------
    def _score(self, surf, rhythm):
        if rhythm.score != self._score_prev:
            self._score_pop  = self._score_pop_max
            self._score_prev = rhythm.score
        if self._score_pop > 0:
            self._score_pop -= 1
            ratio = self._score_pop / self._score_pop_max
            size  = min(31, int(22 + 9 * ratio))
            f     = self._score_fonts.get(size, self.f_score)
            g_val = min(255, int(200 + 55 * ratio))
            c     = (255, g_val, 0)
            s = f.render(f"{rhythm.score:,}", True, c)
        else:
            s = self.f_score.render(f"{rhythm.score:,}", True, GOLD)
        surf.blit(s, (WIDTH//2 - s.get_width()//2, sy(34)))

    # -- Kill count (top-right) -----------------------
    def _kills(self, surf, player):
        t = self.f_sm.render(f"KILLS  {player.total_kills}", True, WHITE)
        surf.blit(t, (WIDTH - t.get_width() - sx(10), sy(10)))

    # -- Active synergies (bottom-left) ---------------
    _SYN_NAMES = {
        'chain_explosion': '연쇄 폭발',
        'homing_triple':   '유도 강화',
        'rhythm_storm':    '리듬 폭풍',
        'pulse_overdrive': '펄스 오버드라이브',
        'orbit_nova':      '오브 노바',
    }

    def _synergies(self, surf, player):
        y = HEIGHT - sy(20)
        for sid in player.active_synergies:
            t = self.f_syn.render(f"[시너지] {self._SYN_NAMES.get(sid,sid)}", True, GOLD)
            surf.blit(t, (sx(10), y)); y -= sy(20)

    # -- Boss HP bar (very bottom, full width) --------
    def _boss_bar(self, surf, boss):
        BW, BH = WIDTH - sx(40), sy(18)
        x, y   = sx(20), HEIGHT - sy(42)
        ratio  = boss.get_hp_ratio()
        pygame.draw.rect(surf, DARK_RED, (x,y,BW,BH), border_radius=4)
        if ratio > 0:
            col = RED if boss.phase==1 else (255,0,120)
            fw  = int(BW * ratio)
            pygame.draw.rect(surf, col, (x,y,fw,BH), border_radius=4)
            hi_r,hi_g,hi_b = col
            boss_hi_key = (fw, BH//2)
            if getattr(self, '_boss_hi_surf', None) is None or self._boss_hi_surf.get_size() != boss_hi_key:
                self._boss_hi_surf = pygame.Surface(boss_hi_key, pygame.SRCALPHA)
            self._boss_hi_surf.fill((min(255,hi_r+80), min(255,hi_g+40), min(255,hi_b+40), 90))
            surf.blit(self._boss_hi_surf, (x, y))
        pygame.draw.rect(surf,(200,80,80),(x,y,BW,BH),1,border_radius=4)
        name = self.f_sm.render(boss.name, True, WHITE)
        surf.blit(name,(WIDTH//2-name.get_width()//2, y - sy(20)))
        if boss.phase == 2:
            ph = self.f_xs.render("!! PHASE 2", True, (255,80,0))
            surf.blit(ph,(WIDTH//2-ph.get_width()//2, y+2))

    # -- 보스 페이즈 2 화면 가장자리 맥박 -------------
    def _phase2_pulse(self, surf):
        pulse = 0.5 + 0.5 * math.sin(self._pulse_t * 0.12)
        alpha = int(35 + 45 * pulse)
        thick = int(8 + 6 * pulse)
        if self._phase2_surf is None:
            self._phase2_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        ov = self._phase2_surf
        ov.fill((0, 0, 0, 0))
        pygame.draw.rect(ov, (220, 0, 60, alpha), (0, 0, WIDTH, HEIGHT), thick)
        surf.blit(ov, (0, 0))

    # -- 필살기 게이지 (HP 바 바로 아래) --------------
    def _ult_bar(self, surf, player):
        BW, BH = sx(210), sy(8)
        x, y   = sx(10), sy(62)   # EXP 바 아래

        ratio   = player.ult_gauge / player.ULT_MAX
        is_full = player.is_ult_ready()
        active  = player._ult_active > 0

        # 배경
        pygame.draw.rect(surf, (10, 30, 40), (x, y, BW, BH), border_radius=3)

        if ratio > 0:
            fw = int(BW * ratio)
            # 풀 충전: 밝은 청록 + 깜빡임
            if is_full or active:
                pulse = 0.6 + 0.4 * abs(math.sin(self._pulse_t * 0.15))
                col   = (int(60 * pulse), int(240 * pulse), int(200 * pulse))
            else:
                col = (30, 150, 130)
            pygame.draw.rect(surf, col, (x, y, fw, BH), border_radius=3)

            # 풀 충전 글로우 효과
            if is_full:
                gw_key = (BW + sx(6), BH + sy(6))
                if self._ult_glow_surf is None or self._ult_glow_surf.get_size() != gw_key:
                    self._ult_glow_surf = pygame.Surface(gw_key, pygame.SRCALPHA)
                self._ult_glow_surf.fill((0, 0, 0, 0))
                pulse2 = int(50 * (0.5 + 0.5 * abs(math.sin(self._pulse_t * 0.15))))
                pygame.draw.rect(self._ult_glow_surf, (80, 240, 220, pulse2),
                                 (0, 0, *gw_key), border_radius=4)
                surf.blit(self._ult_glow_surf, (x - sx(3), y - sy(3)))

        pygame.draw.rect(surf, (40, 120, 110), (x, y, BW, BH), 1, border_radius=3)

        # 레이블: 발동 가능 시 "F  PULSE NOVA" 표시, 아니면 게이지 수치
        if is_full:
            lbl = self.f_ult.render("[ F ]  PULSE NOVA", True, (80, 240, 220))
        elif active:
            remain = int(player._ult_active / 60 * 10) / 10
            lbl = self.f_ult.render(f"PULSE NOVA  {remain:.1f}s", True, (80, 240, 220))
        else:
            pct = int(ratio * 100)
            lbl = self.f_ult.render(f"PULSE NOVA  {pct}%", True, (60, 140, 120))
        surf.blit(lbl, (x, y + BH + sy(2)))

    # -- Overclock indicator ---------------------------
    def _overclock(self, surf):
        t = self.f_md.render("OVERCLOCK", True, YELLOW)
        surf.blit(t,(sx(10), HEIGHT - sy(50)))

    # -- Synergy pop-up banners (center) --------------
    def _banners(self, surf, banners):
        cy = HEIGHT//2 - sy(60)
        for name, _ in banners:
            s = self._banner_font.render(f"시너지  {name}", True, GOLD)
            surf.blit(s,(WIDTH//2-s.get_width()//2, cy)); cy += sy(30)
