import pygame
import random
import math
from settings import *
from weapon import EnemyBullet


class Boss:
    def __init__(self, index, player_ref, ebullet_group, particles):
        self.index         = index
        self.player_ref    = player_ref
        self.ebullet_group = ebullet_group
        self.particles     = particles

        data = BOSS_DATA[min(index, len(BOSS_DATA)-1)]
        extra = max(0, index-(len(BOSS_DATA)-1))
        self.max_hp       = data['hp'] + extra*350
        self.hp           = self.max_hp
        self.base_color   = data['color']
        self.phase2_color = data['phase2_color']
        self.color        = list(self.base_color)
        self.exp          = data['exp']
        self.score        = data['score']
        self.name         = (data['name'] if index < len(BOSS_DATA)
                             else f"네뷸라 갓 Mk.{extra+1}")
        self.w, self.h    = data['w'], data['h']
        self.rect         = pygame.Rect(WIDTH//2-self.w//2, -self.h, self.w, self.h)

        self.alive         = True
        self.phase         = 1
        self.phase_changed        = False
        self.phase2_just_triggered = False
        self.entering             = True
        self.target_y      = sy(50)
        self.entry_speed   = 2.5 * SY
        self.flash_timer   = 0   # 피격 플래시
        # -- 파괴 애니메이션 ----------------------------
        self.dying_anim         = False
        self._death_frames      = []
        self._death_frame_idx   = 0
        self._death_frame_timer = 0
        self._DEATH_FRAME_DUR   = 4   # 틱/프레임 (15fps, 보스용 느린 속도)

        self.move_dir   = 1
        self.move_timer = 0
        self.move_speed = 2 * SY

        self.pat_timer = 0
        self.pat_idx   = 0
        self.patterns  = self._build_patterns()
        self.spiral_a  = 0
        self._lerp_t   = 0
        # 이동 범위 사전 계산 (매 프레임 sx() 재계산 방지)
        self._move_range = sx(60) if self.index == 2 else sx(95)

        # -- 부유 진동 / 방향 전환 버스트 ------------------
        self._bob_t         = 0.0
        self._burst_pending = None

    def _build_patterns(self):
        idx = self.index
        # 보스 1: 쉬움 - 예측 가능한 기본 패턴
        if idx == 0:
            return ['aimed_burst', 'spread_bomb']
        # 보스 2: 중간 - 이동 압박 + 새 패턴
        if idx == 1:
            return ['cross_fire', 'claw_shot', 'spiral', 'charge_beam', 'ray_strike']
        # 보스 3: 어려움 - 화면 장악 + 예측 불가
        return ['orbit_ring', 'gravity_pull', 'spiral', 'laser_sweep', 'nova_burst']

    def _get_interval(self):
        """보스별 패턴 발사 간격."""
        if self.index == 0:
            return 150 if self.phase == 1 else 100
        elif self.index == 1:
            return 120 if self.phase == 1 else 80
        else:
            return 90  if self.phase == 1 else 65

    def _get_bullet_speed(self):
        """보스별 기본 총알 속도."""
        speeds = {0: 4.5, 1: 5.5, 2: 6.5}
        base = speeds.get(self.index, 5.0)
        return base * (1.3 if self.phase == 2 else 1.0)

    def take_damage(self, dmg):
        self.hp = max(0, self.hp - dmg)
        self.flash_timer = 5
        if self.hp <= 0:
            self.alive = False
            return True
        if self.phase == 1 and self.hp <= self.max_hp * 0.5:
            self.phase         = 2
            self.phase_changed = True
            self.phase2_just_triggered = True   # 슬로우모션/연출 트리거용
            # 보스별 페이즈 2 이동 속도
            self.move_speed = {0: 3.2*SY, 1: 4.0*SY, 2: 5.0*SY}.get(self.index, 3.5*SY)
            self._lerp_t    = 30
        return False

    def update(self):
        if not self.alive: return
        self.phase_changed = False

        # 부유 진동 카운터 (phase2에서 빨라짐)
        self._bob_t = (self._bob_t + (0.07 if self.phase == 2 else 0.04)) % (3.14159 * 2)

        if self.entering:
            self.rect.y = min(self.rect.y + self.entry_speed, self.target_y)
            if self.rect.y >= self.target_y:
                self.entering = False
            return

        # 페이즈 색상 전환
        if self._lerp_t > 0:
            self._lerp_t -= 1
            t = 1 - self._lerp_t / 30
            for i in range(3):
                self.color[i] = int(self.base_color[i]
                                    + (self.phase2_color[i] - self.base_color[i]) * t)

        # 이동 - 보스 3은 더 넓게 이동
        self.move_timer += 1
        if self.move_timer > self._move_range:
            # 방향 전환 버스트 - trailing side에서 역분사
            side_x = self.rect.right if self.move_dir == 1 else self.rect.x
            self._burst_pending = (
                int(side_x), int(self.rect.centery),
                tuple(int(v) for v in self.color)
            )
            self.move_dir  *= -1
            self.move_timer = 0
        self.rect.x += self.move_dir * self.move_speed
        self.rect.x  = max(20, min(WIDTH - self.w - 20, self.rect.x))

        # 피격 플래시 타이머
        if self.flash_timer > 0:
            self.flash_timer -= 1

        # 패턴 발사
        interval = self._get_interval()
        self.pat_timer += 1
        if self.pat_timer >= interval:
            self.pat_timer = 0
            self._fire(self.patterns[self.pat_idx % len(self.patterns)])
            self.pat_idx += 1

    def _fire(self, pat):
        ex, ey = self.rect.centerx, self.rect.bottom
        px, py = self.player_ref.rect.centerx, self.player_ref.rect.centery
        dx, dy = px - ex, py - ey
        spd    = self._get_bullet_speed()
        m      = 1.5 if self.phase == 2 else 1.0

        # -- 보스 1 패턴 (Kla'ed) --------------------------
        if pat == 'aimed_burst':
            for _ in range(int(3 * m)):
                sp = math.radians(random.uniform(-15, 15))
                a  = math.atan2(dy, dx) + sp
                self.ebullet_group.add(
                    EnemyBullet(ex, ey, math.cos(a)*spd, math.sin(a)*spd,
                                10, (255, 100, 100), sprite_key='e_kla_bb'))

        elif pat == 'spread_bomb':
            n = int(8 * m)
            for i in range(n):
                a = math.pi * 2 / n * i
                self.ebullet_group.add(
                    EnemyBullet(ex, ey, math.cos(a)*spd*0.9, math.sin(a)*spd*0.9,
                                8, (255, 160, 50), sprite_key='e_kla_w'))

        # -- 보스 2 전용 패턴 (Nautolan) ------------------
        elif pat == 'cross_fire':
            for a_deg in (0, 90, 180, 270):
                a = math.radians(a_deg)
                for offset_deg in (-8, 0, 8):
                    ao = a + math.radians(offset_deg)
                    self.ebullet_group.add(
                        EnemyBullet(ex, ey, math.cos(ao)*spd, math.sin(ao)*spd,
                                    11, (180, 60, 255), sprite_key='e_nau_spin'))

        elif pat == 'claw_shot':
            for side in (-1, 1):
                base_x = ex + side * self.w // 2
                spread = 45
                count  = int(5 * m)
                for i in range(count):
                    a_deg = 90 + side * (spread/2 - spread/(count-1)*i if count > 1 else 0)
                    a     = math.radians(a_deg)
                    self.ebullet_group.add(
                        EnemyBullet(base_x, ey,
                                    math.cos(a)*spd, math.sin(a)*spd,
                                    11, (100, 60, 255), sprite_key='e_nau_b'))

        elif pat == 'charge_beam':
            count = int(10 * m)
            for i in range(count):
                sp2  = math.radians(random.uniform(-6, 6))
                a    = math.atan2(dy, dx) + sp2
                v    = spd * random.uniform(0.8, 1.2)
                self.ebullet_group.add(
                    EnemyBullet(ex, ey, math.cos(a)*v, math.sin(a)*v,
                                12, (255, 80, 180), sprite_key='e_nau_rok'))

        elif pat == 'ray_strike':
            # Nautolan Ray - 좌우에서 수직 레이 교차 포격
            n   = int(5 * m)
            gap = WIDTH // (n + 1)
            for i in range(n):
                x_pos = gap * (i + 1)
                spd2  = spd * 0.9
                # 짝수는 아래서 위로, 홀수는 위에서 아래로
                vy2 = -spd2 if i % 2 == 0 else spd2
                y_start = HEIGHT if vy2 < 0 else 0
                self.ebullet_group.add(
                    EnemyBullet(x_pos, y_start, 0, vy2, 11,
                                (200, 240, 160), sprite_key='e_nau_spin'))

        elif pat == 'spiral':
            # 보스 2 -> Nautolan, 보스 3 -> Nairan
            sk   = 'e_nai_bolt' if self.index >= 2 else 'e_nau_spin'
            col  = (200, 80, 255)
            step = 24 if self.phase == 1 else 14
            for i in range(0, 360, step):
                a = math.radians(self.spiral_a + i)
                self.ebullet_group.add(
                    EnemyBullet(ex, ey, math.cos(a)*spd*0.85, math.sin(a)*spd*0.85,
                                8, col, sprite_key=sk))
            self.spiral_a = (self.spiral_a + 38) % 360

        # -- 보스 3 전용 패턴 (Nairan) ---------------------
        elif pat == 'laser_sweep':
            n = int(18 * m)
            for i in range(n):
                x = int(WIDTH / n * i + WIDTH / n / 2)
                self.ebullet_group.add(
                    EnemyBullet(x, self.rect.bottom, 0, spd, 13,
                                (255, 50, 50), sprite_key='e_nai_bolt'))

        elif pat == 'orbit_ring':
            n = int(16 * m)
            for i in range(n):
                a    = math.pi * 2 / n * i
                spd2 = 2.5
                self.ebullet_group.add(
                    EnemyBullet(ex, ey, math.cos(a)*spd2, math.sin(a)*spd2,
                                10, (80, 200, 255), sprite_key='e_nai_torp'))
            if self.phase == 2:
                n2 = 10
                for i in range(n2):
                    a    = math.pi * 2 / n2 * i + math.pi / n2
                    spd2 = 4.0
                    self.ebullet_group.add(
                        EnemyBullet(ex, ey, math.cos(a)*spd2, math.sin(a)*spd2,
                                    10, (180, 80, 255), sprite_key='e_nai_rok'))

        elif pat == 'gravity_pull':
            n = int(12 * m)
            for i in range(n):
                a = math.pi * 2 / n * i
                b = EnemyBullet(ex, ey, math.cos(a)*3.5, math.sin(a)*3.5,
                                12, (255, 220, 50), sprite_key='e_nai_torp')
                b._grav_timer  = 40
                b._grav_target = (px, py)
                b._grav_spd    = spd
                b._has_gravity = True
                self.ebullet_group.add(b)

        elif pat == 'nova_burst':
            if self.phase < 2:
                return
            for ring_spd, ring_n, ring_col, sk in [
                (3.0, 20, (100, 150, 255), 'e_nai_torp'),
                (5.0, 14, (200, 100, 255), 'e_nai_bolt'),
                (7.5, 8,  (255, 200, 100), 'e_nai_rok'),
            ]:
                for i in range(ring_n):
                    a = math.pi * 2 / ring_n * i
                    self.ebullet_group.add(
                        EnemyBullet(ex, ey,
                                    math.cos(a)*ring_spd, math.sin(a)*ring_spd,
                                    14, ring_col, sprite_key=sk))

    def draw(self, surf, offset=(0,0)):
        ox, oy = offset
        x  = self.rect.x - ox
        y  = self.rect.y - oy

        # 파괴 애니메이션 재생 중
        if not self.alive and self.dying_anim:
            n = len(self._death_frames)
            if self._death_frames and self._death_frame_idx < n:
                frame = self._death_frames[self._death_frame_idx]
                # 후반 40% 구간부터 서서히 투명해지며 소멸
                progress  = self._death_frame_idx / max(1, n - 1)
                fade_t    = max(0.0, (progress - 0.6) / 0.4)
                fade_alpha = int(255 * (1.0 - fade_t))
                if fade_alpha >= 255:
                    surf.blit(frame, (x, y))
                else:
                    tmp = frame.copy()
                    fade_surf = pygame.Surface(tmp.get_size(), pygame.SRCALPHA)
                    fade_surf.fill((255, 255, 255, fade_alpha))
                    tmp.blit(fade_surf, (0, 0),
                             special_flags=pygame.BLEND_RGBA_MULT)
                    surf.blit(tmp, (x, y))
            return
        if not self.alive:
            return

        # -- 부유 진동 오프셋 ------------------------------
        bob_amp = sy(8) if self.phase == 2 else sy(5)
        bob_y   = int(math.sin(self._bob_t) * bob_amp) if not self.entering else 0

        cx = self.rect.centerx - ox
        cy = self.rect.centery - oy + bob_y
        c  = tuple(int(v) for v in self.color)
        w, h = self.w, self.h

        img_index = min(self.index, len(IMG_BOSSES) - 1)
        sprite    = load_sprite(IMG_BOSSES[img_index], (w, h))

        if sprite:
            tinted = sprite.copy()

            # 피격 플래시 (overlay Surface 캐시 - 크기 고정이므로 1회 생성)
            if not hasattr(self, '_overlay_surf') or self._overlay_surf.get_size() != (w, h):
                self._overlay_surf = pygame.Surface((w, h), pygame.SRCALPHA)
            if self.flash_timer > 0:
                ratio = self.flash_timer / 5
                r_val = int(160 * ratio)
                self._overlay_surf.fill((r_val, 0, 0, 0))
                tinted.blit(self._overlay_surf, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
            elif self.phase == 2:
                self._overlay_surf.fill((60, 0, 0, 0))
                tinted.blit(self._overlay_surf, (0, 0), special_flags=pygame.BLEND_RGB_ADD)

            surf.blit(tinted, (x, y + bob_y))
        else:
            yb = y + bob_y
            pygame.draw.ellipse(surf, c, (x, yb+h//4, w, h//2))
            pygame.draw.rect(surf, c, (x+w//4, yb, w//2, h), border_radius=8)
            pygame.draw.polygon(surf, c, [
                (x,yb+h//2),(x-24,yb+h-8),(x+w//4,yb+h//2)])
            pygame.draw.polygon(surf, c, [
                (x+w,yb+h//2),(x+w+24,yb+h-8),(x+3*w//4,yb+h//2)])
            gem = (255,200,0) if self.phase==1 else (255,60,0)
            pygame.draw.circle(surf, gem,   (cx, cy), 12)
            pygame.draw.circle(surf, WHITE, (cx, cy), 5)

        # 페이즈 2 스파이크 이펙트
        if self.phase == 2:
            for a_deg in range(0, 360, 60):
                a = math.radians(a_deg)
                pygame.draw.line(surf, (255, 80, 0), (cx, cy),
                                 (cx+int(math.cos(a)*22), cy+int(math.sin(a)*22)), 2)

    def is_alive(self):   return self.alive
    def get_hp_ratio(self): return max(0.0, self.hp/self.max_hp)

    def start_death_anim(self):
        """보스 파괴 애니메이션 시작"""
        self.alive       = False
        self.dying_anim  = True
        self._death_frame_idx   = 0
        self._death_frame_timer = 0
        boss_key = f'boss_{min(self.index, len(BOSS_DATA)-1)}'
        self._death_frames = load_destruction_frames(boss_key)

    def update_death_anim(self):
        """파괴 애니메이션 틱 - 완료 시 dying_anim = False"""
        if not self._death_frames:
            self.dying_anim = False
            return
        self._death_frame_timer += 1
        if self._death_frame_timer >= self._DEATH_FRAME_DUR:
            self._death_frame_timer = 0
            self._death_frame_idx  += 1
        if self._death_frame_idx >= len(self._death_frames):
            self.dying_anim = False
