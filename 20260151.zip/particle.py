import pygame
import random
import math
from settings import WIDTH, HEIGHT, WHITE, YELLOW, GREEN, GOLD, get_font


class Particle:
    __slots__ = ('x', 'y', 'vx', 'vy', 'color', 'size', 'lifetime', 'max_lt', 'gravity')

    def __init__(self, x, y, vx, vy, color, size, lifetime, gravity=0.07):
        self.x, self.y   = float(x), float(y)
        self.vx, self.vy = float(vx), float(vy)
        self.color       = color
        self.size        = size
        self.lifetime    = self.max_lt = lifetime
        self.gravity     = gravity

    def update(self):
        self.x  += self.vx
        self.y  += self.vy
        self.vy += self.gravity
        self.vx *= 0.93
        self.lifetime -= 1
        return self.lifetime > 0

    def draw(self, surf, offset=(0, 0)):
        ratio = self.lifetime / self.max_lt
        r, g, b = self.color
        c  = (int(r * ratio), int(g * ratio), int(b * ratio))
        # 도트 스타일 - 원 대신 사각형 픽셀 블록
        sz = max(1, int(self.size * ratio))
        px = int(self.x - offset[0]) - sz // 2
        py = int(self.y - offset[1]) - sz // 2
        pygame.draw.rect(surf, c, (px, py, sz, sz))


class DamageNumber:
    __slots__ = ('x', 'y', 'text', 'color', 'lifetime', 'max_lt', 'vy', 'size')

    def __init__(self, x, y, value, critical=False, heal=False, judgment=None):
        self.x, self.y = float(x), float(y)
        self.lifetime  = self.max_lt = 55 if critical else 40

        if judgment == 'PERFECT':
            self.text  = f'PERFECT  {value}'
            self.color = (255, 220, 0)
            self.size  = 'lg'
        elif judgment == 'GOOD':
            self.text  = f'GOOD  {value}'
            self.color = (100, 200, 255)
            self.size  = 'md'
        elif heal:
            self.text  = f'+{value}'
            self.color = (50, 255, 80)
            self.size  = 'sm'
        elif critical:
            self.text  = str(value)
            self.color = (255, 220, 0)
            self.size  = 'lg'
        else:
            self.text  = str(value)
            self.color = WHITE
            self.size  = 'sm'

        self.vy = -1.8 if critical or judgment == 'PERFECT' else -1.1

    def update(self):
        self.y  += self.vy
        self.vy *= 0.96
        self.lifetime -= 1
        return self.lifetime > 0

    def draw(self, surf, fonts, offset=(0, 0)):
        ratio = min(1.0, self.lifetime / (self.max_lt * 0.6))
        r, g, b = self.color
        c   = (int(r * ratio), int(g * ratio), int(b * ratio))
        fnt = fonts.get(self.size, fonts['sm'])
        s   = fnt.render(self.text, True, c)
        surf.blit(s, (int(self.x - offset[0]) - s.get_width() // 2,
                      int(self.y - offset[1])))


class ScreenFlash:
    _surf_cache = {}   # size -> SRCALPHA Surface (재사용)

    def __init__(self, color, duration, alpha=70):
        self.color    = color
        self.duration = duration
        self.lifetime = duration
        self.alpha    = alpha

    def update(self):
        self.lifetime -= 1
        return self.lifetime > 0

    def draw(self, surf):
        a   = int(self.alpha * self.lifetime / self.duration)
        sz  = surf.get_size()
        if sz not in self._surf_cache:
            self._surf_cache[sz] = pygame.Surface(sz, pygame.SRCALPHA)
        s = self._surf_cache[sz]
        s.fill((*self.color, a))
        surf.blit(s, (0, 0))


class ParticleManager:
    def __init__(self):
        self.particles      = []
        self.damage_numbers = []
        self.flashes        = []
        self._fonts         = {}
        self._ready         = False

    def init_fonts(self):
        if self._ready:
            return
        self._fonts = {
            'sm': get_font(17, bold=True),
            'md': get_font(20, bold=True),
            'lg': get_font(26, bold=True),
        }
        self._ready = True

    # -- Spawn helpers --------------------------------
    def spawn_explosion(self, x, y, color, count=8, speed=4, size=4, lifetime=25):
        for _ in range(count):
            a   = random.uniform(0, math.pi * 2)
            spd = random.uniform(speed * 0.4, speed)
            self.particles.append(
                Particle(x, y, math.cos(a)*spd, math.sin(a)*spd,
                         color, random.randint(max(1,size-1), size+2),
                         random.randint(max(8,lifetime-8), lifetime+8)))

    def spawn_boss_explosion(self, x, y, color):
        self.spawn_explosion(x, y, color,         count=28, speed=9, size=8, lifetime=55)
        self.spawn_explosion(x, y, (255,240,180), count=18, speed=4, size=4, lifetime=38)

    # -- 7. 적 종류별 전용 이펙트 ---------------------
    def spawn_enemy_death(self, x, y, etype, color):
        """적 종류에 따라 다른 처치 이펙트 연출."""
        if etype == 'drone':
            # 작은 붉은 파편 + 빠른 소멸
            self.spawn_explosion(x, y, color,      count=6,  speed=3, size=3, lifetime=18)
            self.spawn_explosion(x, y, (255,80,80),count=3,  speed=5, size=2, lifetime=12)

        elif etype == 'rusher':
            # 주황 불꽃 - 진행 방향으로 늘어지는 느낌
            self.spawn_explosion(x, y, (255,140,30), count=10, speed=5, size=4, lifetime=22)
            self.spawn_explosion(x, y, (255,220,80), count=5,  speed=3, size=2, lifetime=14)
            for i in range(4):    # 아래 방향 꼬리
                vx = random.uniform(-1, 1)
                vy = random.uniform(2, 5)
                self.particles.append(
                    Particle(x, y, vx, vy, (255,160,30), 3, 20, gravity=0.05))

        elif etype == 'gunship':
            # 보라 폭발 + 원형 파편
            self.spawn_explosion(x, y, color,        count=14, speed=5, size=5, lifetime=30)
            self.spawn_explosion(x, y, (200,100,255),count=8,  speed=8, size=3, lifetime=20)
            # 원형으로 균등 방사
            for i in range(8):
                a = math.pi * 2 / 8 * i
                self.particles.append(
                    Particle(x, y, math.cos(a)*6, math.sin(a)*6,
                             (220,120,255), 4, 25, gravity=0))

        elif etype == 'splitter':
            # 사방으로 강하게 분열되는 느낌 + 빨간 파편
            self.spawn_explosion(x, y, color,       count=18, speed=7, size=5, lifetime=28)
            self.spawn_explosion(x, y, (255,60,60), count=10, speed=4, size=3, lifetime=20)
            # 4방향 집중 파편
            for a_deg in (0, 90, 180, 270):
                a = math.radians(a_deg)
                for _ in range(3):
                    spd = random.uniform(4, 9)
                    da  = random.uniform(-0.3, 0.3)
                    self.particles.append(
                        Particle(x, y,
                                 math.cos(a+da)*spd, math.sin(a+da)*spd,
                                 (255,80,50), random.randint(3,5), 22))

        elif etype == 'shieldron':
            # 파란 실드 파편 + 전기 스파크 느낌
            self.spawn_explosion(x, y, color,          count=12, speed=4, size=5, lifetime=28)
            self.spawn_explosion(x, y, (120,180,255),  count=10, speed=7, size=3, lifetime=18)
            self.spawn_explosion(x, y, (200,230,255),  count=6,  speed=2, size=2, lifetime=12)
            # 실드 파편 - 천천히 퍼지는 링
            for i in range(10):
                a = math.pi * 2 / 10 * i
                self.particles.append(
                    Particle(x, y, math.cos(a)*3, math.sin(a)*3,
                             (80,160,255), 5, 35, gravity=0))
        else:
            # 기본 폭발 (조합 무기 등 기타)
            self.spawn_explosion(x, y, color, count=8, speed=4, size=4, lifetime=25)

    def spawn_levelup(self, x, y):
        for i in range(20):
            a = math.pi * 2 / 20 * i
            self.particles.append(
                Particle(x, y, math.cos(a)*4, math.sin(a)*4,
                         (100,200,255), 5, 50, gravity=0))

    def spawn_perfect(self, x, y):
        """Golden ring burst on PERFECT judgment."""
        for i in range(16):
            a = math.pi * 2 / 16 * i
            self.particles.append(
                Particle(x, y, math.cos(a)*5, math.sin(a)*5,
                         (255,220,0), 4, 35, gravity=0))

    def spawn_perfect_wave(self, surf_size):
        """5. PERFECT 화면 가장자리 파동 이펙트."""
        self._perfect_wave = {'timer': 22, 'max': 22,
                              'size': surf_size}

    def draw_perfect_wave(self, surf):
        wave = getattr(self, '_perfect_wave', None)
        if not wave:
            return
        wave['timer'] -= 1
        if wave['timer'] <= 0:
            self._perfect_wave = None
            return
        ratio = wave['timer'] / wave['max']
        alpha = int(160 * ratio)
        thick = int(6 * ratio) + 1
        color = (255, int(220 * ratio), 0)
        w, h  = wave['size']
        inset = int((1 - ratio) * 30)
        # wave_surf 재사용 (크기 고정)
        if not hasattr(self, '_wave_surf') or self._wave_surf.get_size() != (w, h):
            self._wave_surf = pygame.Surface((w, h), pygame.SRCALPHA)
        self._wave_surf.fill((0, 0, 0, 0))
        pygame.draw.rect(self._wave_surf, (*color, alpha),
                         (inset, inset, w - inset*2, h - inset*2),
                         thick, border_radius=8)
        surf.blit(self._wave_surf, (0, 0))

    def spawn_ult_clear(self, cx, cy):
        """필살기 발동 시 플레이어 중심에서 퍼져나가는 청록 링 연출"""
        # 다중 확산 링 3개
        for radius_mul in [0.3, 0.6, 1.0]:
            self._ult_rings = getattr(self, '_ult_rings', [])
            self._ult_rings.append({
                'cx': cx, 'cy': cy,
                'r': 0,
                'max_r': int(max(WIDTH, HEIGHT) * radius_mul),
                'delay': int(radius_mul * 20),   # 시차
                'life': 40,
                'timer': 0,
            })

    def _update_ult_rings(self):
        if not hasattr(self, '_ult_rings'):
            return
        alive = []
        for ring in self._ult_rings:
            if ring['delay'] > 0:
                ring['delay'] -= 1
                alive.append(ring)
                continue
            ring['timer'] += 1
            ring['r'] = int(ring['max_r'] * (ring['timer'] / ring['life']))
            if ring['timer'] < ring['life']:
                alive.append(ring)
        self._ult_rings = alive

    def _draw_ult_rings(self, surf):
        if not hasattr(self, '_ult_rings') or not self._ult_rings:
            return
        for ring in self._ult_rings:
            if ring['delay'] > 0 or ring['r'] <= 0:
                continue
            ratio = ring['timer'] / ring['life']
            alpha = int(180 * (1.0 - ratio))
            thick = max(1, int(5 * (1.0 - ratio)))
            r     = ring['r']
            # Surface에 그리기 (알파 지원)
            diameter = r * 2 + thick * 2
            ring_s = pygame.Surface((diameter, diameter), pygame.SRCALPHA)
            pygame.draw.circle(ring_s, (80, 240, 220, alpha),
                               (diameter//2, diameter//2), r, thick)
            surf.blit(ring_s, (ring['cx'] - diameter//2, ring['cy'] - diameter//2))

    def spawn_overbeat(self, x, y):
        """Screen-wide explosion on 10x consecutive PERFECT."""
        self.spawn_explosion(WIDTH//2, HEIGHT//2,
                             (255,200,50), count=40, speed=12, size=6, lifetime=50)
        self.add_flash((255,200,0), duration=18, alpha=90)

    def spawn_synergy(self, x, y):
        for _ in range(30):
            a   = random.uniform(0, math.pi*2)
            spd = random.uniform(2, 7)
            self.particles.append(
                Particle(x, y, math.cos(a)*spd, math.sin(a)*spd,
                         (255,185,0), 4, 50, gravity=0))

    # -- Add events -----------------------------------
    def add_damage(self, x, y, value, critical=False, heal=False, judgment=None):
        self.damage_numbers.append(
            DamageNumber(x, y, value, critical, heal, judgment))

    def add_flash(self, color, duration=12, alpha=70):
        self.flashes.append(ScreenFlash(color, duration, alpha))

    # -- Update / Draw --------------------------------
    def update(self):
        # in-place 업데이트 - 리스트 재생성 대신 뒤에서 앞으로 제거
        i = len(self.particles) - 1
        while i >= 0:
            if not self.particles[i].update():
                self.particles.pop(i)
            i -= 1

        i = len(self.damage_numbers) - 1
        while i >= 0:
            if not self.damage_numbers[i].update():
                self.damage_numbers.pop(i)
            i -= 1

        i = len(self.flashes) - 1
        while i >= 0:
            if not self.flashes[i].update():
                self.flashes.pop(i)
            i -= 1

        self._update_ult_rings()

    def draw_particles(self, surf, offset=(0,0)):
        for p in self.particles:
            p.draw(surf, offset)

    def draw_damage_numbers(self, surf, offset=(0,0)):
        for d in self.damage_numbers:
            d.draw(surf, self._fonts, offset)

    def draw_flashes(self, surf):
        for f in self.flashes:
            f.draw(surf)
        self._draw_ult_rings(surf)
