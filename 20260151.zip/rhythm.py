import pygame
from settings import (BPM_NORMAL, BPM_BOSS, PERFECT_MS, GOOD_MS,
                      COLOR_PERFECT, COLOR_GOOD, COLOR_MISS,
                      BGM_NORMAL, BGM_BOSS, BGM_HUB, get_font,
                      WIDTH, HEIGHT, WHITE, GOLD, GRAY, PURPLE,
                      sx, sy)


class RhythmEngine:
    """
    BPM-fixed metronome rhythm judgment engine.
    Tracks the beat clock independently from game frames
    so that judgment accuracy is not affected by frame rate.
    """

    JUDGMENT_NONE    = 'none'
    JUDGMENT_PERFECT = 'PERFECT'
    JUDGMENT_GOOD    = 'GOOD'
    JUDGMENT_FAST    = 'FAST'
    JUDGMENT_SLOW    = 'SLOW'

    # Combo thresholds -> score multiplier
    COMBO_TIERS = [(30, 3.0), (20, 2.0), (10, 1.5), (0, 1.0)]

    def __init__(self):
        self.bpm           = BPM_NORMAL
        self.beat_interval = 60_000 / self.bpm   # ms per beat
        self.beat_start_ms = 0                    # time of first beat
        self.active        = False

        # Judgment state
        self.last_judgment    = self.JUDGMENT_NONE
        self.judgment_display = self.JUDGMENT_NONE
        self.judgment_timer   = 0                 # frames to show result
        self.JUDGMENT_DUR     = 30                # frames

        # Combo
        self.combo     = 0
        self.max_combo = 0

        # Accuracy tracking
        self.total_shots   = 0
        self.perfect_shots = 0
        self.good_shots    = 0

        # Score
        self.score = 0

        # Rhythm upgrade flags
        self.perfect_window_bonus = 0   # extra ms from upgrades
        self.char_perf_bonus      = 0.0 # 캐릭터 고유 PERFECT 데미지 보너스
        self.overbeat_count       = 0   # consecutive PERFECTs
        self.overbeat_active      = False
        self.rhythm_overload      = False   # high combo damage bonus
        self._combo_boost         = False   # combo_boost 업그레이드 연동
        self._overclock_active    = False   # 오버클럭 활성 상태 (player에서 동기화)

        # BGM
        self._bgm_mode = 'normal'
        self._bgm_volume = 0.65
        self._fonts_ready = False

    # -- Font init -------------------------------------
    def _init_fonts(self):
        if self._fonts_ready:
            return
        self.f_judgment = get_font(32, bold=True)
        self.f_combo    = get_font(22, bold=True)
        self.f_score    = get_font(20)
        self._fonts_ready = True

    # -- BGM control -----------------------------------
    def set_bgm_volume(self, volume):
        """Persist user-configured BGM volume so track switches keep the same level."""
        try:
            vol = max(0.0, min(1.0, float(volume)))
        except (TypeError, ValueError):
            return
        self._bgm_volume = vol
        try:
            pygame.mixer.music.set_volume(self._bgm_volume)
        except Exception:
            pass

    def _load_and_play_bgm(self, path, error_label):
        try:
            pygame.mixer.music.load(path)
            pygame.mixer.music.set_volume(self._bgm_volume)
            pygame.mixer.music.play(-1)   # loop forever
        except Exception as e:
            print(f'[BGM] {error_label}: {e}')

    def start_bgm(self, mode='normal'):
        self._bgm_mode = mode
        if mode == 'boss':
            path = BGM_BOSS
            self.bpm = BPM_BOSS
        elif mode == 'hub':
            path = BGM_HUB
            self.bpm = BPM_NORMAL
        else:
            path = BGM_NORMAL
            self.bpm = BPM_NORMAL
        self.beat_interval = 60_000 / self.bpm
        self._load_and_play_bgm(path, '로드 실패')
        self._sync_beat()

    def switch_to_boss_bgm(self):
        if self._bgm_mode == 'boss':
            return
        self._bgm_mode = 'boss'
        self.bpm = BPM_BOSS
        self.beat_interval = 60_000 / self.bpm
        self._load_and_play_bgm(BGM_BOSS, '보스 BGM 실패')
        self._sync_beat()

    def switch_to_normal_bgm(self):
        if self._bgm_mode == 'normal':
            return
        self._bgm_mode = 'normal'
        self.bpm = BPM_NORMAL
        self.beat_interval = 60_000 / self.bpm
        self._load_and_play_bgm(BGM_NORMAL, '일반 BGM 실패')
        self._sync_beat()

    def switch_to_hub_bgm(self):
        if self._bgm_mode == 'hub':
            return
        self._bgm_mode = 'hub'
        # 허브 음악도 옵션의 BGM 볼륨을 그대로 사용
        self.bpm = BPM_NORMAL
        self.beat_interval = 60_000 / self.bpm
        self._load_and_play_bgm(BGM_HUB, '허브 BGM 실패')
        self._sync_beat()

    def stop_bgm(self):
        pygame.mixer.music.stop()

    def _sync_beat(self):
        """Align beat clock to current time, compensating for audio latency."""
        # 3. 오디오 레이턴시 보정 - pygame mixer 버퍼 + 시스템 레이턴시
        # beat_start_ms를 AUDIO_OFFSET_MS만큼 뒤로 당겨서 박자를 음악에 맞춤
        AUDIO_OFFSET_MS = 80   # 조절 가능 (50~150ms 범위)
        self.beat_start_ms = pygame.time.get_ticks() - AUDIO_OFFSET_MS
        self.active = True

    # -- Beat calculation ------------------------------
    def _ms_to_nearest_beat(self):
        """Return (offset_ms, is_fast).
        offset_ms: distance to nearest beat in ms.
        is_fast: True = 박자보다 빠름(앞당김), False = 느림(늦음).
        """
        now     = pygame.time.get_ticks()
        elapsed = (now - self.beat_start_ms) % self.beat_interval
        if elapsed <= self.beat_interval / 2:
            # 직전 박자 이후 -> 늦게 누름 (SLOW)
            return elapsed, False
        else:
            # 다음 박자 전 -> 빠르게 누름 (FAST)
            return self.beat_interval - elapsed, True

    def get_beat_ratio(self):
        """0.0 = just on beat, 1.0 = halfway between beats (for UI pulse)."""
        now     = pygame.time.get_ticks()
        elapsed = (now - self.beat_start_ms) % self.beat_interval
        return elapsed / self.beat_interval

    # -- Judgment --------------------------------------
    def judge(self, particles=None):
        """
        Call this when the player fires.
        Returns (judgment_str, damage_multiplier).
        """
        if not self.active:
            return self.JUDGMENT_NONE, 1.0

        self.total_shots += 1
        offset, is_fast  = self._ms_to_nearest_beat()

        perfect_window = PERFECT_MS + self.perfect_window_bonus
        good_window    = GOOD_MS    + self.perfect_window_bonus

        if offset <= perfect_window:
            judgment = self.JUDGMENT_PERFECT
            dmg_mult = 2.0 + self.char_perf_bonus
            self.combo += 1
            self.max_combo = max(self.max_combo, self.combo)
            self.perfect_shots += 1
            self.score += int(20 * self._score_mult())
            self.overbeat_count += 1
            if self.overbeat_count >= 10 and particles:
                self.overbeat_active = True
                self.overbeat_count  = 0

        elif offset <= good_window:
            judgment = self.JUDGMENT_GOOD
            dmg_mult = 1.0
            # 오버클럭 활성 시 GOOD -> PERFECT 승격
            if self._overclock_active:
                judgment = self.JUDGMENT_PERFECT
                dmg_mult = 2.0 + self.char_perf_bonus
                self.perfect_shots += 1   # 정확도 통계에 PERFECT로 반영
                self.score += int(20 * self._score_mult())
                self.overbeat_count += 1
                if self.overbeat_count >= 10 and particles:
                    self.overbeat_active = True
                    self.overbeat_count  = 0
            else:
                self.good_shots += 1
                self.score += int(5 * self._score_mult())
                self.overbeat_count = 0
            self.combo += 1
            self.max_combo = max(self.max_combo, self.combo)

        else:
            # FAST / SLOW - 데미지 0.4배, 콤보 초기화 (콤보 부스트 시 30% 유지)
            judgment = self.JUDGMENT_FAST if is_fast else self.JUDGMENT_SLOW
            dmg_mult = 0.4
            if self._combo_boost:
                self.combo = int(self.combo * 0.3)
            else:
                self.combo = 0
            self.overbeat_count = 0

        # Rhythm overload bonus (combo 30+)
        if self.rhythm_overload and self.combo >= 30:
            dmg_mult *= 1.5

        self.last_judgment    = judgment
        self.judgment_display = judgment
        self.judgment_timer   = self.JUDGMENT_DUR
        return judgment, dmg_mult

    def _score_mult(self):
        for threshold, mult in self.COMBO_TIERS:
            if self.combo >= threshold:
                return mult
        return 1.0

    def add_score(self, base):
        self.score += int(base * self._score_mult())

    # -- Update ----------------------------------------
    def update(self):
        if self.judgment_timer > 0:
            self.judgment_timer -= 1
            if self.judgment_timer == 0:
                self.judgment_display = self.JUDGMENT_NONE
        # overbeat_active는 judge() 에서 set, 외부(_update)에서 처리 후 초기화

    # -- Accuracy --------------------------------------
    def get_accuracy(self):
        if self.total_shots == 0:
            return 0.0
        return self.perfect_shots / self.total_shots * 100

    # -- Draw ------------------------------------------
    def draw(self, surf):
        self._init_fonts()
        # 2. 비트 펄스 인디케이터 삭제
        self._draw_judgment(surf)
        self._draw_combo(surf)

    def _draw_judgment(self, surf):
        if self.judgment_display == self.JUDGMENT_NONE:
            return
        ratio = self.judgment_timer / self.JUDGMENT_DUR
        color_map = {
            self.JUDGMENT_PERFECT: COLOR_PERFECT,
            self.JUDGMENT_GOOD:    COLOR_GOOD,
            self.JUDGMENT_FAST:    (255, 140,  40),   # 주황
            self.JUDGMENT_SLOW:    (140, 140, 255),   # 연보라
        }
        c  = color_map.get(self.judgment_display, WHITE)
        cr = tuple(int(v * ratio) for v in c)
        s  = self.f_judgment.render(self.judgment_display, True, cr)
        y_off = int((1 - ratio) * 20)
        surf.blit(s, (WIDTH // 2 - s.get_width() // 2,
                      HEIGHT // 2 - sy(120) - y_off))

    def _draw_combo(self, surf):
        if self.combo < 2:
            return
        mult = self._score_mult()
        # Color gets warmer as combo grows
        if self.combo >= 30:
            color = GOLD
        elif self.combo >= 20:
            color = (255, 160, 50)
        elif self.combo >= 10:
            color = (100, 220, 255)
        else:
            color = WHITE
        s = self.f_combo.render(f"{self.combo} COMBO  x{mult:.1f}", True, color)
        surf.blit(s, (WIDTH // 2 - s.get_width() // 2,
                      HEIGHT // 2 - sy(82)))
