import pygame
import random
import math
from settings import *
from weapon import EnemyBullet


class Enemy(pygame.sprite.Sprite):
    def __init__(self, etype, player_ref, ebullet_group, hp_scale=1.0):
        super().__init__()
        self.etype         = etype
        self.player_ref    = player_ref
        self.ebullet_group = ebullet_group

        s = ENEMY_STATS[etype]
        self.max_hp    = int(s['hp'] * hp_scale)
        self.hp        = self.max_hp
        self.speed     = s['speed']
        self.exp       = s['exp']
        self.touch_dmg = s['touch_dmg']
        self.score     = s['score']
        self.base_color = s['color']
        self.color     = self.base_color
        self.shoots    = s['shoots']
        self.w, self.h = s['w'], s['h']

        x = random.randint(4, WIDTH - self.w - 4)
        self.image = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
        self.rect  = self.image.get_rect(topleft=(x, -self.h - 4))

        # 적 타입별 발사 간격 (FPS 60 기준)
        _shoot_ranges = {
            'gunship':   (108, 162),   # 1.8~2.7초 - 기본 사격
            'splitter':  (162, 222),   # 2.7~3.7초 - 3방향이라 간격 넉넉히
            'shieldron': ( 78, 108),   # 1.3~1.8초 - 정밀 저격, 빠름
        }
        lo, hi = _shoot_ranges.get(etype, (108, 162))
        self.shoot_cd    = random.randint(lo, hi)
        self.shoot_timer = random.randint(lo // 2, self.shoot_cd)
        self.move_dir    = random.choice([-1, 1])
        self.move_timer  = 0
        self.flash_timer = 0
        self._overlay_cache = {}   # (w, h, r_val) -> Surface 캐시
        # -- 파괴 애니메이션 ----------------------------
        self.dying              = False
        self._death_frames      = []
        self._death_frame_idx   = 0
        self._death_frame_timer = 0
        self._DEATH_FRAME_DUR   = 3   # 틱/프레임 (20fps)
        # 방향 전환 버스트 플래그 (main.py에서 파티클 생성)
        self._burst_pending = None

        self._draw_shape()

    def _draw_shape(self):
        self.image.fill((0, 0, 0, 0))

        sprite = load_sprite(IMG_ENEMIES.get(self.etype), (self.w, self.h))
        if sprite:
            if self.flash_timer > 0:
                # 피격 플래시: BLEND_RGB_ADD - 알파 유지, 빨간 네모 없음
                tinted = sprite.copy()
                ratio  = self.flash_timer / 4
                r_val  = int(180 * ratio)
                # overlay Surface 캐시 - 매 프레임 새로 생성하지 않음
                cache_key = r_val
                if cache_key not in self._overlay_cache:
                    ov = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
                    ov.fill((r_val, r_val, r_val, 0))
                    self._overlay_cache[cache_key] = ov
                tinted.blit(self._overlay_cache[cache_key], (0, 0),
                            special_flags=pygame.BLEND_RGB_ADD)
                self.image.blit(tinted, (0, 0))
            else:
                self.image.blit(sprite, (0, 0))
            return

        # 도형 폴백
        cx, cy = self.w // 2, self.h // 2
        c = self.color
        if self.etype == 'drone':
            pygame.draw.polygon(self.image, c, [
                (cx, self.h), (0,2), (cx, self.h//4), (self.w,2)])
            pygame.draw.circle(self.image, WHITE, (cx, cy), 3)
        elif self.etype == 'rusher':
            pygame.draw.polygon(self.image, c, [
                (cx, self.h), (0,4), (cx, self.h//3), (self.w,4)])
            pygame.draw.polygon(self.image, (255,140,0), [
                (cx-4,self.h),(cx-2,self.h//2),(cx+2,self.h//2),(cx+4,self.h)])
        elif self.etype == 'gunship':
            pygame.draw.ellipse(self.image, c,
                                (0, self.h//4, self.w, self.h//2))
            pygame.draw.rect(self.image, c, (cx-4, 0, 8, self.h))
            pygame.draw.circle(self.image, (255,80,80), (cx, cy), 6)
        elif self.etype == 'splitter':
            pygame.draw.polygon(self.image, c, [
                (cx, self.h),(0,2),(cx//2,self.h//2),
                (cx,2),(cx+cx//2,self.h//2),(self.w,2)])
        elif self.etype == 'shieldron':
            pygame.draw.rect(self.image, c,
                             (self.w//4, self.h//4, self.w//2, self.h//2),
                             border_radius=4)
            pygame.draw.arc(self.image, (100,160,255),
                            (2,2,self.w-4,self.h//2), 0, math.pi, 3)

    def take_damage(self, dmg):
        if self.dying: return False
        self.hp -= dmg
        self.flash_timer = 4
        # _draw_shape은 update()에서 flash_timer 변화 시 처리 (중복 호출 방지)
        return self.hp <= 0

    def _shoot(self):
        ex, ey = self.rect.centerx, self.rect.bottom
        px, py = self.player_ref.rect.centerx, self.player_ref.rect.centery
        dx, dy = px-ex, py-ey
        dist   = max(1, math.hypot(dx,dy))
        spd    = 4.5

        if self.etype == 'gunship':
            self.ebullet_group.add(
                EnemyBullet(ex,ey, dx/dist*spd, dy/dist*spd, 8,
                            sprite_key='e_nau_bomb'))
        elif self.etype == 'splitter':
            for off in (-30,0,30):
                a = math.atan2(dy,dx)+math.radians(off)
                self.ebullet_group.add(
                    EnemyBullet(ex,ey, math.cos(a)*spd, math.sin(a)*spd, 6,
                                sprite_key='e_kla_w'))
        elif self.etype == 'shieldron':
            self.ebullet_group.add(
                EnemyBullet(ex,ey, dx/dist*(spd+1), dy/dist*(spd+1),
                            10, (100,160,255), sprite_key='e_nai_bolt'))

    def update(self):
        if self.dying:
            self._update_death()
            return

        # 플래시 타이머가 변화할 때만 이미지 재드로우
        prev_flash = self.flash_timer
        if self.flash_timer > 0:
            self.flash_timer -= 1
            self.color = (255,255,255)
        else:
            self.color = self.base_color

        if self.flash_timer != prev_flash:
            self._draw_shape()   # 플래시 상태 변화 시만 재그리기

        if self.etype == 'drone':
            self.rect.y += self.speed
        elif self.etype == 'rusher':
            px, py = self.player_ref.rect.centerx, self.player_ref.rect.centery
            dx, dy = px-self.rect.centerx, py-self.rect.centery
            dist   = max(1, math.hypot(dx,dy))
            self.rect.x += dx/dist*self.speed
            self.rect.y += dy/dist*self.speed
        elif self.etype == 'gunship':
            self.move_timer += 1
            if self.move_timer > 85:
                # 방향 전환 버스트 - 역분사 방향(trailing side)
                side_x = self.rect.right if self.move_dir == 1 else self.rect.x
                self._burst_pending = (int(side_x), int(self.rect.centery), self.base_color)
                self.move_dir  *= -1
                self.move_timer = 0
            self.rect.x += self.move_dir*self.speed
            self.rect.y += 0.30
            self.rect.x  = max(0, min(WIDTH-self.w, self.rect.x))
        elif self.etype == 'splitter':
            self.rect.y += self.speed
        elif self.etype == 'shieldron':
            self.rect.y += self.speed*0.7

        if self.shoots:
            self.shoot_timer -= 1
            if self.shoot_timer <= 0:
                self._shoot()
                self.shoot_timer = self.shoot_cd   # 반드시 양수로 리셋

        if self.rect.top > HEIGHT + 20:
            self.kill()

    def draw(self, surf, offset=(0, 0)):
        """잔상 -> 스프라이트 -> HP바 순으로 렌더링."""
        ox, oy = offset

        # -- 스프라이트 ------------------------------------
        surf.blit(self.image, (self.rect.x - ox, self.rect.y - oy))

        # -- HP 바 -----------------------------------------
        if not self.dying and self.hp < self.max_hp:
            bw    = self.w
            bx    = self.rect.x - ox
            by    = self.rect.top - oy - 6
            ratio = self.hp / self.max_hp
            pygame.draw.rect(surf, DARK_RED, (bx, by, bw, 4))
            pygame.draw.rect(surf, GREEN,    (bx, by, int(bw * ratio), 4))

    def start_death_anim(self):
        """파괴 애니메이션 시작 - 이미지를 death frame 크기로 교체"""
        self.dying       = True
        self.flash_timer = 0
        self._death_frame_idx   = 0
        self._death_frame_timer = 0
        self._death_frames = load_destruction_frames(self.etype)
        if self._death_frames:
            gs     = DESTROY_GAME_SIZE.get(self.etype, 64)
            center = self.rect.center
            self.image = pygame.Surface((gs, gs), pygame.SRCALPHA)
            self.rect  = self.image.get_rect(center=center)

    def _update_death(self):
        """파괴 애니메이션 틱 - 완료 시 그룹에서 제거"""
        if not self._death_frames:
            self.kill()
            return
        self._death_frame_timer += 1
        if self._death_frame_timer >= self._DEATH_FRAME_DUR:
            self._death_frame_timer = 0
            self._death_frame_idx  += 1
        if self._death_frame_idx >= len(self._death_frames):
            self.kill()
            return
        n = len(self._death_frames)
        # 후반 40% 구간부터 서서히 투명해지며 소멸
        progress  = self._death_frame_idx / max(1, n - 1)
        fade_t    = max(0.0, (progress - 0.6) / 0.4)
        fade_alpha = int(255 * (1.0 - fade_t))
        frame = self._death_frames[self._death_frame_idx]
        self.image.fill((0, 0, 0, 0))
        self.image.blit(frame, (0, 0))
        if fade_alpha < 255:
            # fade_surf 캐시 - 매 프레임 재생성 방지
            sz = self.image.get_size()
            if not hasattr(self, '_fade_surf') or self._fade_surf.get_size() != sz:
                self._fade_surf = pygame.Surface(sz, pygame.SRCALPHA)
            self._fade_surf.fill((255, 255, 255, fade_alpha))
            self.image.blit(self._fade_surf, (0, 0),
                            special_flags=pygame.BLEND_RGBA_MULT)


class SpawnManager:
    def __init__(self, player_ref, enemy_group, ebullet_group):
        self.player_ref    = player_ref
        self.enemy_group   = enemy_group
        self.ebullet_group = ebullet_group
        self.timer  = 0
        self.paused = False
        # 난이도 배율 (main.py의 _start_game 에서 설정)
        self.difficulty_hp_mul  = 1.0
        self.difficulty_spd_mul = 1.0

    def update(self, player_level):
        if self.paused:
            return
        self.timer += 1
        # 하드 모드: 스폰 간격 15% 감소 (더 빠른 스폰)
        interval = get_spawn_interval(player_level)
        if self.difficulty_spd_mul > 1.0:
            interval = int(interval / self.difficulty_spd_mul)
        if self.timer >= interval:
            self.timer = 0
            self._spawn(player_level)

    def _spawn(self, level):
        weights  = get_enemy_weights(level)
        hp_scale = get_hp_scale(level) * self.difficulty_hp_mul
        etype    = random.choices(list(weights.keys()),
                                  weights=list(weights.values()))[0]
        e = Enemy(etype, self.player_ref, self.ebullet_group, hp_scale)
        # 속도도 난이도에 맞게 보정
        e.speed = e.speed * self.difficulty_spd_mul
        self.enemy_group.add(e)
