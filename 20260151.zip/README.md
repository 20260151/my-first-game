# PULSE DRIVE

리듬에 맞춰 싸울수록 강해지는 로그라이크 우주 슈팅 게임

## 실행 방법
```bash
pip install pygame
python main.py
```

## 조작법
| 키 | 동작 |
|---|---|
| ← → ↑ ↓ | 이동 |
| SPACE | 발사 (리듬 판정 동시 적용) |
| ESC | 일시 정지 |
| 1 / 2 / 3 | 업그레이드 선택 |
| R | 재굴림 |
| Q | 메인 메뉴 (일시 정지 중) |

## 리듬 시스템
| 판정 | 오차 | 효과 |
|------|------|------|
| PERFECT | ±80ms | 데미지 2배 + 콤보 + 점수 +20 |
| GOOD | ±150ms | 데미지 1.3배 |
| MISS | 그 외 | 기본 데미지, 콤보 초기화 |

## BGM
- `assets/bgm_normal.mp3` — 일반 스테이지 (128 BPM)
- `assets/bgm_boss.mp3`   — 보스전 (160 BPM)

## 파일 구조
| 파일 | 역할 |
|---|---|
| settings.py | 전역 상수, 스탯, BGM 경로 |
| rhythm.py | 리듬 판정 엔진, 콤보, BGM 전환 |
| save.py | JSON 하이스코어 저장/로드 |
| particle.py | 파티클, 데미지 팝업, 화면 플래시 |
| weapon.py | 6종 무기 (Orbit Drone 포함) |
| enemy.py | 5종 적, 스폰 매니저 |
| boss.py | 보스 클래스, 페이즈 전환 |
| upgrade.py | 업그레이드 풀, 리듬 업그레이드, 시너지 |
| player.py | 플레이어 클래스 |
| hud.py | 인게임 HUD |
| ui.py | 메인 메뉴, 게임오버, 일시 정지 |
| main.py | 게임 루프, 충돌 처리 |
