import json, os

SAVE_FILE = 'pulse_drive_save.json'
DEFAULT = {
    'best_score':    0,
    'best_combo':    0,
    'best_accuracy': 0.0,
    'best_level':    0,
    'best_kills':    0,
    'total_runs':    0,
}

# -- 게임 옵션 ----------------------------------------
OPTIONS_FILE = 'pulse_drive_options.json'
DEFAULT_OPTIONS = {
    'bgm_volume':  65,       # 0~100
    'sfx_volume':  80,       # 0~100
    'difficulty':  'normal', # 'easy' | 'normal' | 'hard'
    'fullscreen':  False,
}

def load():
    if os.path.exists(SAVE_FILE):
        try:
            with open(SAVE_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
            for k, v in DEFAULT.items():
                data.setdefault(k, v)
            return data
        except Exception:
            pass
    return dict(DEFAULT)

def save(data):
    try:
        with open(SAVE_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f'[save] 저장 실패: {e}')

def update_best(data, score, combo, accuracy, level, kills):
    data['best_score']    = max(data['best_score'],    score)
    data['best_combo']    = max(data['best_combo'],    combo)
    data['best_accuracy'] = max(data['best_accuracy'], accuracy)
    data['best_level']    = max(data['best_level'],    level)
    data['best_kills']    = max(data['best_kills'],    kills)
    data['total_runs']    = data.get('total_runs', 0) + 1
    save(data)

# -- 옵션 저장/로드 ------------------------------------
def load_options():
    if os.path.exists(OPTIONS_FILE):
        try:
            with open(OPTIONS_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
            for k, v in DEFAULT_OPTIONS.items():
                data.setdefault(k, v)
            # 게임 시작 시 항상 창 모드로 시작
            # (전체화면은 옵션 창에서 직접 설정하도록)
            data['fullscreen'] = False
            return data
        except Exception:
            pass
    return dict(DEFAULT_OPTIONS)

def save_options(data):
    try:
        with open(OPTIONS_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f'[save_options] 저장 실패: {e}')


# -- 영구 진행 데이터 ---------------------------------
PROGRESS_DEFAULTS = {
    'aether':          0,       # 보유 에테르 (영구 화폐)
    'total_aether':    0,       # 총 획득 에테르 누적
    'mirror_upgrades': {},      # 거울 강화 레벨 {'mirror_hp': 2, ...}
    'unlocked_chars':  ['vega'], # 해금된 캐릭터
    'run_history':     [],      # 최근 런 기록 (최대 10개)
}

def load_progress(save_data: dict) -> dict:
    """save_data에 progress 필드가 없으면 기본값으로 채운다."""
    for k, v in PROGRESS_DEFAULTS.items():
        if k not in save_data:
            import copy
            save_data[k] = copy.deepcopy(v)
    return save_data

def calc_aether_reward(score, level, kills, boss_kills, accuracy) -> int:
    base        = max(5, level * 3)
    boss_bonus  = boss_kills * 15
    kill_bonus  = kills // 10
    score_bonus = score // 500
    acc_bonus   = int(accuracy * 10)
    return max(5, base + boss_bonus + kill_bonus + score_bonus + acc_bonus)

def record_run(save_data, score, level, kills, boss_kills, accuracy,
               char_id, aether_earned):
    entry = {
        'score': score, 'level': level, 'kills': kills,
        'boss_kills': boss_kills, 'accuracy': round(accuracy, 1),
        'char': char_id, 'aether': aether_earned,
    }
    hist = save_data.get('run_history', [])
    hist.insert(0, entry)
    save_data['run_history'] = hist[:10]
