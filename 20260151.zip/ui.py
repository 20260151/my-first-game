import math
import pygame
from settings import *


class MainMenu:
    def __init__(self, save_data):
        self.save_data = save_data
        self.f_title  = get_font(78, bold=True)
        self.f_start  = get_font(22, bold=True)
        self.f_opt    = get_font(18)

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_SPACE, pygame.K_RETURN):
                return 'start'
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mx, my = event.pos
            if self._start_rect().collidepoint(mx, my):
                return 'start'
            if self._options_rect().collidepoint(mx, my):
                return 'options'
            if self._exit_rect().collidepoint(mx, my):
                return 'exit'
        return None

    def _start_rect(self):
        cx = WIDTH // 2
        cy = HEIGHT // 2 + sy(40)
        return pygame.Rect(cx - sx(130), cy, sx(260), sy(56))

    def _options_rect(self):
        cx = WIDTH // 2
        cy = HEIGHT // 2 + sy(120)
        return pygame.Rect(cx - sx(90), cy, sx(180), sy(44))

    def _exit_rect(self):
        cx = WIDTH // 2
        cy = HEIGHT // 2 + sy(190)
        return pygame.Rect(cx - sx(70), cy, sx(140), sy(36))

    def draw(self, surf, mouse_pos=None):
        mx, my = mouse_pos if mouse_pos else pygame.mouse.get_pos()

        # 타이틀
        t = self.f_title.render("PULSE DRIVE", True, LIGHT_BLUE)
        ty = HEIGHT // 2 - sy(110)
        surf.blit(t, (WIDTH // 2 - t.get_width() // 2, ty))

        # 타이틀 아래 얇은 구분선
        lw = sx(260)
        lx = WIDTH // 2 - lw // 2
        pygame.draw.line(surf, (60, 100, 160),
                         (lx, ty + t.get_height() + sy(10)),
                         (lx + lw, ty + t.get_height() + sy(10)), 1)

        # START 버튼
        r_start   = self._start_rect()
        hov_start = r_start.collidepoint(mx, my)
        scol = (80, 180, 255) if hov_start else (40, 120, 220)
        pygame.draw.rect(surf, scol, r_start, border_radius=10)
        pygame.draw.rect(surf, (160, 210, 255) if hov_start else (100, 160, 255),
                         r_start, 2, border_radius=10)
        st = self.f_start.render("START", True, WHITE)
        surf.blit(st, (r_start.centerx - st.get_width() // 2,
                       r_start.centery - st.get_height() // 2))

        # OPTIONS 버튼
        r_opt   = self._options_rect()
        hov_opt = r_opt.collidepoint(mx, my)
        ocol = (65, 65, 105) if hov_opt else (38, 38, 72)
        pygame.draw.rect(surf, ocol, r_opt, border_radius=8)
        pygame.draw.rect(surf, (130, 130, 175) if hov_opt else (90, 90, 140),
                         r_opt, 2, border_radius=8)
        ot = self.f_opt.render("OPTIONS", True,
                               (210, 210, 240) if hov_opt else (160, 160, 210))
        surf.blit(ot, (r_opt.centerx - ot.get_width() // 2,
                       r_opt.centery - ot.get_height() // 2))

        # EXIT GAME 버튼
        r_exit   = self._exit_rect()
        hov_exit = r_exit.collidepoint(mx, my)
        ecol = (90, 30, 30) if hov_exit else (50, 18, 18)
        pygame.draw.rect(surf, ecol, r_exit, border_radius=6)
        pygame.draw.rect(surf, (160, 60, 60) if hov_exit else (100, 40, 40),
                         r_exit, 1, border_radius=6)
        et = self.f_opt.render("EXIT GAME", True,
                               (255, 140, 140) if hov_exit else (180, 90, 90))
        surf.blit(et, (r_exit.centerx - et.get_width() // 2,
                       r_exit.centery - et.get_height() // 2))


class GameOverScreen:
    def __init__(self):
        self.f_xl    = get_font(54, bold=True)
        self.f_lg    = get_font(26, bold=True)
        self.f_md    = get_font(20)
        self.f_sm    = get_font(16)
        self.f_xs    = get_font(14)
        self.f_ctrl  = get_font(19)
        self.f_btn   = get_font(18, bold=True)

    def _return_rect(self):
        bw, bh = sx(210), sy(42)
        return pygame.Rect(WIDTH//2 - bw//2, HEIGHT - sy(92), bw, bh)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self._return_rect().collidepoint(*event.pos):
                return 'return_hub'
        return None

    def draw(self, surf, player, rhythm, elapsed_secs, save_data, new_record, auto_return_timer=None, mouse_pos=None):
        mx, my = mouse_pos if mouse_pos else pygame.mouse.get_pos()

        ov = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        ov.fill((0, 0, 20, 220))
        surf.blit(ov, (0, 0))

        go = self.f_xl.render("GAME  OVER", True, RED)
        surf.blit(go, (WIDTH // 2 - go.get_width() // 2, sy(22)))

        t   = int(elapsed_secs)
        acc = rhythm.get_accuracy()

        # 왼쪽 패널
        lx = sx(60)
        col_w = sx(155)   # 값이 오른쪽 정렬될 폭
        self._section(surf, "이번 런", lx, sy(90))
        stats_left = [
            ("최종 점수",      f"{rhythm.score:,}",         GOLD),
            ("생존 시간",      f"{t//60:02d}:{t%60:02d}",   WHITE),
            ("최종 레벨",      f"Lv.{player.player_level}",  LIGHT_BLUE),
            ("처치 수",        f"{player.total_kills}",      WHITE),
            ("보스 처치",      f"{player.boss_kills}",       (255,120,120)),
            ("최고 콤보",      f"{rhythm.max_combo}",        (100,220,255)),
            ("PERFECT 정확도", f"{acc:.1f}%",                COLOR_PERFECT),
        ]
        y = sy(122)
        for label, val, col in stats_left:
            ls = self.f_sm.render(label, True, GRAY)
            vs = self.f_md.render(val, True, col)
            surf.blit(ls, (lx, y))
            surf.blit(vs, (lx + col_w - vs.get_width(), y))
            y += sy(30)

        # 오른쪽 패널
        rx = WIDTH // 2 + sx(30)
        self._section(surf, "최고 기록", rx, sy(90))
        stats_right = [
            ("최고 점수",   f"{save_data['best_score']:,}",       GOLD),
            ("최고 레벨",   f"Lv.{save_data['best_level']}",      LIGHT_BLUE),
            ("최고 콤보",   f"{save_data['best_combo']}",         (100,220,255)),
            ("최고 정확도", f"{save_data['best_accuracy']:.1f}%", COLOR_PERFECT),
            ("총 플레이",   f"{save_data['total_runs']}판",       WHITE),
            ("최고 처치",   f"{save_data.get('best_kills',0)}",   WHITE),
        ]
        y = sy(122)
        for label, val, col in stats_right:
            ls = self.f_sm.render(label, True, GRAY)
            vs = self.f_md.render(val, True, col)
            surf.blit(ls, (rx, y))
            surf.blit(vs, (rx + col_w - vs.get_width(), y))
            y += sy(30)

        # 중앙 구분선
        pygame.draw.line(surf, (60,60,100),
                         (WIDTH//2, sy(85)), (WIDTH//2, sy(340)), 1)

        # 무기 구성
        self._section(surf, "무기 구성", sx(60), sy(348))
        weapon_names = [WEAPON_DATA[w.wtype]['name']
                        for w in player.weapons if w.wtype in WEAPON_DATA]
        wx = sx(60)
        for wname in weapon_names[:6]:
            wc = RARITY_COLORS.get('rare', WHITE)
            ws = self.f_xs.render(f"- {wname}", True, wc)
            if wx + ws.get_width() > WIDTH - sx(40):
                break
            surf.blit(ws, (wx, sy(372)))
            wx += ws.get_width() + sx(18)

        # 시너지
        if player.active_synergies:
            self._section(surf, "달성 시너지", sx(60), sy(400))
            syn_x = sx(60)
            SYN_NAMES = {
                'chain_explosion': '연쇄 폭발',
                'homing_triple': '유도 강화',  'rhythm_storm': '리듬 폭풍',
            }
            for sid in player.active_synergies:
                ss = self.f_xs.render(f"[시너지] {SYN_NAMES.get(sid, sid)}", True, GOLD)
                surf.blit(ss, (syn_x, sy(424)))
                syn_x += ss.get_width() + sx(20)

        # 신기록 배너
        if new_record:
            bw, bh = sx(340), sy(42)
            bx = WIDTH//2 - bw//2
            by = sy(452)
            nr_s = pygame.Surface((bw, bh), pygame.SRCALPHA)
            nr_s.fill((80,60,0,160))
            surf.blit(nr_s, (bx, by))
            pygame.draw.rect(surf, GOLD, (bx, by, bw, bh), 2, border_radius=6)
            nr = self.f_lg.render("[신기록] 최고 점수 갱신!", True, GOLD)
            surf.blit(nr, (WIDTH//2 - nr.get_width()//2, by + sy(4)))

        r_return = self._return_rect()
        hov_return = r_return.collidepoint(mx, my)
        base_col = (20, 42, 76) if hov_return else (12, 26, 52)
        edge_col = LIGHT_BLUE if hov_return else (90, 150, 210)
        txt_col = WHITE if hov_return else (210, 235, 255)
        pygame.draw.rect(surf, base_col, r_return, border_radius=8)
        pygame.draw.rect(surf, edge_col, r_return, 2, border_radius=8)
        rt = self.f_btn.render("격납고 귀환", True, txt_col)
        surf.blit(rt, (r_return.centerx - rt.get_width()//2,
                       r_return.centery - rt.get_height()//2))

        if auto_return_timer is None:
            ctrl_text = "ENTER / SPACE / ESC / 버튼 클릭  귀환       Q  종료"
        else:
            remain = max(0, int(math.ceil(auto_return_timer / FPS)))
            ctrl_text = f"잠시 후 격납고로 귀환 ({remain})       Q  종료"
        ctrl = self.f_ctrl.render(ctrl_text, True, GRAY)
        surf.blit(ctrl, (WIDTH//2 - ctrl.get_width()//2, HEIGHT - sy(42)))

    _f_section = None  # 클래스 레벨 폰트 (최초 호출 시 초기화)

    @staticmethod
    def _section(surf, title, x, y):
        if GameOverScreen._f_section is None:
            GameOverScreen._f_section = get_font(14, bold=True)
        t = GameOverScreen._f_section.render(title, True, (140,140,200))
        surf.blit(t, (x, y))
        pygame.draw.line(surf, (60,60,100),
                         (x, y + sy(18)), (x + sx(180), y + sy(18)), 1)


class PauseScreen:
    def __init__(self):
        self.f_xl   = get_font(50, bold=True)
        self.f_md   = get_font(20, bold=True)
        self.f_sm   = get_font(17)
        self.f_ctrl = get_font(19)
        self.f_btn  = get_font(16)

    def _options_rect(self):
        return pygame.Rect(WIDTH//2 - sx(70), HEIGHT - sy(110), sx(140), sy(36))

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self._options_rect().collidepoint(*event.pos):
                return 'options'
        return None

    def draw(self, surf, player, rhythm, mouse_pos=None):
        mx, my = mouse_pos if mouse_pos else pygame.mouse.get_pos()

        ov = pygame.Surface((WIDTH,HEIGHT), pygame.SRCALPHA)
        ov.fill((0,0,20,175)); surf.blit(ov,(0,0))

        pause = self.f_xl.render("일시 정지", True, WHITE)
        surf.blit(pause,(WIDTH//2-pause.get_width()//2, sy(55)))

        sc = self.f_md.render(f"현재 점수: {rhythm.score:,}   콤보: {rhythm.combo}", True, GOLD)
        surf.blit(sc,(WIDTH//2-sc.get_width()//2, sy(130)))

        hdr = self.f_md.render("보유 업그레이드", True, LIGHT_BLUE)
        surf.blit(hdr,(WIDTH//2-hdr.get_width()//2, sy(168)))

        from upgrade import UPGRADE_BY_ID
        y = sy(200)
        for uid, count in player.upgrade_counts.items():
            if uid not in UPGRADE_BY_ID: continue
            u  = UPGRADE_BY_ID[uid]
            rc = RARITY_COLORS[u['rarity']]
            s  = self.f_sm.render(f"  {u['name']}  x{count}", True, rc)
            surf.blit(s,(WIDTH//2-s.get_width()//2, y)); y += sy(22)
            if y > HEIGHT - sy(130): break

        # OPTIONS 버튼
        r_opt   = self._options_rect()
        hov_opt = r_opt.collidepoint(mx, my)
        ocol = (65, 65, 105) if hov_opt else (38, 38, 72)
        pygame.draw.rect(surf, ocol, r_opt, border_radius=6)
        pygame.draw.rect(surf, (130, 130, 175) if hov_opt else (90, 90, 140),
                         r_opt, 1, border_radius=6)
        ot = self.f_btn.render("OPTIONS", True,
                               (210, 210, 240) if hov_opt else (160, 160, 210))
        surf.blit(ot, (r_opt.centerx - ot.get_width()//2,
                       r_opt.centery - ot.get_height()//2))

        ctrl = self.f_ctrl.render("ESC  계속       Q  격납고로", True, GRAY)
        surf.blit(ctrl,(WIDTH//2-ctrl.get_width()//2, HEIGHT - sy(50)))


class WarningScreen:
    def __init__(self):
        self.f_warn = get_font(62, bold=True)
        self.f_sub  = get_font(26)

    def draw(self, surf, timer, total_dur, title="!! WARNING !!", subtitle="보스 접근 중...",
             title_color=RED, sub_color=ORANGE, bar_bg=(40, 0, 0), bar_color=RED,
             blink=True):
        if (not blink) or ((timer // 15) % 2 == 0):
            w = self.f_warn.render(title, True, title_color)
            surf.blit(w,(WIDTH//2-w.get_width()//2, HEIGHT//2 - sy(55)))
        sub = self.f_sub.render(subtitle, True, sub_color)
        surf.blit(sub,(WIDTH//2-sub.get_width()//2, HEIGHT//2 + sy(28)))
        ratio = 1 - timer/total_dur
        bw = sx(300); bx=(WIDTH-bw)//2; by=HEIGHT//2 + sy(72)
        pygame.draw.rect(surf, bar_bg, (bx,by,bw,sy(8)), border_radius=4)
        pygame.draw.rect(surf, bar_color, (bx,by,int(bw*ratio),sy(8)), border_radius=4)


# -----------------------------------------------------------------
# Options Screen
# -----------------------------------------------------------------
class OptionsScreen:
    """
    게임 설정 화면
    - BGM 볼륨 / 효과음 볼륨 (< > 버튼)
    - 난이도 (쉬움 / 보통 / 어려움)
    - 전체화면 토글
    - 저장 데이터 초기화 (확인 팝업)
    - 저장 후 메인으로 / 취소
    """

    DIFF_LABELS  = [('easy', '쉬움'), ('normal', '보통'), ('hard', '어려움')]
    DIFF_COLORS  = {
        'easy':   (80,  200,  80),
        'normal': (80,  150, 255),
        'hard':   (230,  60,  60),
    }
    DIFF_DESC = {
        'easy':   '적 HP x0.7  |  플레이어 HP x1.5',
        'normal': '기본 설정',
        'hard':   '적 HP x1.3  |  플레이어 HP x0.8  |  스폰 빠름',
    }

    # -- 패널 레이아웃 상수 -----------------------------
    _PW   = 560   # 패널 폭  (sx 환산 전)
    _ROW  = 68    # 행 높이
    _LX   = 36    # 라벨 x 오프셋
    _CX   = 260   # 컨트롤 x 오프셋 (패널 기준)

    def __init__(self, options: dict):
        self._opts          = dict(options)   # 작업 사본 (저장 전까지 원본 불변)
        self._confirm_reset = False           # 초기화 확인 팝업 표시 여부
        self._saved_flash   = 0              # "저장됨" 플래시 타이머

        # 폰트
        self.f_title    = get_font(44, bold=True)
        self.f_head     = get_font(20, bold=True)
        self.f_md       = get_font(18)
        self.f_sm       = get_font(16)
        self.f_xs       = get_font(14)
        self.f_btn      = get_font(17)
        self.f_btn_bold = get_font(17, bold=True)

    # -- 공개 API --------------------------------------
    def get_options(self) -> dict:
        return dict(self._opts)

    def open(self, options: dict):
        """화면 열릴 때 최신 옵션으로 초기화"""
        self._opts          = dict(options)
        self._confirm_reset = False
        self._saved_flash   = 0

    # -- 레이아웃 헬퍼 ---------------------------------
    def _panel_rect(self) -> pygame.Rect:
        pw = sx(self._PW)
        ph = sy(self._ROW * 6 + 52)   # 5행 + 상하 여백
        return pygame.Rect(WIDTH//2 - pw//2, sy(56), pw, ph)

    def _row_y(self, row_idx: int) -> int:
        pr = self._panel_rect()
        return pr.top + sy(70) + row_idx * sy(self._ROW)

    # -- 볼륨 버튼 rect --------------------------------
    def _vol_left_rect(self, row: int) -> pygame.Rect:
        pr = self._panel_rect()
        cx = pr.left + sx(self._CX)
        y  = self._row_y(row)
        return pygame.Rect(cx, y, sx(28), sy(28))

    def _vol_right_rect(self, row: int) -> pygame.Rect:
        r = self._vol_left_rect(row)
        return pygame.Rect(r.left + sx(162), r.top, sx(28), sy(28))

    # -- 난이도 버튼 rects -----------------------------
    def _diff_rects(self, row: int):
        pr   = self._panel_rect()
        cx   = pr.left + sx(self._CX)
        y    = self._row_y(row)
        bw   = sx(82)
        gap  = sx(6)
        return [pygame.Rect(cx + i*(bw+gap), y, bw, sy(32))
                for i in range(3)]

    # -- 전체화면 토글 rects ---------------------------
    def _fs_rects(self, row: int):
        pr  = self._panel_rect()
        cx  = pr.left + sx(self._CX)
        y   = self._row_y(row)
        bw  = sx(72)
        gap = sx(8)
        return [pygame.Rect(cx + i*(bw+gap), y, bw, sy(32))
                for i in range(2)]

    # -- 초기화 버튼 rect ------------------------------
    def _reset_rect(self, row: int) -> pygame.Rect:
        pr = self._panel_rect()
        cx = pr.left + sx(self._CX)
        y  = self._row_y(row)
        return pygame.Rect(cx, y, sx(160), sy(32))

    # -- 하단 버튼 rects -------------------------------
    def _save_rect(self) -> pygame.Rect:
        pr = self._panel_rect()
        bw = sx(190); bh = sy(44)
        return pygame.Rect(pr.centerx - bw - sx(8),
                           pr.bottom + sy(18), bw, bh)

    def _cancel_rect(self) -> pygame.Rect:
        pr = self._panel_rect()
        bw = sx(110); bh = sy(44)
        return pygame.Rect(pr.centerx + sx(8),
                           pr.bottom + sy(18), bw, bh)

    # -- 확인 팝업 rects -------------------------------
    def _confirm_rect(self) -> pygame.Rect:
        cw, ch = sx(360), sy(160)
        return pygame.Rect(WIDTH//2 - cw//2, HEIGHT//2 - ch//2, cw, ch)

    def _confirm_yes_rect(self) -> pygame.Rect:
        cr = self._confirm_rect()
        bw, bh = sx(120), sy(38)
        return pygame.Rect(cr.centerx - bw - sx(10),
                           cr.bottom - bh - sy(14), bw, bh)

    def _confirm_no_rect(self) -> pygame.Rect:
        cr = self._confirm_rect()
        bw, bh = sx(120), sy(38)
        return pygame.Rect(cr.centerx + sx(10),
                           cr.bottom - bh - sy(14), bw, bh)

    # -- 이벤트 처리 -----------------------------------
    def handle_event(self, event) -> str | None:
        """
        반환값:
          'save'        -> 옵션 저장 후 메인으로
          'cancel'      -> 저장 안 하고 메인으로
          'reset_done'  -> 저장 데이터 초기화 완료 후 메인으로
          None          -> 계속
        """
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self._confirm_reset = False
                    return 'cancel'
            return None

        mx, my = event.pos

        # -- 확인 팝업이 열려있는 경우 ------------------
        if self._confirm_reset:
            if self._confirm_yes_rect().collidepoint(mx, my):
                return 'reset_done'
            if self._confirm_no_rect().collidepoint(mx, my):
                self._confirm_reset = False
            return None

        # -- BGM 볼륨 (row 0) -------------------------
        if self._vol_left_rect(0).collidepoint(mx, my):
            self._opts['bgm_volume'] = max(0, self._opts['bgm_volume'] - 10)
        elif self._vol_right_rect(0).collidepoint(mx, my):
            self._opts['bgm_volume'] = min(100, self._opts['bgm_volume'] + 10)

        # -- SFX 볼륨 (row 1) -------------------------
        elif self._vol_left_rect(1).collidepoint(mx, my):
            self._opts['sfx_volume'] = max(0, self._opts['sfx_volume'] - 10)
        elif self._vol_right_rect(1).collidepoint(mx, my):
            self._opts['sfx_volume'] = min(100, self._opts['sfx_volume'] + 10)

        # -- 난이도 (row 2) ---------------------------
        else:
            for i, rect in enumerate(self._diff_rects(2)):
                if rect.collidepoint(mx, my):
                    self._opts['difficulty'] = self.DIFF_LABELS[i][0]
                    break
            # -- 전체화면 (row 3) ---------------------
            else:
                fs_rects = self._fs_rects(3)
                if fs_rects[0].collidepoint(mx, my):
                    self._opts['fullscreen'] = True
                elif fs_rects[1].collidepoint(mx, my):
                    self._opts['fullscreen'] = False

                # -- 초기화 버튼 (row 4) ---------------
                elif self._reset_rect(4).collidepoint(mx, my):
                    self._confirm_reset = True

                # -- 하단 버튼 -------------------------
                elif self._save_rect().collidepoint(mx, my):
                    return 'save'
                elif self._cancel_rect().collidepoint(mx, my):
                    self._confirm_reset = False
                    return 'cancel'

        return None

    # -- 그리기 ----------------------------------------
    def draw(self, surf: pygame.Surface, mouse_pos=None):
        # 반투명 전체 오버레이
        ov = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        ov.fill((0, 0, 15, 200))
        surf.blit(ov, (0, 0))

        pr = self._panel_rect()
        mx, my = mouse_pos if mouse_pos else pygame.mouse.get_pos()

        # 패널 배경
        panel_bg = pygame.Surface((pr.width, pr.height), pygame.SRCALPHA)
        panel_bg.fill((12, 14, 32, 230))
        surf.blit(panel_bg, pr.topleft)
        pygame.draw.rect(surf, (60, 80, 140), pr, 2, border_radius=10)

        # 제목
        title = self.f_title.render("게임 설정", True, LIGHT_BLUE)
        surf.blit(title, (WIDTH//2 - title.get_width()//2, pr.top + sy(12)))
        pygame.draw.line(surf, (50, 70, 130),
                         (pr.left + sx(20), pr.top + sy(58)),
                         (pr.right - sx(20), pr.top + sy(58)), 1)

        # -- 각 행 그리기 ------------------------------
        self._draw_volume_row(surf, 0, "BGM 볼륨", 'bgm_volume', mx, my)
        self._draw_volume_row(surf, 1, "효과음 볼륨", 'sfx_volume', mx, my)
        self._draw_difficulty_row(surf, 2, mx, my)
        self._draw_fullscreen_row(surf, 3, mx, my)
        self._draw_reset_row(surf, 4, mx, my)

        # -- 하단 버튼 ---------------------------------
        self._draw_button(surf, self._save_rect(),
                          "저장 후 메인으로",
                          (40, 120, 60), (80, 200, 100), mx, my, bold=True)
        self._draw_button(surf, self._cancel_rect(),
                          "취소",
                          (60, 30, 30), (180, 80, 80), mx, my)

        # -- 확인 팝업 ---------------------------------
        if self._confirm_reset:
            self._draw_confirm_popup(surf, mx, my)

    # -- 볼륨 행 ---------------------------------------
    def _draw_volume_row(self, surf, row, label, key, mx, my):
        pr = self._panel_rect()
        y  = self._row_y(row)

        # 라벨
        lbl = self.f_md.render(label, True, (180, 190, 220))
        surf.blit(lbl, (pr.left + sx(self._LX), y + sy(4)))

        val  = self._opts[key]
        cx   = pr.left + sx(self._CX)

        # < 버튼
        rl = self._vol_left_rect(row)
        hover_l = rl.collidepoint(mx, my)
        self._draw_arrow_btn(surf, rl, "<", hover_l, val > 0)

        # 볼륨 바 (10칸)
        bar_x  = rl.right + sx(6)
        bar_y  = y + sy(9)
        bar_w  = sx(120)
        bar_h  = sy(12)
        filled = int(bar_w * val / 100)
        # 배경 바
        pygame.draw.rect(surf, (30, 35, 65), (bar_x, bar_y, bar_w, bar_h), border_radius=3)
        # 채워진 바 (색상: bgm=파랑, sfx=청록)
        bar_col = (70, 160, 255) if key == 'bgm_volume' else (60, 200, 190)
        if filled > 0:
            pygame.draw.rect(surf, bar_col, (bar_x, bar_y, filled, bar_h), border_radius=3)
        # 눈금 (10개)
        for i in range(1, 10):
            nx = bar_x + int(bar_w * i / 10)
            tick_col = (20, 25, 50) if (i * 10) <= val else (50, 55, 85)
            pygame.draw.line(surf, tick_col, (nx, bar_y), (nx, bar_y + bar_h), 1)
        pygame.draw.rect(surf, (60, 80, 130), (bar_x, bar_y, bar_w, bar_h), 1, border_radius=3)

        # > 버튼
        rr = self._vol_right_rect(row)
        hover_r = rr.collidepoint(mx, my)
        self._draw_arrow_btn(surf, rr, ">", hover_r, val < 100)

        # 수치
        vt = self.f_sm.render(f"{val}%", True, (200, 210, 240))
        surf.blit(vt, (rr.right + sx(10), y + sy(4)))

    # -- 난이도 행 -------------------------------------
    def _draw_difficulty_row(self, surf, row, mx, my):
        pr  = self._panel_rect()
        y   = self._row_y(row)
        cur = self._opts['difficulty']

        lbl = self.f_md.render("난이도", True, (180, 190, 220))
        surf.blit(lbl, (pr.left + sx(self._LX), y + sy(4)))

        rects = self._diff_rects(row)
        for i, (key, label) in enumerate(self.DIFF_LABELS):
            r       = rects[i]
            active  = (cur == key)
            hovered = r.collidepoint(mx, my)
            dcol    = self.DIFF_COLORS[key]

            if active:
                bg = dcol
                tc = (255, 255, 255)
                border = dcol
            elif hovered:
                bg = tuple(max(0, c - 60) for c in dcol)
                tc = dcol
                border = dcol
            else:
                bg = (20, 22, 45)
                tc = (100, 110, 140)
                border = (60, 65, 100)

            pygame.draw.rect(surf, bg, r, border_radius=5)
            pygame.draw.rect(surf, border, r, 2, border_radius=5)
            lt = self.f_sm.render(label, True, tc)
            surf.blit(lt, (r.centerx - lt.get_width()//2,
                           r.centery - lt.get_height()//2))

        # 현재 난이도 설명
        desc = self.DIFF_DESC[cur]
        dcol = self.DIFF_COLORS[cur]
        ds   = self.f_xs.render(desc, True, dcol)
        desc_y = y + sy(38)
        surf.blit(ds, (pr.left + sx(self._CX), desc_y))

    # -- 전체화면 행 -----------------------------------
    def _draw_fullscreen_row(self, surf, row, mx, my):
        pr  = self._panel_rect()
        y   = self._row_y(row)
        cur = self._opts['fullscreen']

        lbl = self.f_md.render("전체화면", True, (180, 190, 220))
        surf.blit(lbl, (pr.left + sx(self._LX), y + sy(4)))

        labels   = ["ON", "OFF"]
        values   = [True, False]
        rects    = self._fs_rects(row)
        for i in range(2):
            r       = rects[i]
            active  = (cur == values[i])
            hovered = r.collidepoint(mx, my)

            if active:
                bg     = (60, 160, 255) if i == 0 else (70, 70, 110)
                tc     = WHITE
                border = bg
            elif hovered:
                bg     = (30, 40, 80)
                tc     = (150, 170, 220)
                border = (80, 100, 160)
            else:
                bg     = (16, 18, 40)
                tc     = (80, 90, 120)
                border = (50, 60, 100)

            pygame.draw.rect(surf, bg, r, border_radius=5)
            pygame.draw.rect(surf, border, r, 2, border_radius=5)
            lt = self.f_sm.render(labels[i], True, tc)
            surf.blit(lt, (r.centerx - lt.get_width()//2,
                           r.centery - lt.get_height()//2))

        # 전체화면 참고 안내
        note = self.f_xs.render("(Alt+Enter 로도 전환 가능)", True, (80, 90, 120))
        surf.blit(note, (rects[-1].right + sx(12), y + sy(8)))

    # -- 초기화 행 -------------------------------------
    def _draw_reset_row(self, surf, row, mx, my):
        pr = self._panel_rect()
        y  = self._row_y(row)

        lbl = self.f_md.render("저장 데이터", True, (180, 190, 220))
        surf.blit(lbl, (pr.left + sx(self._LX), y + sy(4)))

        r       = self._reset_rect(row)
        hovered = r.collidepoint(mx, my)
        bg      = (160, 40, 40) if hovered else (100, 20, 20)
        border  = (220, 80, 80) if hovered else (160, 50, 50)
        pygame.draw.rect(surf, bg, r, border_radius=5)
        pygame.draw.rect(surf, border, r, 2, border_radius=5)
        rt = self.f_sm.render("기록 초기화", True, (255, 200, 200))
        surf.blit(rt, (r.centerx - rt.get_width()//2,
                       r.centery - rt.get_height()//2))

        warn = self.f_xs.render("모든 최고 기록이 삭제됩니다", True, (120, 60, 60))
        surf.blit(warn, (r.right + sx(12), y + sy(8)))

    # -- 확인 팝업 -------------------------------------
    def _draw_confirm_popup(self, surf, mx, my):
        # 배경 dim
        dim = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        dim.fill((0, 0, 0, 140))
        surf.blit(dim, (0, 0))

        cr = self._confirm_rect()
        pygame.draw.rect(surf, (18, 10, 10), cr, border_radius=10)
        pygame.draw.rect(surf, (180, 50, 50), cr, 2, border_radius=10)

        title = self.f_head.render("정말 초기화하시겠습니까?", True, (255, 100, 100))
        surf.blit(title, (cr.centerx - title.get_width()//2, cr.top + sy(18)))

        desc = self.f_sm.render("모든 최고 기록과 플레이 데이터가 삭제됩니다.", True, (200, 160, 160))
        surf.blit(desc, (cr.centerx - desc.get_width()//2, cr.top + sy(54)))

        self._draw_button(surf, self._confirm_yes_rect(),
                          "초기화",
                          (140, 30, 30), (220, 80, 80), mx, my, bold=True)
        self._draw_button(surf, self._confirm_no_rect(),
                          "취소",
                          (30, 40, 80), (80, 120, 200), mx, my)

    # -- 공통 버튼 그리기 ------------------------------
    def _draw_button(self, surf, r, text, bg_col, hover_col,
                     mx, my, bold=False):
        hovered = r.collidepoint(mx, my)
        col     = hover_col if hovered else bg_col
        border  = tuple(min(255, c + 40) for c in col)
        pygame.draw.rect(surf, col, r, border_radius=6)
        pygame.draw.rect(surf, border, r, 2, border_radius=6)
        f = self.f_btn_bold if bold else self.f_btn
        t = f.render(text, True, WHITE)
        surf.blit(t, (r.centerx - t.get_width()//2,
                      r.centery - t.get_height()//2))

    # -- 화살표 버튼 -----------------------------------
    def _draw_arrow_btn(self, surf, r, char, hovered, enabled):
        if not enabled:
            bg, tc = (14, 16, 34), (50, 55, 80)
        elif hovered:
            bg, tc = (60, 90, 180), WHITE
        else:
            bg, tc = (25, 35, 80), (140, 160, 220)
        pygame.draw.rect(surf, bg, r, border_radius=4)
        pygame.draw.rect(surf, (50, 70, 140), r, 1, border_radius=4)
        ct = self.f_xs.render(char, True, tc)
        surf.blit(ct, (r.centerx - ct.get_width()//2,
                       r.centery - ct.get_height()//2))


# -----------------------------------------------------------------
# Character Select Screen
# -----------------------------------------------------------------
class CharacterSelect:
    """
    아이작 스타일 캐릭터 선택 화면
    - 좌우 방향키 or 클릭으로 캐릭터 이동
    - ENTER / 클릭(선택 카드)으로 확정
    - ESC / Q 로 허브로 돌아가기
    """
    # 카드 크기 (내부 해상도 기준)
    _CW  = 220   # 카드 폭
    _CH  = 330   # 카드 높이
    _GAP = 40    # 카드 간격

    def __init__(self, characters: list):
        self._chars   = characters
        self._cur     = 0          # 현재 선택 인덱스
        self._confirm = False      # 선택 확정 여부 (깜빡임 연출용)
        self._flash_t = 0          # 확정 깜빡임 타이머
        self._anim_x  = 0.0       # 슬라이드 애니메이션 현재 위치
        self._target_x = 0.0      # 슬라이드 목표 위치

        # 폰트
        self.f_title  = get_font(42, bold=True)
        self.f_name   = get_font(28, bold=True)
        self.f_sub    = get_font(16)
        self.f_desc   = get_font(15)
        self.f_trait  = get_font(14)
        self.f_stat   = get_font(13)
        self.f_hint   = get_font(14)
        self.f_symbol = get_font(44, bold=True)   # 원 안에 맞는 크기

    # -- 공개 API --------------------------------------
    def open(self):
        self._cur      = 0
        self._confirm  = False
        self._flash_t  = 0
        self._anim_x   = 0.0
        self._target_x = 0.0

    def get_selected(self) -> dict:
        return self._chars[self._cur]

    # -- 이벤트 처리 -----------------------------------
    def handle_event(self, event) -> str | None:
        """
        반환값:
          'confirm'  -> 캐릭터 선택 확정
          'back'     -> 허브로
          None       -> 계속
        """
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_LEFT, pygame.K_a):
                self._move(-1)
            elif event.key in (pygame.K_RIGHT, pygame.K_d):
                self._move(1)
            elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                return 'confirm'
            elif event.key in (pygame.K_ESCAPE, pygame.K_q):
                return 'back'

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mx, my = event.pos
            # 카드 클릭
            rects = self._card_rects()
            for i, r in enumerate(rects):
                if r.collidepoint(mx, my):
                    if i == self._cur:
                        return 'confirm'   # 이미 선택된 카드 클릭 -> 확정
                    self._cur      = i
                    self._target_x = 0.0
            # 화살표 버튼
            if self._left_arrow_rect().collidepoint(mx, my):
                self._move(-1)
            if self._right_arrow_rect().collidepoint(mx, my):
                self._move(1)
            # 하단 확정 버튼
            if self._confirm_btn_rect().collidepoint(mx, my):
                return 'confirm'
            # 뒤로가기
            if self._back_btn_rect().collidepoint(mx, my):
                return 'back'

        return None

    # -- 업데이트 (매 프레임) --------------------------
    def update(self):
        # 슬라이드 애니메이션 (lerp)
        self._anim_x += (self._target_x - self._anim_x) * 0.22
        if abs(self._anim_x - self._target_x) < 0.5:
            self._anim_x = self._target_x

    # -- 내부 헬퍼 ------------------------------------
    def _move(self, d: int):
        n = len(self._chars)
        old = self._cur
        self._cur = (self._cur + d) % n
        # 슬라이드 방향
        if self._cur != old:
            card_step = sx(self._CW + self._GAP)
            self._anim_x  -= d * card_step
            self._target_x = 0.0

    def _card_rects(self):
        """각 카드의 실제 화면 Rect 목록"""
        n      = len(self._chars)
        cw     = sx(self._CW)
        ch     = sy(self._CH)
        gap    = sx(self._GAP)
        step   = cw + gap
        total  = n * cw + (n - 1) * gap
        base_x = WIDTH // 2 - total // 2
        cy     = HEIGHT // 2 - ch // 2 + sy(20)
        return [pygame.Rect(base_x + i * step + int(self._anim_x), cy, cw, ch)
                for i in range(n)]

    def _left_arrow_rect(self):
        rects = self._card_rects()
        aw, ah = sx(36), sy(36)
        lx = rects[0].left - sx(54)
        ly = HEIGHT // 2 - ah // 2
        return pygame.Rect(lx, ly, aw, ah)

    def _right_arrow_rect(self):
        rects = self._card_rects()
        aw, ah = sx(36), sy(36)
        rx = rects[-1].right + sx(18)
        ry = HEIGHT // 2 - ah // 2
        return pygame.Rect(rx, ry, aw, ah)

    def _confirm_btn_rect(self):
        bw, bh = sx(220), sy(50)
        return pygame.Rect(WIDTH // 2 - bw // 2,
                           HEIGHT - sy(90), bw, bh)

    def _back_btn_rect(self):
        bw, bh = sx(100), sy(34)
        return pygame.Rect(WIDTH // 2 - bw // 2,
                           HEIGHT - sy(34), bw, bh)

    # -- 그리기 ----------------------------------------
    def draw(self, surf: pygame.Surface, mouse_pos=None):
        mx, my = mouse_pos if mouse_pos else pygame.mouse.get_pos()

        # 반투명 배경 오버레이
        ov = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        ov.fill((0, 0, 10, 210))
        surf.blit(ov, (0, 0))

        # 제목
        title = self.f_title.render("PILOT SELECT", True, LIGHT_BLUE)
        surf.blit(title, (WIDTH // 2 - title.get_width() // 2, sy(30)))
        pygame.draw.line(surf, (40, 80, 140),
                         (WIDTH // 2 - sx(180), sy(82)),
                         (WIDTH // 2 + sx(180), sy(82)), 1)

        # -- 카드들 ------------------------------------
        rects = self._card_rects()
        for i, (char, r) in enumerate(zip(self._chars, rects)):
            self._draw_card(surf, char, r, i == self._cur, mx, my)

        # -- 좌우 화살표 -------------------------------
        can_left  = self._cur > 0
        can_right = self._cur < len(self._chars) - 1
        self._draw_arrow(surf, self._left_arrow_rect(),  "<", can_left,  mx, my)
        self._draw_arrow(surf, self._right_arrow_rect(), ">", can_right, mx, my)

        # -- 확정 버튼 ---------------------------------
        rb   = self._confirm_btn_rect()
        hov  = rb.collidepoint(mx, my)
        char = self._chars[self._cur]
        ccol = char['color']
        bcol = tuple(min(255, c + 30) for c in ccol) if hov else ccol
        pygame.draw.rect(surf, tuple(c // 5 for c in ccol), rb, border_radius=10)
        pygame.draw.rect(surf, bcol, rb, 2, border_radius=10)
        btn_text = f"[ {char['name']} 선택 ]"
        bt = self.f_name.render(btn_text, True,
                                (255, 255, 255) if hov else ccol)
        surf.blit(bt, (rb.centerx - bt.get_width() // 2,
                       rb.centery - bt.get_height() // 2))

        # -- 뒤로가기 ----------------------------------
        rb2   = self._back_btn_rect()
        hov2  = rb2.collidepoint(mx, my)
        back_col = (150, 150, 180) if hov2 else (90, 90, 110)
        bt2 = self.f_hint.render("< BACK", True, back_col)
        surf.blit(bt2, (rb2.centerx - bt2.get_width() // 2,
                        rb2.centery - bt2.get_height() // 2))

        # -- 하단 조작 힌트 ----------------------------
        hint = self.f_hint.render(
            "방향키로 이동   ENTER / 클릭으로 선택   ESC 뒤로",
            True, (80, 90, 120))
        surf.blit(hint, (WIDTH // 2 - hint.get_width() // 2, sy(96)))

    # -- 카드 그리기 -----------------------------------
    def _draw_card(self, surf, char, r, selected, mx, my):
        hov    = r.collidepoint(mx, my)
        ccol   = char['color']
        cdark  = char['color_dark']
        cbord  = char['color_border']

        # 카드 배경
        card_bg = pygame.Surface((r.width, r.height), pygame.SRCALPHA)
        if selected:
            card_bg.fill((*cdark, 230))
        elif hov:
            card_bg.fill((*cdark, 160))
        else:
            card_bg.fill((8, 10, 22, 200))
        surf.blit(card_bg, r.topleft)

        # 카드 테두리
        border_col = cbord if selected else ((60, 70, 110) if not hov else cbord)
        bw         = 3 if selected else 1
        pygame.draw.rect(surf, border_col, r, bw, border_radius=8)

        # 선택 시 위쪽 발광선
        if selected:
            pygame.draw.rect(surf, ccol,
                             (r.left + sx(6), r.top, r.width - sx(12), sy(3)),
                             border_radius=2)

        pad = sx(14)
        cy  = r.top + sy(18)

        # -- 심볼 영역 (원형 배경 + 텍스트) -----------
        sym_r = sy(36)
        sym_cx = r.centerx
        sym_cy = cy + sym_r
        sym_col = ccol if selected else tuple(c // 2 for c in ccol)
        pygame.draw.circle(surf, (*cdark, 220), (sym_cx, sym_cy), sym_r + sy(2))
        pygame.draw.circle(surf, sym_col, (sym_cx, sym_cy), sym_r, 2)

        # 심볼 텍스트를 원 안에 딱 맞게 렌더링
        sym_t = self.f_symbol.render(char['symbol'], True, sym_col)
        # 내접 사각형 최대 크기 = sym_r * sqrt(2), 여백 15%
        max_side = int(sym_r * 1.30)
        tw, th = sym_t.get_width(), sym_t.get_height()
        if tw > max_side or th > max_side:
            scale_f = min(max_side / max(tw, 1), max_side / max(th, 1))
            sym_t = pygame.transform.smoothscale(
                sym_t, (max(1, int(tw * scale_f)), max(1, int(th * scale_f))))
        surf.blit(sym_t, (sym_cx - sym_t.get_width() // 2,
                          sym_cy - sym_t.get_height() // 2))
        cy = sym_cy + sym_r + sy(14)

        # -- 이름 --------------------------------------
        name_col = (255, 255, 255) if selected else (160, 170, 200)
        nt = self.f_name.render(char['name'], True, name_col)
        surf.blit(nt, (r.centerx - nt.get_width() // 2, cy))
        cy += nt.get_height() + sy(2)

        # 직함
        tt = self.f_sub.render(char['title'], True,
                               ccol if selected else (100, 110, 140))
        surf.blit(tt, (r.centerx - tt.get_width() // 2, cy))
        cy += tt.get_height() + sy(10)

        # 구분선
        pygame.draw.line(surf,
                         cbord if selected else (40, 45, 70),
                         (r.left + pad, cy), (r.right - pad, cy), 1)
        cy += sy(8)

        # -- 특성 3줄 ----------------------------------
        for trait in char['traits']:
            tc = ccol if selected else (120, 130, 155)
            ts = self.f_trait.render(f"  {trait}", True, tc)
            surf.blit(ts, (r.left + pad, cy))
            cy += ts.get_height() + sy(3)

        cy += sy(6)

        # -- 스탯 바 4개 -------------------------------
        bar_labels = char['stat_labels']
        bar_vals   = [char['stat_hp'], char['stat_spd'],
                      char['stat_atk'], char['stat_spec']]
        bar_w   = r.width - pad * 2
        bar_h   = sy(7)
        bar_gap = sy(11)
        for label, val in zip(bar_labels, bar_vals):
            # 라벨
            lbl = self.f_stat.render(label, True, (100, 110, 140))
            surf.blit(lbl, (r.left + pad, cy))
            # 배경 바
            bx = r.left + pad + sx(30)
            bw2 = bar_w - sx(30)
            pygame.draw.rect(surf, (20, 24, 48),
                             (bx, cy + sy(2), bw2, bar_h), border_radius=3)
            # 채워진 바
            filled = max(1, int(bw2 * val))
            fill_col = ccol if selected else tuple(c * 2 // 3 for c in ccol)
            pygame.draw.rect(surf, fill_col,
                             (bx, cy + sy(2), filled, bar_h), border_radius=3)
            cy += bar_gap

    # -- 화살표 버튼 -----------------------------------
    def _draw_arrow(self, surf, r, char, enabled, mx, my):
        hov = r.collidepoint(mx, my) and enabled
        if not enabled:
            bg, tc = (12, 14, 30), (40, 45, 65)
        elif hov:
            bg, tc = (50, 80, 160), WHITE
        else:
            bg, tc = (22, 28, 60), (100, 120, 180)
        pygame.draw.rect(surf, bg, r, border_radius=6)
        pygame.draw.rect(surf, (60, 80, 140) if enabled else (30, 35, 60),
                         r, 1, border_radius=6)
        ct = self.f_sub.render(char, True, tc)
        surf.blit(ct, (r.centerx - ct.get_width() // 2,
                       r.centery - ct.get_height() // 2))
