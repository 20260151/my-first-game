import pygame
import random
import math
from settings import *
from weapon import create_weapon
from particle import Particle


class Player:
    def __init__(self, bullet_group, enemies_ref, particles):
        self.bullet_group = bullet_group
        self.enemies_ref  = enemies_ref
        self.particles    = particles

        self.rect = pygame.Rect(
            WIDTH//2 - PLAYER_W//2, HEIGHT - sy(80), PLAYER_W, PLAYER_H)

        # -- Stats -------------------------------------
        self.max_hp      = PLAYER_HP
        self.hp          = self.max_hp
        self.speed       = float(PLAYER_SPEED)
        self.crit_chance = 0.05
        self.crit_mult   = 2.0

        # -- Multipliers -------------------------------
        self.damage_mult    = 1.0
        self.exp_mult       = 1.0
        self.explosion_mult = 1.0

        # -- Passive flags -----------------------------
        self.shield_regen   = False
        self.kill_explode   = False
        self.overclock      = False
        self.combo_boost    = False
        self.overbeat       = False
        self._synergy_rhythm_storm = False

        # -- Overclock ---------------------------------
        self._oc_cd    = 600
        self._oc_dur   = 180
        self._oc_timer = 0
        self.oc_active = False

        # -- Shield regen ------------------------------
        self._regen_timer = 0
        self._regen_int   = 300

        # -- EXP / Level -------------------------------
        self.exp          = 0
        self.player_level = 1
        self.exp_needed   = exp_to_next(1)

        # -- Invincibility -----------------------------
        self.inv_timer = 0

        # -- 필살기 게이지 ------------------------------
        self.ult_gauge    = 0
        self.ULT_MAX      = 100
        self.ULT_PER_PERF = 10
        self._ult_active  = 0
        self.ULT_DUR      = 180
        self._ult_flash_t = 0
        # 방패 스프라이트 애니메이션
        self._shield_frames   = []   # 로드된 프레임 리스트
        self._shield_idx      = 0    # 현재 프레임
        self._shield_tick     = 0    # 프레임 전환 타이머
        self._SHIELD_ANIM_DUR = 3    # 틱/프레임 (20fps)
        self._shield_loaded   = False

        # -- Weapons -----------------------------------
        self.weapons      = [create_weapon('pulse')]
        self.weapon_types = {'pulse'}

        # -- Upgrade tracking --------------------------
        self.upgrade_counts   = {}
        self.active_synergies = set()

        # -- Stats for end screen ----------------------
        self.total_kills = 0
        self.boss_kills  = 0

        # -- Rhythm state ------------------------------
        self._last_judgment = None
        self._last_dmg_mult = 1.0
        self._fire_timer    = 9999

        # -- Engine sprite animation -------------------
        # Spritesheet: 4프레임x2줄 (row0=idle, row1=powering), 각 48x48
        self._engine_frame      = 0
        self._engine_frame_tick = 0
        self._engine_fps        = 8    # 초당 8프레임 재생
        self._engine_fpt        = FPS // 8  # frames-per-tick 사전 계산
        self._engine_sheets     = {}   # 캐시: sheet_key -> [frame_surfaces]
        self._engine_glows      = {}   # 캐시: glow_key -> Surface

        # -- 스프라이트 tint 캐시 --------------------
        self._tint_cache      = {}
        self._oc_sprite_cache = None

        # -- 기울기 (좌우 이동 시 기체 롤링) ---------
        self._is_moving   = False
        self._tilt_angle  = 0.0   # 현재 기울기 각도 (deg, 양수=오른쪽)
        self._tilt_target = 0.0   # 목표 각도
        self._TILT_MAX    = 18.0  # 최대 기울기 (도)
        self._TILT_SPEED  = 0.18  # lerp 속도 (0~1, 클수록 빠름)

    def _load_engine_frames(self, sheet_key):
        """스프라이트 시트에서 프레임 Surface 목록을 추출-캐시."""
        if sheet_key in self._engine_sheets:
            return self._engine_sheets[sheet_key]
        path = IMG_ENGINE_SUPER if sheet_key == 'super' else IMG_ENGINE_BASE
        try:
            raw = pygame.image.load(path).convert_alpha()
        except Exception:
            self._engine_sheets[sheet_key] = []
            return []
        fw, fh = 48, 48
        cols   = raw.get_width() // fw
        frames = []
        for row in range(2):
            row_frames = []
            for col in range(cols):
                frame = pygame.Surface((fw, fh), pygame.SRCALPHA)
                frame.blit(raw, (0, 0), (col * fw, row * fh, fw, fh))
                row_frames.append(frame)
            frames.append(row_frames)
        self._engine_sheets[sheet_key] = frames
        return frames

    # -- Weapon management ----------------------------
    def add_or_upgrade_weapon(self, wtype):
        if wtype in self.weapon_types:
            for w in self.weapons:
                if w.wtype == wtype:
                    w.level_up()
                    break
        else:
            self.weapons.append(create_weapon(wtype))
            self.weapon_types.add(wtype)

    def apply_upgrade(self, upgrade, game):
        upgrade['apply'](self, game)
        uid = upgrade['id']
        self.upgrade_counts[uid] = self.upgrade_counts.get(uid, 0) + 1
        # combo_boost 업그레이드 시 rhythm 엔진에 동기화
        if uid == 'combo_boost':
            game.rhythm._combo_boost = True

    # -- EXP / Level ----------------------------------
    def gain_exp(self, raw):
        gained  = max(1, int(raw * self.exp_mult))
        self.exp += gained
        leveled = False
        while self.exp >= self.exp_needed:
            self.exp          -= self.exp_needed
            self.player_level += 1
            self.exp_needed    = exp_to_next(self.player_level)
            leveled = True
        return leveled

    # -- Damage / Heal ---------------------------------
    def take_damage(self, dmg):
        if self.inv_timer > 0: return False
        if self._ult_active > 0: return False   # 필살기 무적 중 피해 무효
        self.hp = max(0, self.hp - dmg)
        self.inv_timer = PLAYER_INV
        self._tint_cache.clear()   # 피격 시 색조 캐시 초기화
        return self.hp <= 0

    def heal(self, amount):
        old = self.hp
        self.hp = min(self.max_hp, self.hp + amount)
        gained  = self.hp - old
        if gained > 0:
            self.particles.add_damage(
                self.rect.centerx, self.rect.top, gained, heal=True)

    # -- 필살기 게이지 --------------------------------
    def _load_shield(self):
        """방패 스프라이트 시트 로드 (최초 1회)"""
        if self._shield_loaded:
            return
        import pygame, os
        from settings import ASSETS_DIR, ss
        path = os.path.join(ASSETS_DIR, 'shield_round.png')
        try:
            raw = pygame.image.load(path).convert()
            # 배경색(좌상단 픽셀) 자동 감지 -> colorkey
            bg  = raw.get_at((0, 0))[:3]
            raw.set_colorkey(bg)
            FRAME_SZ = 64   # 원본 프레임 크기
            N        = raw.get_width() // FRAME_SZ   # 12프레임
            # 플레이어 크기의 1.8배로 스케일
            from settings import PLAYER_W, PLAYER_H
            render_sz = int(max(PLAYER_W, PLAYER_H) * 1.8)
            for i in range(N):
                # colorkey -> SRCALPHA 변환
                tmp = pygame.Surface((FRAME_SZ, FRAME_SZ))
                tmp.blit(raw, (0, 0), (i * FRAME_SZ, 0, FRAME_SZ, FRAME_SZ))
                tmp.set_colorkey(bg)
                f = pygame.Surface((FRAME_SZ, FRAME_SZ), pygame.SRCALPHA)
                f.fill((0, 0, 0, 0))
                f.blit(tmp, (0, 0))
                # 크기 스케일
                f = pygame.transform.smoothscale(f, (render_sz, render_sz))
                self._shield_frames.append(f)
            self._shield_loaded = True
        except Exception as e:
            print(f'[shield] 로드 실패: {e}')
            self._shield_loaded = True   # 실패해도 재시도 방지

    def charge_ult(self):
        """PERFECT 판정 시 호출 - 게이지 충전"""
        self.ult_gauge = min(self.ULT_MAX, self.ult_gauge + self.ULT_PER_PERF)

    def is_ult_ready(self) -> bool:
        return self.ult_gauge >= self.ULT_MAX and self._ult_active == 0

    def activate_ult(self) -> bool:
        """필살기 발동. 게이지 풀일 때만 성공. 성공 시 True 반환."""
        if not self.is_ult_ready():
            return False
        self.ult_gauge    = 0
        self._ult_active  = self.ULT_DUR
        self._ult_flash_t = 0
        self._shield_idx  = 0
        self._shield_tick = 0
        self._load_shield()   # 미리 로드
        return True

    # -- Fire (BPM 발사 간격 기반 연동 발사) ----------
    def fire_all(self, judgment, dmg_mult, bpm_interval_frames):
        self._last_judgment = judgment
        self._last_dmg_mult = dmg_mult

        # 최소 발사 간격 6f - 연타 방지용 최소값
        MIN_INTERVAL = 6
        if self._fire_timer < MIN_INTERVAL:
            if judgment == 'PERFECT':
                for w in self.weapons:
                    if w.wtype in ('orbit', 'satellite_drone'):
                        w.boosted = True
            return

        # 발사 타이머 리셋
        self._fire_timer = 0

        # 단일 루프: 발사 + Orbit/Satellite PERFECT 처리 통합
        is_perfect = (judgment == 'PERFECT')
        for i, w in enumerate(self.weapons):
            if w.wtype in ('orbit', 'satellite_drone'):
                if is_perfect:
                    w.boosted = True
                    if hasattr(w, 'drones'):
                        for drone in w.drones:
                            for eid in list(drone.hit_cd):
                                drone.hit_cd[eid] = max(1, drone.hit_cd[eid] // 2)
            else:
                mult = dmg_mult if i == 0 else dmg_mult * 0.75
                w.fire(self, self.bullet_group, self.particles,
                       self.enemies_ref, mult, judgment)

    # -- Update ----------------------------------------
    def update(self, keys):
        spd = int(self.speed)
        moving_left  = keys[pygame.K_LEFT]  and self.rect.left   > 0
        moving_right = keys[pygame.K_RIGHT] and self.rect.right  < WIDTH
        self._is_moving = bool(moving_left or moving_right or
                               keys[pygame.K_UP] or keys[pygame.K_DOWN])
        if moving_left:  self.rect.x -= spd
        if moving_right: self.rect.x += spd
        if keys[pygame.K_UP]   and self.rect.top    > 0:      self.rect.y -= spd
        if keys[pygame.K_DOWN] and self.rect.bottom < HEIGHT:  self.rect.y += spd

        # 기울기 목표각 설정 (좌/우/동시/없음)
        if moving_left and not moving_right:
            self._tilt_target = -self._TILT_MAX
        elif moving_right and not moving_left:
            self._tilt_target =  self._TILT_MAX
        else:
            self._tilt_target =  0.0
        # lerp으로 부드럽게 보간
        self._tilt_angle += (self._tilt_target - self._tilt_angle) * self._TILT_SPEED

        # BPM 발사 간격 타이머 증가
        self._fire_timer += 1

        # Invincibility
        if self.inv_timer > 0: self.inv_timer -= 1

        # 필살기 무적 타이머 + 방패 애니메이션
        if self._ult_active > 0:
            self._ult_active  -= 1
            self._ult_flash_t += 1
            if self._shield_frames:
                self._shield_tick += 1
                if self._shield_tick >= self._SHIELD_ANIM_DUR:
                    self._shield_tick = 0
                    self._shield_idx  = (self._shield_idx + 1) % len(self._shield_frames)

        # Shield regen
        if self.shield_regen and self.hp < self.max_hp:
            self._regen_timer += 1
            if self._regen_timer >= self._regen_int:
                self._regen_timer = 0
                self.heal(3)

        # Overclock
        if self.overclock:
            self._oc_timer += 1
            if self.oc_active:
                if self._oc_timer >= self._oc_dur:
                    self.oc_active = False
                    self._oc_timer = 0
                    self._oc_sprite_cache = None   # 캐시 무효화
            else:
                if self._oc_timer >= self._oc_cd:
                    self.oc_active = True
                    self._oc_timer = 0
                    self._oc_sprite_cache = None   # 캐시 무효화

    def _load_engine_glow(self, glow_key):
        """글로우 오버레이 Surface 로드-캐시."""
        if glow_key in self._engine_glows:
            return self._engine_glows[glow_key]
        path = IMG_ENGINE_GLOW_SUPER if glow_key == 'super' else IMG_ENGINE_GLOW_BASE
        try:
            surf = pygame.image.load(path).convert_alpha()
        except Exception:
            self._engine_glows[glow_key] = None
            return None
        self._engine_glows[glow_key] = surf
        return surf

    # -- Engine sprite animation --------------------
    def emit_engine(self, keys):
        """엔진 애니메이션 프레임 진행 (매 프레임 1회만 호출)."""
        self._engine_frame_tick += 1
        if self._engine_frame_tick >= self._engine_fpt:
            self._engine_frame_tick = 0
            self._engine_frame += 1

    def _get_tinted_sprite(self, sprite, w, h):
        """피격/오버클럭 tint 적용 후 캐시된 Surface 반환."""
        if self.inv_timer > 0:
            alpha   = int(160 * self.inv_timer / PLAYER_INV)
            cache_k = (alpha // 16) * 16
            if cache_k not in self._tint_cache:
                tinted  = sprite.copy()
                overlay = pygame.Surface((w, h), pygame.SRCALPHA)
                overlay.fill((cache_k, 0, 0, 0))
                tinted.blit(overlay, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
                self._tint_cache[cache_k] = tinted
            return self._tint_cache[cache_k]
        elif self.oc_active:
            if self._oc_sprite_cache is None:
                tinted  = sprite.copy()
                overlay = pygame.Surface((w, h), pygame.SRCALPHA)
                overlay.fill((80, 50, 0, 0))
                tinted.blit(overlay, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
                self._oc_sprite_cache = tinted
            return self._oc_sprite_cache
        else:
            if self._tint_cache:
                self._tint_cache.clear()
            return sprite

    # -- Draw ------------------------------------------
    def draw(self, surf, offset=(0,0)):
        # 피격 무적 깜빡임 (필살기 무적 중에는 깜빡이지 않음)
        if self.inv_timer > 0 and self._ult_active == 0 and (self.inv_timer//8)%2 == 0:
            return
        ox, oy = offset
        x  = self.rect.x  - ox
        y  = self.rect.y  - oy
        cx = self.rect.centerx - ox
        cy = self.rect.centery - oy
        w, h = PLAYER_W, PLAYER_H

        # -- 엔진 스프라이트 (선체 뒤에 그림) ----------
        sheet_key = 'super' if self.oc_active else 'base'
        frames = self._load_engine_frames(sheet_key)
        if frames:
            row = 1 if self._is_moving or self.oc_active else 0
            row_frames = frames[min(row, len(frames)-1)]
            if row_frames:
                fi = self._engine_frame % len(row_frames)
                eng_surf = row_frames[fi]
                # 엔진도 기울기에 맞게 회전
                if abs(self._tilt_angle) > 0.5:
                    eng_surf = pygame.transform.rotate(eng_surf, -self._tilt_angle)
                ew, eh = eng_surf.get_size()
                ex = cx - ew // 2
                ey = y + h - eh + sy(8)
                surf.blit(eng_surf, (ex, ey))
                glow = self._load_engine_glow(sheet_key)
                if glow:
                    if abs(self._tilt_angle) > 0.5:
                        glow = pygame.transform.rotate(glow, -self._tilt_angle)
                    surf.blit(glow, (ex, ey), special_flags=pygame.BLEND_ADD)

        sprite = load_sprite(IMG_PLAYER, (w, h))

        if sprite:
            # 기울기 적용 - 회전 후 중심을 rect 중심에 고정
            base = self._get_tinted_sprite(sprite, w, h)
            if abs(self._tilt_angle) > 0.5:
                rotated = pygame.transform.rotate(base, -self._tilt_angle)
                rw, rh  = rotated.get_size()
                surf.blit(rotated, (cx - rw//2, cy - rh//2))
            else:
                # 거의 수직 -> 회전 연산 생략 (성능 절약)
                surf.blit(base, (x, y))
        else:
            # 폴백 도형도 기울기 적용
            angle_rad = math.radians(-self._tilt_angle)
            def rot(px, py):
                dx, dy = px - cx, py - cy
                return (cx + dx*math.cos(angle_rad) - dy*math.sin(angle_rad),
                        cy + dx*math.sin(angle_rad) + dy*math.cos(angle_rad))
            col = RED if self.inv_timer > 0 else BLUE
            pts = [rot(cx,y), rot(x,y+h-10), rot(cx,y+h-16), rot(x+w,y+h-10)]
            pygame.draw.polygon(surf, col, pts)
            pts2 = [rot(cx,y+6), rot(cx-7,y+20), rot(cx,y+14), rot(cx+7,y+20)]
            pygame.draw.polygon(surf, LIGHT_BLUE, pts2)

        # 필살기 발동 중 방패 스프라이트 오버레이
        if self._ult_active > 0 and self._shield_frames:
            frame  = self._shield_frames[self._shield_idx % len(self._shield_frames)]
            ratio  = self._ult_active / self.ULT_DUR
            # 종료 30프레임(0.5초) 동안 페이드아웃
            if ratio < 30 / self.ULT_DUR:
                fade_a = int(255 * (self._ult_active / 30))
                frame  = frame.copy()
                mod    = pygame.Surface(frame.get_size(), pygame.SRCALPHA)
                mod.fill((255, 255, 255, fade_a))
                frame.blit(mod, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
            sw, sh = frame.get_size()
            sx_ = self.rect.centerx - ox - sw // 2
            sy_ = self.rect.centery - oy - sh // 2
            surf.blit(frame, (sx_, sy_), special_flags=pygame.BLEND_ADD)
