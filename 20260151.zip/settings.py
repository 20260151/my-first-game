import pygame
import os

# -- Screen -----------------------------------------
WIDTH, HEIGHT = 1920, 1080
FPS           = 60
TITLE         = "PULSE DRIVE"

# 원본 800x600 기준 스케일 팩터
_SX = WIDTH  / 800   # 2.4
_SY = HEIGHT / 600   # 1.8
SX  = _SX   # 공개 버전 - float 곱셈용 (속도, 크기 등)
SY  = _SY

# import * 로 접근 가능하도록 공개 이름으로 래핑
def sx(v): return max(1, int(v * _SX))
def sy(v): return max(1, int(v * _SY))
def ss(v): return max(1, int(v * max(_SX, _SY)))  # 균등 스케일 (비율 왜곡 없음)

# -- Asset paths ------------------------------------
BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
ASSETS_DIR = os.path.join(BASE_DIR, 'assets')
BGM_NORMAL = os.path.join(ASSETS_DIR, 'bgm_normal.mp3')
BGM_BOSS   = os.path.join(ASSETS_DIR, 'bgm_boss.mp3')
BGM_HUB    = os.path.join(ASSETS_DIR, 'hub_bgm.wav')

# -- Sprite image paths -----------------------------
IMG_BG_SPACE   = os.path.join(ASSETS_DIR, 'bg_space.png')
IMG_PLAYER     = os.path.join(ASSETS_DIR, 'player.png')
IMG_ENGINE_BASE      = os.path.join(ASSETS_DIR, 'engine_base.png')
IMG_ENGINE_SUPER     = os.path.join(ASSETS_DIR, 'engine_super.png')
IMG_ENGINE_GLOW_BASE  = os.path.join(ASSETS_DIR, 'engine_glow_base.png')
IMG_ENGINE_GLOW_SUPER = os.path.join(ASSETS_DIR, 'engine_glow_super.png')
IMG_ENEMIES = {
    'drone':     os.path.join(ASSETS_DIR, 'enemy_drone.png'),
    'rusher':    os.path.join(ASSETS_DIR, 'enemy_rusher.png'),
    'gunship':   os.path.join(ASSETS_DIR, 'enemy_gunship.png'),
    'splitter':  os.path.join(ASSETS_DIR, 'enemy_splitter.png'),
    'shieldron': os.path.join(ASSETS_DIR, 'enemy_shieldron.png'),
}
IMG_BOSSES = [
    os.path.join(ASSETS_DIR, 'boss_0.png'),
    os.path.join(ASSETS_DIR, 'boss_1.png'),
    os.path.join(ASSETS_DIR, 'boss_2.png'),
]

_sprite_cache = {}

# -- Destruction animation -----------------------------------
# 각 유닛의 스프라이트 시트 원본 프레임 크기 (px)
DESTROY_FRAME_SIZE = {
    'drone':     64,  'rusher':    64,  'gunship':  64,
    'splitter':  64,  'shieldron': 64,
    'boss_0':   128,  'boss_1':   128,  'boss_2':  111,
}
# 게임 내 렌더 크기 (스케일 자동 적용)
DESTROY_GAME_SIZE = {
    'drone':    ss( 56), 'rusher':   ss( 56), 'gunship':  ss( 60),
    'splitter': ss( 64), 'shieldron':ss( 60),
    'boss_0':   ss(120), 'boss_1':   ss(145), 'boss_2':   ss(140),
}
IMG_DESTRUCTIONS = {
    'drone':     os.path.join(ASSETS_DIR, 'destroy_drone.png'),
    'rusher':    os.path.join(ASSETS_DIR, 'destroy_rusher.png'),
    'gunship':   os.path.join(ASSETS_DIR, 'destroy_gunship.png'),
    'splitter':  os.path.join(ASSETS_DIR, 'destroy_splitter.png'),
    'shieldron': os.path.join(ASSETS_DIR, 'destroy_shieldron.png'),
    'boss_0':    os.path.join(ASSETS_DIR, 'destroy_boss_0.png'),
    'boss_1':    os.path.join(ASSETS_DIR, 'destroy_boss_1.png'),
    'boss_2':    os.path.join(ASSETS_DIR, 'destroy_boss_2.png'),
}

def load_destruction_frames(etype):
    """파괴 애니메이션 프레임 목록 반환 - 검정 배경을 알파 0으로 정확히 변환"""
    cache_key = ('destroy', etype)
    if cache_key in _sprite_cache:
        return _sprite_cache[cache_key]
    path     = IMG_DESTRUCTIONS.get(etype)
    frame_sz = DESTROY_FRAME_SIZE.get(etype, 64)
    game_sz  = DESTROY_GAME_SIZE.get(etype, 64)
    if not path:
        return []
    try:
        # convert_alpha() 로 로드 후 colorkey 방식 대신 직접 SRCALPHA 추출
        raw = pygame.image.load(path).convert()
        raw.set_colorkey((0, 0, 0))
        n = raw.get_width() // frame_sz
        frames = []
        for i in range(n):
            # 중간 서피스에서 colorkey -> SRCALPHA 변환
            tmp = pygame.Surface((frame_sz, frame_sz))
            tmp.blit(raw, (0, 0), (i * frame_sz, 0, frame_sz, frame_sz))
            tmp.set_colorkey((0, 0, 0))
            f = pygame.Surface((frame_sz, frame_sz), pygame.SRCALPHA)
            f.fill((0, 0, 0, 0))
            f.blit(tmp, (0, 0))
            if game_sz != frame_sz:
                # 정수배 nearest 선처리 후 smoothscale - 파괴 애니메이션 선명도 향상
                pre_scale = 4
                pre_sz = frame_sz * pre_scale
                if pre_sz <= game_sz:
                    f = pygame.transform.smoothscale(f, (game_sz, game_sz))
                else:
                    f = pygame.transform.scale(f, (pre_sz, pre_sz))
                    f = pygame.transform.smoothscale(f, (game_sz, game_sz))
            frames.append(f)
        _sprite_cache[cache_key] = frames
        return frames
    except Exception as e:
        print(f'[destroy] 로드 실패 {etype}: {e}')
        return []

# -- Projectile sprites --------------------------------------
# (filename, frame_size_h, (render_w, render_h))
PROJ_SPECS = {
    # -- 플레이어 무기 ------------------------------
    'pulse':       ('proj_player_pulse.png',    32, (sx( 8), sy(18))),
    'spread':      ('proj_player_spread.png',    8, (sx( 8), sy( 8))),
    'homing':      ('proj_player_homing.png',   32, (sx(12), sy(20))),
    'cluster':     ('proj_player_homing.png',   32, (sx(10), sy(16))),
    'explosive':   ('proj_player_explosive.png',32, (sx(14), sy(14))),
    # -- 신규 무기 투사체 ----------------------------------
    'rocket_pod':  ('proj_rocket.png',        32, (sx( 8), sy(18)), True),  # 로켓 - flip_v(v->^)
    # -- 조합 무기 투사체 ----------------------------------
    'torpedo_kla':  ('proj_torpedo_kla.png',      11, (sx(12), sy(28))),  # 유도 펄스 어뢰
    'wave_nau_p':   ('proj_wave_nau_p.png',        64, (sx(32), sy(28))), # 펄스 버스트 파동
    # e_nau_ray 제거 (레이저형 에셋 -> e_nau_spin으로 대체)
    # -- 적 / 보스 - Kla'ed ------------------------
    'e_kla_b':     ('proj_e_kla_b.png',         16, (sx( 8), sy(11)), True),  # flip_v
    'e_kla_bb':    ('proj_e_kla_bb.png',          8, (sx( 7), sy(13)), True),  # 4프레임 애니, flip_v
    'e_kla_w':     ('proj_e_kla_w.png',          64, (sx(22), sy(22))),
    # -- 적 / 보스 - Nairan ------------------------
    'e_nai_bolt':  ('proj_e_nai_bolt.png',        9, (sx( 9), sy( 9)), True),  # flip_v
    'e_nai_torp':  ('proj_e_nai_torp.png',         9, (sx( 8), sy(18)), True),  # 3프레임, flip_v
    'e_nai_rok':   ('proj_e_nai_rok.png',          9, (sx( 8), sy(14)), True),  # 9pxx4프레임, flip_v
    # -- 적 / 보스 - Nautolan ----------------------
    'e_nau_bomb':  ('proj_e_nau_bomb.png',        16, (sx(11), sy(11))),
    'e_nau_spin':  ('proj_e_nau_spin.png',         8, (sx( 8), sy( 8))),
    'e_nau_rok':   ('proj_e_nau_rok.png',          16, (sx( 8), sy(20)), True),  # 16pxx6프레임, flip_v
    'e_nau_b':     ('proj_e_nau_b.png',            9, (sx( 9), sy(12)), True),  # 9pxx8프레임, flip_v
}

def load_proj_frames(key):
    """투사체 스프라이트 프레임 로드.
    배경색을 좌상단 코너 픽셀에서 자동 감지 -> colorkey -> SRCALPHA 변환.
    flip_v=True 항목은 수직 반전 적용 (스프라이트 원본 방향 보정).
    """
    if key not in PROJ_SPECS:
        return []
    cache_key = ('proj', key)
    if cache_key in _sprite_cache:
        return _sprite_cache[cache_key]
    spec = PROJ_SPECS[key]
    fname, frame_sz, (rw, rh) = spec[0], spec[1], spec[2]
    flip_v = spec[3] if len(spec) > 3 else False
    path = os.path.join(ASSETS_DIR, fname)
    try:
        raw = pygame.image.load(path).convert()
        # 배경색 자동 감지 (좌상단 코너 픽셀)
        bg_color = raw.get_at((0, 0))[:3]
        raw.set_colorkey(bg_color)

        n  = max(1, raw.get_width() // frame_sz)
        fh = raw.get_height()  # 실제 높이 사용 (비정사각 프레임 지원)
        frames = []
        for i in range(n):
            src = pygame.Surface((frame_sz, fh))
            src.fill(bg_color)   # BG-FIX: 배경을 bg_color로 채워야 colorkey가 올바르게 작동
            src.blit(raw, (0, 0), (i * frame_sz, 0, frame_sz, fh))
            src.set_colorkey(bg_color)

            f = pygame.Surface((frame_sz, fh), pygame.SRCALPHA)
            f.blit(src, (0, 0))   # colorkey -> SRCALPHA 변환

            # 패딩 없이 목표 크기로 직접 스케일 (비정사각 프레임도 정확히 보존)
            if (rw, rh) != (frame_sz, fh):
                f = pygame.transform.smoothscale(f, (rw, rh))
            if flip_v:
                f = pygame.transform.flip(f, False, True)
            frames.append(f)
        _sprite_cache[cache_key] = frames
        return frames
    except Exception as e:
        print(f'[proj] 로드 실패 {key}: {e}')
        return []

def load_sprite(path, size):
    """스프라이트 로드 및 고화질 업스케일.

    픽셀아트 스프라이트 품질 향상 전략:
      1) 정수배 nearest-neighbor 선처리 (4x) -> 계단 현상 없이 픽셀 선명도 유지
      2) 이후 smoothscale로 최종 크기에 맞춤 -> bilinear로 살짝 부드럽게 마무리
      결과: 단순 smoothscale 대비 엣지 선명도 크게 향상
    """
    key = (path, size)
    if key in _sprite_cache:
        return _sprite_cache[key]
    try:
        img = pygame.image.load(path).convert_alpha()
        sw, sh = img.get_size()
        tw, th = size

        # 정수배 nearest-neighbor 선처리 (최소 4x, 최종 크기보다 크면 불필요)
        pre_scale = 4
        pre_w, pre_h = sw * pre_scale, sh * pre_scale
        if pre_w > tw or pre_h > th:
            # 이미 충분히 크면 바로 smoothscale
            img = pygame.transform.smoothscale(img, (tw, th))
        else:
            # nearest로 4x 확대 -> 선명한 픽셀 유지
            img = pygame.transform.scale(img, (pre_w, pre_h))
            # 최종 크기로 smoothscale (부드러운 마무리)
            img = pygame.transform.smoothscale(img, (tw, th))

        _sprite_cache[key] = img
        return img
    except Exception:
        return None

# -- Colors -----------------------------------------
BLACK      = (0,   0,   0)
WHITE      = (255, 255, 255)
BG_COLOR   = (6,   6,  18)
DARK_GRAY  = (20,  20,  40)

BLUE       = (50,  150, 255)
LIGHT_BLUE = (120, 200, 255)
RED        = (220,  50,  50)
DARK_RED   = (100,  10,  10)
YELLOW     = (240, 220,   0)
GOLD       = (255, 185,   0)
GREEN      = (50,  220,  80)
LIME       = (150, 255, 100)
ORANGE     = (240, 140,   0)
PURPLE     = (170,  70, 230)
CYAN       = (0,   210, 220)
PINK       = (255, 120, 180)
GRAY       = (100, 100, 120)
DARK_BLUE  = (10,  10,  40)

# Rhythm judgment colors
COLOR_PERFECT = (255, 220,   0)
COLOR_GOOD    = (100, 200, 255)
COLOR_MISS    = (180,  60,  60)

RARITY_COLORS = {
    'common':    (160, 160, 180),
    'rare':      (80,  140, 255),
    'legendary': (255, 185,   0),
    'rhythm':    (200,  80, 255),
    'combo':     (255, 130,  30),   # 조합 무기 - 주황 골드
}

# -- Rhythm -----------------------------------------
BPM_NORMAL     = 128
BPM_BOSS       = 160
PERFECT_MS     = 80
GOOD_MS        = 150

# -- Player -----------------------------------------
PLAYER_W     = ss(48)
PLAYER_H     = ss(48)
PLAYER_HP    = 100
PLAYER_SPEED = 5.0 * _SX   # 화면 크기에 비례한 이동 속도
PLAYER_INV   = 90

# -- Weapon data -------------------------------------
WEAPON_DATA = {
    # -- 기본 무기 (baseline) ------------------------
    'pulse':     {'name': '펄스 샷',       'cooldown': 15, 'damage':  8, 'color': YELLOW},
    'spread':    {'name': '산탄',          'cooldown': 28, 'damage':  6, 'color': ORANGE},
    'homing':    {'name': '유도 미사일',   'cooldown': 50, 'damage': 18, 'color': LIME},
    'explosive': {'name': '폭발탄',        'cooldown': 45, 'damage': 14, 'color': PINK},
    'orbit':     {'name': '회전 오브',     'cooldown':  0, 'damage': 14, 'color': CYAN},
    'rocket_pod':  {'name': '로켓 포드',    'cooldown': 30, 'damage': 20, 'color': (164, 132, 104)},
    # -- 조합 무기 ------------------------------------
    # PulseShot 조합
    'guided_pulse':   {'name': '유도 펄스',   'cooldown': 35, 'damage': 22, 'color': (100, 220, 210)},
    'pulse_burst':    {'name': '펄스 버스트', 'cooldown': 22, 'damage': 10, 'color': (150, 255, 120)},
    # 기존 조합
    'cluster_missile': {'name': '클러스터 미사일', 'cooldown': 40, 'damage': 35, 'color': (255, 120,  50)},
    'satellite_drone': {'name': '위성 드론',       'cooldown':  0, 'damage': 18, 'color': (100, 255, 180)},
    'grenade_shot':    {'name': '그레네이드 샷',   'cooldown': 45, 'damage': 45, 'color': (180, 255,  50)},
}

# -- Enemy stats -------------------------------------
ENEMY_STATS = {
    'drone':     {'hp': 20, 'speed': 2.5*_SY, 'exp': 15,  'touch_dmg': 8,
                  'color': (210, 60,  60),  'w': ss(34), 'h': ss(34), 'shoots': False, 'score': 100},
    'rusher':    {'hp': 15, 'speed': 5.5*_SY, 'exp': 20,  'touch_dmg': 12,
                  'color': (230, 110, 50),  'w': ss(32), 'h': ss(32), 'shoots': False, 'score': 100},
    'gunship':   {'hp': 45, 'speed': 1.2*_SY, 'exp': 30,  'touch_dmg': 8,
                  'color': (160, 60, 210),  'w': ss(52), 'h': ss(48), 'shoots': True,  'score': 100},
    'splitter':  {'hp': 65, 'speed': 1.8*_SY, 'exp': 50,  'touch_dmg': 8,
                  'color': (210, 30,  30),  'w': ss(58), 'h': ss(52), 'shoots': True,  'score': 100},
    'shieldron': {'hp': 85, 'speed': 1.0*_SY, 'exp': 45,  'touch_dmg': 8,
                  'color': (60, 100, 220),  'w': ss(54), 'h': ss(54), 'shoots': True,  'score': 100},
}

# -- Boss data ---------------------------------------
BOSS_DATA = [
    {'name': '스타 크루저', 'hp': 1800,  'exp': 200, 'score': 1000,
     'w': ss(120), 'h': ss(120), 'color': (200, 80, 80),   'phase2_color': (230, 20, 20)},
    {'name': '둠 크로울러', 'hp': 3500,  'exp': 300, 'score': 1000,
     'w': ss(145), 'h': ss(145), 'color': (160, 60, 210),  'phase2_color': (200, 10, 10)},
    {'name': '네뷸라 갓',   'hp': 6000,  'exp': 400, 'score': 1000,
     'w': ss(140), 'h': ss(140), 'color': (80,  60, 230),  'phase2_color': (160, 0, 255)},
]

# Boss spawn at these player levels
BOSS_SPAWN_LEVELS = [5, 10, 15]

# -- Level/EXP ---------------------------------------
def exp_to_next(level):
    return 60 + (level - 1) * 35

# -- Spawn helpers -----------------------------------
def get_spawn_interval(level):
    if level <= 2:  return 80
    if level <= 4:  return 60
    if level <= 6:  return 45
    if level <= 9:  return 32
    if level <= 14: return 22
    return 14

def get_enemy_weights(level):
    if level <= 2:  return {'drone': 10}
    if level <= 4:  return {'drone': 7,  'rusher': 3}
    if level <= 6:  return {'drone': 5,  'rusher': 3, 'gunship': 2}
    if level <= 9:  return {'drone': 4,  'rusher': 3, 'gunship': 2, 'splitter': 1}
    if level <= 14: return {'drone': 3,  'rusher': 3, 'gunship': 2, 'splitter': 2, 'shieldron': 1}
    return              {'drone': 2,  'rusher': 3, 'gunship': 2, 'splitter': 3, 'shieldron': 2}

def get_hp_scale(level):
    return 1.0 + max(0, (level - 10)) * 0.15

# -- Font --------------------------------------------
_font_cache = {}

FONT_REGULAR = os.path.join(ASSETS_DIR, 'Galmuri11-Condensed.ttf')
FONT_BOLD    = os.path.join(ASSETS_DIR, 'Galmuri11-Bold.ttf')

def get_font(size, bold=False):
    # 해상도 스케일 자동 적용 (원본 800x600 기준 폰트 크기 -> 현재 해상도 크기)
    scaled = max(10, int(size * _SY))
    key = (scaled, bold)
    if key in _font_cache:
        return _font_cache[key]
    path = FONT_BOLD if bold else FONT_REGULAR
    try:
        f = pygame.font.Font(path, scaled)
        _font_cache[key] = f
        return f
    except Exception as e:
        print(f'[font] Galmuri 로드 실패 ({path}): {e}')
    # 폴백: 시스템 폰트
    f = pygame.font.SysFont(None, scaled, bold=bold)
    _font_cache[key] = f
    return f
