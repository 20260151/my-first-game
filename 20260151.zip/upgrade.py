import pygame
import random
from settings import *


# -----------------------------------------------------
# Upgrade pool
# -----------------------------------------------------
def _add_weapon(p, g, wtype):
    p.add_or_upgrade_weapon(wtype)

def _stat_mult(p, attr, mult):
    setattr(p, attr, getattr(p, attr) * mult)

def _stat_add(p, attr, val):
    setattr(p, attr, getattr(p, attr) + val)

def _flag(p, flag):
    setattr(p, flag, True)

def _hp_up(p, g):
    p.max_hp += 30
    p.hp = min(p.max_hp, p.hp + 30)

UPGRADES = [
    # -- Common ----------------------------------------
    {'id':'dmg_up',    'name':'공격력 강화',    'desc':'전체 무기 데미지 +20%',      'rarity':'common',
     'apply': lambda p,g: _stat_mult(p,'damage_mult',1.20)},
    {'id':'move_spd',  'name':'이동 속도 강화', 'desc':'이동 속도 +1',              'rarity':'common',
     'apply': lambda p,g: _stat_add(p,'speed',1)},
    {'id':'hp_up',     'name':'HP 최대치 증가', 'desc':'최대 HP +30, 즉시 회복',    'rarity':'common',
     'apply': _hp_up},
    {'id':'crit_c',    'name':'크리티컬 확률',  'desc':'크리티컬 확률 +8%',          'rarity':'common',
     'apply': lambda p,g: _stat_add(p,'crit_chance',0.08)},
    {'id':'crit_m',    'name':'크리티컬 배율',  'desc':'크리티컬 배율 +0.3x',        'rarity':'common',
     'apply': lambda p,g: _stat_add(p,'crit_mult',0.3)},
    {'id':'exp_up',    'name':'EXP 획득 증가',  'desc':'모든 EXP +25%',             'rarity':'common',
     'apply': lambda p,g: _stat_mult(p,'exp_mult',1.25)},

    # -- Rare: weapons ---------------------------------
    {'id':'w_spread',  'name':'산탄',          'desc':'산탄 추가 또는 강화',         'rarity':'rare',
     'apply': lambda p,g: _add_weapon(p,g,'spread')},
    {'id':'w_homing',  'name':'유도 미사일',   'desc':'유도 미사일 추가 또는 강화',   'rarity':'rare',
     'apply': lambda p,g: _add_weapon(p,g,'homing')},
    {'id':'w_explosive','name':'폭발탄',       'desc':'폭발탄 추가 또는 강화',        'rarity':'rare',
     'apply': lambda p,g: _add_weapon(p,g,'explosive')},
    {'id':'w_orbit',   'name':'회전 오브',     'desc':'회전 오브 추가 또는 강화',     'rarity':'rare',
     'apply': lambda p,g: _add_weapon(p,g,'orbit')},
    {'id':'w_rocket_pod', 'name':'로켓 포드',  'desc':'로켓 포드 추가 또는 강화',     'rarity':'rare',
     'apply': lambda p,g: _add_weapon(p,g,'rocket_pod')},

    # -- Rare: passives --------------------------------
    {'id':'shield_regen', 'name':'실드 재생',  'desc':'5초마다 HP +3 자동 회복',      'rarity':'rare',
     'apply': lambda p,g: _flag(p,'shield_regen')},
    {'id':'kill_explode', 'name':'처치 폭발',  'desc':'적 처치 시 소형 폭발',         'rarity':'rare',
     'apply': lambda p,g: _flag(p,'kill_explode')},

    # -- Legendary -------------------------------------
    {'id':'overclock',  'name':'오버클럭',     'desc':'10초마다 3초간 GOOD->PERFECT 승격', 'rarity':'legendary',
     'apply': lambda p,g: _flag(p,'overclock')},

    # -- Rhythm upgrades -------------------------------
    {'id':'rhythm_up',   'name':'리듬 강화',   'desc':'PERFECT 판정 범위 +20ms',          'rarity':'rhythm',
     'apply': lambda p,g: _stat_add(g.rhythm,'perfect_window_bonus',20)},
    {'id':'combo_boost', 'name':'콤보 부스트', 'desc':'FAST/SLOW 시 콤보 30% 유지',        'rarity':'rhythm',
     'apply': lambda p,g: _flag(p,'combo_boost')},
    {'id':'overbeat',    'name':'오버비트',    'desc':'연속 PERFECT 10회 시 폭발',          'rarity':'rhythm',
     'apply': lambda p,g: _flag(p,'overbeat')},
    {'id':'rhythm_oload','name':'리듬 오버로드','desc':'콤보 30+ 시 데미지 +50%',           'rarity':'rhythm',
     'apply': lambda p,g: _flag(g.rhythm,'rhythm_overload')},
]

UPGRADE_BY_ID = {u['id']: u for u in UPGRADES}

# -----------------------------------------------------
# Combo recipes  (조합 무기)
# -----------------------------------------------------
# key: frozenset of two source weapon types
# value: resulting combo weapon type
COMBO_RECIPES = {
    frozenset({'homing',    'explosive'}): 'cluster_missile',
    frozenset({'homing',    'orbit'}):     'satellite_drone',
    frozenset({'explosive', 'spread'}):    'grenade_shot',
    # PulseShot 조합
    frozenset({'pulse',     'homing'}):    'guided_pulse',
    frozenset({'pulse',     'spread'}):    'pulse_burst',
}

COMBO_INFO = {
    'cluster_missile': {
        'name': '클러스터 미사일',
        'desc': '추적 후 폭발! 유도탄 + 폭발탄',
        'sources': ('homing', 'explosive'),
    },
    'satellite_drone': {
        'name': '위성 드론',
        'desc': '자동 미사일 발사! 유도탄 + 오브',
        'sources': ('homing', 'orbit'),
    },
    'grenade_shot': {
        'name': '그레네이드 샷',
        'desc': '퍼지는 수류탄! 폭발탄 + 산탄',
        'sources': ('explosive', 'spread'),
    },
    'guided_pulse': {
        'name': '유도 펄스',
        'desc': '추적 어뢰 일제 발사! PulseShot + 유도탄',
        'sources': ('pulse', 'homing'),
    },
    'pulse_burst': {
        'name': '펄스 버스트',
        'desc': '파동 부채꼴 발사! PulseShot + 산탄',
        'sources': ('pulse', 'spread'),
    },
}


def get_available_combo(player):
    """조합 가능한 (재료 set, 결과 타입) 반환. 없으면 (None, None)."""
    for required, result in COMBO_RECIPES.items():
        if (required.issubset(player.weapon_types)
                and result not in player.weapon_types):
            return required, result
    return None, None


def make_combo_card(required_set, combo_type):
    """조합 카드 딕셔너리 생성."""
    info = COMBO_INFO[combo_type]
    return {
        'id':       f'combo_{combo_type}',
        'name':     info['name'],
        'desc':     info['desc'],
        'rarity':   'combo',
        'combo_type':    combo_type,
        'combo_sources': required_set,
        'apply': lambda p, g, ct=combo_type, rs=required_set: _apply_combo(p, g, ct, rs),
    }


def _apply_combo(player, game, combo_type, required_set):
    """두 소스 무기 제거 후 조합 무기 장착."""
    from weapon import create_weapon
    player.weapons      = [w for w in player.weapons if w.wtype not in required_set]
    player.weapon_types -= required_set
    new_weapon = create_weapon(combo_type)
    player.weapons.append(new_weapon)
    player.weapon_types.add(combo_type)


# -----------------------------------------------------
# Synergies
# -----------------------------------------------------
SYNERGIES = {
    'chain_explosion': {
        'name': '연쇄 폭발',
        'desc': '폭발 반경 2배',
        'weapons_needed': {'explosive'},
        'upgrade_counts': {'kill_explode': 1},
        'apply': lambda p: setattr(p,'explosion_mult',2.0),
    },
    'homing_triple': {
        'name': '유도 강화',
        'desc': '유도탄 3발 동시 발사',
        'weapons_needed': {'homing'},
        'upgrade_counts': {'dmg_up': 1},
        'apply': lambda p: [
            (w.level_up(), w.level_up())   # 두 번 개별 호출 -> Lv.3 보장
            for w in p.weapons if w.wtype == 'homing'
        ],
    },
    'rhythm_storm': {
        'name': '리듬 폭풍',
        'desc': 'PERFECT 시 산탄 10발',
        'weapons_needed': {'spread'},
        'upgrade_counts': {'rhythm_up': 2},
        'apply': lambda p: setattr(p,'_synergy_rhythm_storm',True),
    },
    'pulse_overdrive': {
        'name': '펄스 오버드라이브',
        'desc': 'PERFECT 시 PulseShot 3열 동시 발사',
        'weapons_needed': {'pulse'},
        'upgrade_counts': {'crit_c': 1},
        'apply': lambda p: setattr(p, '_synergy_pulse_overdrive', True),
    },
    'orbit_nova': {
        'name': '오브 노바',
        'desc': '오브 처치 시 소형 폭발 + 오브 속도 증가',
        'weapons_needed': {'orbit'},
        'upgrade_counts': {'kill_explode': 1},
        'apply': lambda p: setattr(p, '_synergy_orbit_nova', True),
    },
}

SYNERGY_DISPLAY = {sid: s['name'] for sid, s in SYNERGIES.items()}


def check_new_synergies(player):
    result = []
    for sid, syn in SYNERGIES.items():
        if sid in player.active_synergies: continue
        if not syn['weapons_needed'].issubset(player.weapon_types): continue
        if all(player.upgrade_counts.get(uid,0) >= n
               for uid, n in syn['upgrade_counts'].items()):
            result.append(sid)
    return result


def apply_synergy(sid, player):
    SYNERGIES[sid]['apply'](player)
    player.active_synergies.add(sid)


# -----------------------------------------------------
# Card picker
# -----------------------------------------------------
def get_random_cards(player, count=3):
    lv = player.player_level
    if lv < 5:
        w = {'common':65,'rare':22,'legendary':5,'rhythm':8}
    elif lv < 10:
        w = {'common':50,'rare':30,'legendary':10,'rhythm':10}
    else:
        w = {'common':38,'rare':38,'legendary':14,'rhythm':10}

    pool = []
    for u in UPGRADES:
        weight = w[u['rarity']]
        if u['id'].startswith('w_') and u['id'][2:] not in player.weapon_types:
            weight = int(weight * 1.5)
        pool.append((u, weight))

    chosen, pool_copy = [], list(pool)
    for _ in range(min(count, len(pool_copy))):
        ups, wts = zip(*pool_copy)
        idx = random.choices(range(len(ups)), weights=wts)[0]
        chosen.append(ups[idx])
        pool_copy.pop(idx)

    # 조합 카드: 재료 보유 시 4번째 카드로 추가
    required, combo_type = get_available_combo(player)
    if combo_type:
        chosen.append(make_combo_card(required, combo_type))

    return chosen


# -----------------------------------------------------
# Upgrade Menu UI
# -----------------------------------------------------
class UpgradeMenu:
    def __init__(self):
        self.CW = sx(192)
        self.CH = sy(280)
        self.GAP = sy(18)
        self.cards   = []
        self.rerolls = 2
        self.hovered = -1
        self._ready  = False

    def _init_fonts(self):
        if self._ready: return
        self.f_title  = get_font(19, bold=True)
        self.f_body   = get_font(15)
        self.f_rarity = get_font(13, bold=True)
        self.f_big    = get_font(28, bold=True)
        self.f_sub    = get_font(17)
        self._ready   = True

    def reset(self, rerolls=2):
        self.rerolls = rerolls
        self.hovered = -1
        self._card_bg_cache = {}  # 카드 크기 바뀔 수 있으므로 초기화

    def set_cards(self, cards):
        self.cards   = cards
        self.hovered = -1

    def handle_event(self, event):
        self._init_fonts()
        if event.type == pygame.MOUSEMOTION:
            self.hovered = self._card_at(*event.pos)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mx, my = event.pos
            idx = self._card_at(mx, my)
            if 0 <= idx < len(self.cards): return idx
            if self._in_reroll(mx, my):    return 'reroll'
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_1 and len(self.cards)>0: return 0
            if event.key == pygame.K_2 and len(self.cards)>1: return 1
            if event.key == pygame.K_3 and len(self.cards)>2: return 2
            if event.key == pygame.K_4 and len(self.cards)>3: return 3   # 조합 카드
            if event.key == pygame.K_r:                        return 'reroll'
        return None

    def _card_rect(self, i):
        n     = len(self.cards)
        cw    = sx(155) if n >= 4 else sx(192)
        gap   = sy(14)  if n >= 4 else sy(18)
        total = cw * n + gap * (n - 1)
        ox    = (WIDTH  - total) // 2   # origin x (함수명 sx와 충돌 방지)
        oy    = (HEIGHT - self.CH) // 2  # origin y
        return ox + i * (cw + gap), oy, cw, self.CH

    def _card_at(self, mx, my):
        for i in range(len(self.cards)):
            x,y,w,h = self._card_rect(i)
            if x<=mx<=x+w and y<=my<=y+h: return i
        return -1

    def _reroll_rect(self):
        _, card_y, _, ch = self._card_rect(0)
        cx = WIDTH//2; rw, rh = sx(160), sy(38)
        return cx - rw//2, card_y + ch + sy(14), rw, rh

    def _in_reroll(self, mx, my):
        rx,ry,rw,rh = self._reroll_rect()
        return rx<=mx<=rx+rw and ry<=my<=ry+rh

    def draw(self, surf):
        self._init_fonts()

        # 배경 오버레이 - 캐시 (첫 프레임만 생성)
        if not hasattr(self, '_bg_surf'):
            self._bg_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            self._bg_surf.fill((0, 0, 28, 195))
            glow = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            pygame.draw.ellipse(glow, (30, 30, 80, 40),
                                (WIDTH//4, HEIGHT//4, WIDTH//2, HEIGHT//2))
            self._bg_surf.blit(glow, (0, 0))
        surf.blit(self._bg_surf, (0, 0))

        _, card_top, _, _ = self._card_rect(0)
        t = self.f_big.render("업그레이드 선택", True, WHITE)
        surf.blit(t, (WIDTH//2-t.get_width()//2, card_top - sy(80)))
        key_hint = "1 / 2 / 3 / 4" if len(self.cards) >= 4 else "1 / 2 / 3"
        hint = self.f_body.render(f"{key_hint}  또는 클릭으로 선택   |   R 재굴림", True, GRAY)
        surf.blit(hint, (WIDTH//2-hint.get_width()//2, card_top - sy(30)))

        for i, card in enumerate(self.cards):
            x, y, w, h = self._card_rect(i)
            rc  = RARITY_COLORS[card['rarity']]
            hov = (i == self.hovered)

            # 카드 배경 Surface 캐시 (크기x색상 키)
            bg_key = (w, h, tuple(rc))
            if not hasattr(self, '_card_bg_cache'):
                self._card_bg_cache = {}
            if bg_key not in self._card_bg_cache:
                r_tint, g_tint, b_tint = rc
                _bg = pygame.Surface((w, h), pygame.SRCALPHA)
                _bg.fill((max(10, r_tint//8), max(10, g_tint//8), max(10, b_tint//6), 230))
                self._card_bg_cache[bg_key] = _bg
            surf.blit(self._card_bg_cache[bg_key], (x, y))

            if hov:
                # 호버 오버레이는 작고 간단하게 direct draw
                pygame.draw.rect(surf, (*rc, 40), (x, y, w, h))
                pygame.draw.rect(surf, (*rc, 60), (x-3, y-3, w+6, h+6), 3, border_radius=10)

            bw = 3 if hov else 2
            pygame.draw.rect(surf, rc, (x,y,w,h), bw, border_radius=8)

            if card['rarity'] in ('legendary', 'combo'):
                glow_s = pygame.Surface((w+4, h+4), pygame.SRCALPHA)
                pygame.draw.rect(glow_s, (*rc, 50), (0,0,w+4,h+4), 5, border_radius=10)
                surf.blit(glow_s, (x-2, y-2))

            num = self.f_rarity.render(f"[{i+1}]", True, GRAY)
            surf.blit(num,(x + sx(7), y + sy(7)))
            rl = self.f_rarity.render(card['rarity'].upper(), True, rc)
            surf.blit(rl,(x+w-rl.get_width() - sx(7), y + sy(7)))

            pygame.draw.rect(surf, rc,       (x + sx(8), y + sy(30), w - sx(16), 2))
            pygame.draw.rect(surf, (*rc, 60), (x + sx(8), y + sy(32), w - sx(16), 1))

            ns = self.f_title.render(card['name'], True, WHITE)
            surf.blit(ns,(x+w//2-ns.get_width()//2, y + sy(40)))

            desc_y = y + sy(70)
            if card['rarity'] == 'combo':
                srcs = card.get('combo_sources', set())
                src_names = ' + '.join(WEAPON_DATA[s]['name'] for s in srcs)
                src_s = self.f_body.render(src_names, True, (255,180,80))
                surf.blit(src_s,(x+w//2-src_s.get_width()//2, desc_y))
                desc_y += sy(24)
                arrow = self.f_body.render('^', True, (255,130,30))
                surf.blit(arrow,(x+w//2-arrow.get_width()//2, desc_y))
                desc_y += sy(20)

            for line in self._wrap(card['desc'], self.f_body, w - sx(14)):
                ls = self.f_body.render(line, True, (210,210,230))
                surf.blit(ls,(x + sx(7), desc_y)); desc_y += sy(22)

        rx,ry,rw,rh = self._reroll_rect()
        if self.rerolls > 0:
            # 8. 재굴림 버튼 발광 효과
            btn_glow = pygame.Surface((rw+6, rh+6), pygame.SRCALPHA)
            pygame.draw.rect(btn_glow, (100,100,180,50), (0,0,rw+6,rh+6), border_radius=8)
            surf.blit(btn_glow, (rx-3, ry-3))
            pygame.draw.rect(surf,(55,55,100),(rx,ry,rw,rh),border_radius=6)
            pygame.draw.rect(surf,(120,120,200),(rx,ry,rw,rh),1,border_radius=6)
            rt = self.f_sub.render(f"재굴림 [R]  {self.rerolls}회", True, WHITE)
        else:
            pygame.draw.rect(surf,(30,30,50),(rx,ry,rw,rh),border_radius=6)
            pygame.draw.rect(surf,GRAY,(rx,ry,rw,rh),1,border_radius=6)
            rt = self.f_sub.render("재굴림 불가", True, GRAY)
        surf.blit(rt,(rx+rw//2-rt.get_width()//2, ry+rh//2-rt.get_height()//2))

    @staticmethod
    def _wrap(text, font, max_w):
        words,lines,cur = text.split(' '),[],''
        for word in words:
            test = (cur+' '+word).strip()
            if font.size(test)[0] <= max_w: cur = test
            else:
                if cur: lines.append(cur)
                cur = word
        if cur: lines.append(cur)
        return lines
