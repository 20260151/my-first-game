import pygame
import random
import math
from settings import *


# -----------------------------------------------------
# Sprite animation helpers
# -----------------------------------------------------
def _init_anim(obj, sprite_key, anim_dur=3):
    frames = load_proj_frames(sprite_key) if sprite_key else []
    obj._anim_frames = frames
    obj._anim_idx    = 0
    obj._anim_timer  = 0
    obj._ANIM_DUR    = anim_dur
    return frames

def _step_anim(obj):
    if not obj._anim_frames:
        return
    obj._anim_timer += 1
    if obj._anim_timer >= obj._ANIM_DUR:
        obj._anim_timer = 0
        obj._anim_idx = (obj._anim_idx + 1) % len(obj._anim_frames)
        obj.image = obj._anim_frames[obj._anim_idx]

def _step_rotated_anim(obj):
    if not obj._anim_frames:
        return
    obj._anim_timer += 1
    if obj._anim_timer >= obj._ANIM_DUR:
        obj._anim_timer = 0
        obj._anim_idx = (obj._anim_idx + 1) % len(obj._anim_frames)
    base = obj._anim_frames[obj._anim_idx]
    if obj.vx != 0 or obj.vy != 0:
        angle   = -math.degrees(math.atan2(obj.vy, obj.vx)) - 90
        rotated = pygame.transform.rotate(base, angle)
        center  = obj.rect.center
        obj.image = rotated
        obj.rect  = obj.image.get_rect(center=center)
    else:
        obj.image = base


# -----------------------------------------------------
# Dot-style fallback drawing
# -----------------------------------------------------
def _draw_dot_bullet(surf, color, w, h):
    r, g, b = color
    dark   = (max(0,r-60), max(0,g-60), max(0,b-60))
    bright = (min(255,r+80), min(255,g+80), min(255,b+80))
    pygame.draw.rect(surf, dark,   (0,0,w,h))
    pygame.draw.rect(surf, color,  (1,1,w-2,h-2))
    pygame.draw.rect(surf, bright, (2,2,max(1,w-4),max(1,h//3)))


# -----------------------------------------------------
# Player bullet classes
# -----------------------------------------------------
class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, vx, vy, damage, color,
                 w=4, h=10, piercing=False, sprite_key=None):
        super().__init__()
        frames = _init_anim(self, sprite_key)
        if frames:
            self.image = frames[0].copy()
        else:
            self.image = pygame.Surface((w, h), pygame.SRCALPHA)
            _draw_dot_bullet(self.image, color, w, h)
        self.rect     = self.image.get_rect(centerx=x, centery=y)
        self.vx, self.vy = float(vx), float(vy)
        self.damage   = damage
        self.piercing = piercing
        self.hit_ids  = set()
        self.explosive_radius = 0

    def update(self):
        _step_anim(self)
        self.rect.x += self.vx
        self.rect.y += self.vy
        if (self.rect.bottom < -10 or self.rect.top > HEIGHT+10
                or self.rect.right < -10 or self.rect.left > WIDTH+10):
            self.kill()


class GuidedBullet(pygame.sprite.Sprite):
    def __init__(self, x, y, damage, enemies_ref):
        super().__init__()
        frames = _init_anim(self, 'homing', anim_dur=4)
        if frames:
            self.image = frames[0].copy()
        else:
            W, H = 6, 12
            self.image = pygame.Surface((W, H), pygame.SRCALPHA)
            pygame.draw.rect(self.image, (30,120,30),  (0,0,W,H))
            pygame.draw.rect(self.image, LIME,          (1,1,W-2,H-2))
            pygame.draw.rect(self.image, (200,255,200), (2,1,2,3))
            pygame.draw.rect(self.image, (30,120,30),   (1,H-3,W-2,2))
        self.rect        = self.image.get_rect(centerx=x, centery=y)
        self.damage      = damage
        self.enemies_ref = enemies_ref
        self.vx, self.vy = 0.0, -9.0
        self.speed       = 9.0
        self.turn        = 0.13
        self.piercing    = False
        self.hit_ids     = set()
        self.explosive_radius = 0

    def update(self):
        nearest, min_d2 = None, float('inf')
        scx, scy = self.rect.centerx, self.rect.centery
        for e in self.enemies_ref:
            if e.alive() and not getattr(e, 'dying', False):
                dx = e.rect.centerx - scx
                dy = e.rect.centery  - scy
                d2 = dx*dx + dy*dy   # 제곱 거리 - hypot 생략
                if d2 < min_d2:
                    min_d2, nearest = d2, e
        if nearest:
            dx = nearest.rect.centerx - scx
            dy = nearest.rect.centery  - scy
            dist = max(1.0, math.hypot(dx, dy))
            inv  = self.speed / dist
            tx, ty = dx*inv, dy*inv
            self.vx += (tx-self.vx)*self.turn
            self.vy += (ty-self.vy)*self.turn
            spd = math.hypot(self.vx, self.vy)
            if spd > 0:
                inv2 = self.speed / spd
                self.vx *= inv2
                self.vy *= inv2
        else:
            self.vy = -self.speed
        _step_rotated_anim(self)
        self.rect.x += self.vx
        self.rect.y += self.vy
        if (self.rect.bottom < -20 or self.rect.top > HEIGHT+20
                or self.rect.right < -20 or self.rect.left > WIDTH+20):
            self.kill()


class ExplosiveBullet(pygame.sprite.Sprite):
    def __init__(self, x, y, damage, radius=60):
        super().__init__()
        frames = _init_anim(self, 'explosive', anim_dur=3)
        if frames:
            self.image = frames[0].copy()
        else:
            W, H = 10, 10
            self.image = pygame.Surface((W, H), pygame.SRCALPHA)
            pygame.draw.rect(self.image, (120,0,60),   (0,0,W,H))
            pygame.draw.rect(self.image, PINK,          (1,1,W-2,H-2))
            pygame.draw.rect(self.image, (255,255,200), (3,3,4,4))
            for corner in [(0,0),(W-1,0),(0,H-1),(W-1,H-1)]:
                self.image.set_at(corner,(0,0,0,0))
        self.rect             = self.image.get_rect(centerx=x, centery=y)
        self.damage           = damage
        self.radius           = radius
        self.explosive_radius = radius
        self.vy               = -7
        self.vx               = 0.0
        self.piercing         = False
        self.hit_ids          = set()

    def update(self):
        _step_anim(self)
        self.rect.x += self.vx
        self.rect.y += self.vy
        if self.rect.bottom < -10:
            self.kill()


class ClusterBullet(pygame.sprite.Sprite):
    def __init__(self, x, y, damage, radius, enemies_ref):
        super().__init__()
        frames = _init_anim(self, 'cluster', anim_dur=4)
        if frames:
            self.image = frames[0].copy()
        else:
            W, H = 6, 14
            self.image = pygame.Surface((W, H), pygame.SRCALPHA)
            pygame.draw.rect(self.image, (140,50,0),   (0,0,W,H))
            pygame.draw.rect(self.image, (255,120,50),  (1,1,W-2,H-2))
            pygame.draw.rect(self.image, (255,220,100), (2,1,2,3))
            pygame.draw.rect(self.image, (255,200,80),  (1,H-4,W-2,3))
        self.rect             = self.image.get_rect(centerx=x, centery=y)
        self.damage           = damage
        self.radius           = radius
        self.explosive_radius = radius
        self.enemies_ref      = enemies_ref
        self.vx, self.vy      = 0.0, -9.0
        self.speed            = 8.5
        self.turn             = 0.12
        self.piercing         = False
        self.hit_ids          = set()

    def update(self):
        nearest, min_d2 = None, float('inf')
        scx, scy = self.rect.centerx, self.rect.centery
        for e in self.enemies_ref:
            if e.alive() and not getattr(e, 'dying', False):
                dx = e.rect.centerx - scx
                dy = e.rect.centery  - scy
                d2 = dx*dx + dy*dy   # 제곱거리 - hypot 생략
                if d2 < min_d2:
                    min_d2, nearest = d2, e
        if nearest:
            dx = nearest.rect.centerx - scx
            dy = nearest.rect.centery  - scy
            dist = max(1.0, math.hypot(dx, dy))
            inv  = self.speed / dist
            tx, ty = dx*inv, dy*inv
            self.vx += (tx-self.vx)*self.turn
            self.vy += (ty-self.vy)*self.turn
            spd = math.hypot(self.vx, self.vy)
            if spd > 0:
                inv2 = self.speed / spd
                self.vx *= inv2
                self.vy *= inv2
        else:
            self.vy = -self.speed
        _step_rotated_anim(self)
        self.rect.x += self.vx
        self.rect.y += self.vy
        if (self.rect.bottom < -20 or self.rect.top > HEIGHT+20
                or self.rect.right < -20 or self.rect.left > WIDTH+20):
            self.kill()


# -----------------------------------------------------
# Enemy bullet
# -----------------------------------------------------
# 투사체 종류별 애니메이션 속도 (틱/프레임, 작을수록 빠름)
_PROJ_ANIM_DUR = {
    'e_kla_b':    3,   # 1프레임 - 정적
    'e_kla_bb':   4,   # 4프레임 - 15fps
    'e_kla_w':    3,   # 6프레임 - 파동
    'e_nai_bolt': 3,   # 5프레임
    'e_nai_rok':  4,   # 4프레임 - 15fps
    'e_nai_torp': 3,   # 3프레임 - 20fps
    'e_nau_b':    3,   # 8프레임 - 20fps
    'e_nau_bomb': 2,   # 16프레임 - 빠른 폭탄
    'e_nau_rok':  4,   # 6프레임 - 15fps
    'e_nau_spin': 2,   # 8프레임 - 회전탄 빠르게
}


class EnemyBullet(pygame.sprite.Sprite):
    def __init__(self, x, y, vx, vy, damage=8,
                 color=(255,80,80), sprite_key=None):
        super().__init__()
        dur    = _PROJ_ANIM_DUR.get(sprite_key, 3)
        frames = _init_anim(self, sprite_key, anim_dur=dur)
        if frames:
            self.image = frames[0].copy()
        else:
            r, g, b = color
            dark = (max(0,r-60), max(0,g-60), max(0,b-60))
            self.image = pygame.Surface((6, 6), pygame.SRCALPHA)
            pygame.draw.rect(self.image, dark,  (0,0,6,6))
            pygame.draw.rect(self.image, color, (1,1,4,4))
            pygame.draw.rect(self.image,
                (min(255,r+80),min(255,g+80),min(255,b+80)), (2,2,2,2))
        self.rect   = self.image.get_rect(centerx=x, centery=y)
        self.vx, self.vy = float(vx), float(vy)
        self.damage = damage
        self._has_gravity = False   # gravity_pull 패턴에서 동적 설정

    def update(self):
        _step_anim(self)
        if self._has_gravity:
            self._grav_timer -= 1
            if self._grav_timer <= 0:
                tx, ty = self._grav_target
                dx = tx - self.rect.centerx
                dy = ty - self.rect.centery
                dist = max(1, math.hypot(dx, dy))
                self.vx = dx/dist*self._grav_spd
                self.vy = dy/dist*self._grav_spd
                self._has_gravity = False
        self.rect.x += self.vx
        self.rect.y += self.vy
        if (self.rect.bottom < -10 or self.rect.top > HEIGHT+10
                or self.rect.right < -10 or self.rect.left > WIDTH+10):
            self.kill()



# -----------------------------------------------------
# Orbit Drone
# -----------------------------------------------------
class OrbitDrone:
    def __init__(self, index, total, damage, radius=None):
        if radius is None:
            radius = sy(70)
        self.index   = index
        self.total   = total
        self.damage  = damage
        self.radius  = radius
        self.angle   = math.pi*2/total*index
        self.speed   = 0.04
        self.size    = 8
        self.hit_cd  = {}
        self.hit_interval = 30

    def update(self, player_cx, player_cy, boosted=False):
        self.angle = (self.angle + self.speed*(1.4 if boosted else 1.0)) % (math.pi*2)
        self.x = player_cx + math.cos(self.angle)*self.radius
        self.y = player_cy + math.sin(self.angle)*self.radius
        for eid in list(self.hit_cd):
            self.hit_cd[eid] -= 1
            if self.hit_cd[eid] <= 0:
                del self.hit_cd[eid]

    def try_hit(self, enemy):
        eid = id(enemy)
        if eid in self.hit_cd:
            return 0
        threshold = self.size + enemy.w // 2
        dx = self.x - enemy.rect.centerx
        dy = self.y - enemy.rect.centery
        if dx*dx + dy*dy <= threshold * threshold:
            self.hit_cd[eid] = self.hit_interval
            return self.damage
        return 0

    # 잔상 Surface 클래스 레벨 캐시 (인스턴스마다 생성 방지)
    _trail_surfs = None

    @classmethod
    def _get_trail_surfs(cls):
        if cls._trail_surfs is None:
            cls._trail_surfs = []
            for i in range(1, 4):
                s = pygame.Surface((6, 6), pygame.SRCALPHA)
                pygame.draw.circle(s, (*CYAN, 60 - i*15), (3, 3), 3)
                cls._trail_surfs.append(s)
        return cls._trail_surfs

    def draw(self, surf, offset=(0,0)):
        ox, oy = offset
        cx, cy = int(self.x-ox), int(self.y-oy)
        pygame.draw.circle(surf, CYAN,  (cx,cy), self.size)
        pygame.draw.circle(surf, WHITE, (cx,cy), self.size-3)
        trail_surfs = self._get_trail_surfs()
        for i, ts in enumerate(trail_surfs, 1):
            ta = self.angle - self.speed*i*4
            tx = int(self.x-ox+math.cos(ta)*(self.radius-5))
            ty = int(self.y-oy+math.sin(ta)*(self.radius-5))
            surf.blit(ts, (tx-3, ty-3))


# -----------------------------------------------------
# Weapon base
# -----------------------------------------------------
class Weapon:
    def __init__(self, wtype):
        self.wtype    = wtype
        self.level    = 1
        data          = WEAPON_DATA[wtype]
        self.base_dmg = data['damage']
        self.color    = data['color']
        self.name     = data['name']
        self.pierce   = False
        self.sniper   = False

    def get_damage(self, player, dmg_mult=1.0):
        base = self.base_dmg*(1.0+(self.level-1)*0.30)
        dmg  = base*player.damage_mult*dmg_mult
        crit = random.random() < player.crit_chance
        if crit:
            dmg *= player.crit_mult
        return int(max(1, dmg)), crit

    def level_up(self):
        if self.level < 3:
            self.level += 1
            return True
        return False

    def fire(self, player, bullet_group, particles, enemies_ref, dmg_mult=1.0, judgment=None):
        raise NotImplementedError


# -----------------------------------------------------
# Concrete weapons
# -----------------------------------------------------
class PulseWeapon(Weapon):
    def __init__(self): super().__init__('pulse')

    def fire(self, player, bullet_group, particles, enemies_ref, dmg_mult=1.0, judgment=None):
        dmg, _ = self.get_damage(player, dmg_mult)
        x, y = player.rect.centerx, player.rect.top
        overdrive = getattr(player, '_synergy_pulse_overdrive', False)
        if judgment == 'PERFECT':
            offsets = [-18, 0, 18] if overdrive else [-10, 10]
            for ox in offsets:
                bullet_group.add(
                    Bullet(x+ox, y, 0, -13, dmg, self.color, sprite_key='pulse'))
        else:
            cols = [-10, 0, 10] if overdrive else [0]
            for ox in cols:
                bullet_group.add(
                    Bullet(x+ox, y, 0, -13, dmg, self.color, sprite_key='pulse'))


class SpreadWeapon(Weapon):
    def __init__(self): super().__init__('spread')

    def fire(self, player, bullet_group, particles, enemies_ref, dmg_mult=1.0, judgment=None):
        dmg, _ = self.get_damage(player, dmg_mult)
        x, y = player.rect.centerx, player.rect.top
        # rhythm_storm 시너지: PERFECT 시 10발
        rhythm_storm = getattr(player, '_synergy_rhythm_storm', False)
        if judgment == 'PERFECT' and rhythm_storm:
            pellets = 10
        elif judgment == 'PERFECT':
            pellets = 8
        else:
            pellets = 5
        pellets += (self.level - 1)
        spread  = 55
        for i in range(pellets):
            a_deg = -spread/2+spread/(pellets-1)*i if pellets > 1 else 0
            a_rad = math.radians(a_deg-90)
            vx = math.cos(a_rad)*11
            vy = math.sin(a_rad)*11
            bullet_group.add(
                Bullet(x, y, vx, vy, dmg, self.color, w=5, h=5, sprite_key='spread'))


class HomingWeapon(Weapon):
    def __init__(self): super().__init__('homing')

    def fire(self, player, bullet_group, particles, enemies_ref, dmg_mult=1.0, judgment=None):
        dmg, _ = self.get_damage(player, dmg_mult)
        x, y   = player.rect.centerx, player.rect.top
        count   = self.level + (1 if judgment == 'PERFECT' else 0)
        o = sx(16)   # 해상도 보정 오프셋 (1920x1080에서 ~38px)
        offsets = {1: [0], 2: [-o, o], 3: [-o*2, 0, o*2], 4: [-o*3, -o, o, o*3]}
        for ox in offsets.get(count, [0]):
            bullet_group.add(GuidedBullet(x + ox, y, dmg, enemies_ref))


class ExplosiveWeapon(Weapon):
    def __init__(self): super().__init__('explosive')

    def fire(self, player, bullet_group, particles, enemies_ref, dmg_mult=1.0, judgment=None):
        dmg, _ = self.get_damage(player, dmg_mult)
        x, y   = player.rect.centerx, player.rect.top
        mult   = 1.5 if judgment=='PERFECT' else 1.0
        radius = int((60+(self.level-1)*20)*player.explosion_mult*mult)
        bullet_group.add(ExplosiveBullet(x, y, dmg, radius))


class OrbitWeapon(Weapon):
    def __init__(self):
        super().__init__('orbit')
        self.drones  = []
        self.boosted = False
        self._build(1)

    def _build(self, lv):
        count  = lv+1
        radius = sy(65 + lv*10)
        dmg    = WEAPON_DATA['orbit']['damage']+(lv-1)*5
        self.drones = [OrbitDrone(i, count, dmg, radius) for i in range(count)]

    def level_up(self):
        ok = super().level_up()
        if ok: self._build(self.level)
        return ok

    def update_drones(self, player, enemies, particles, game_kill_cb=None):
        px, py = player.rect.centerx, player.rect.centery
        for drone in self.drones:
            drone.update(px, py, self.boosted)
            for enemy in enemies:
                if enemy.alive():
                    dmg = drone.try_hit(enemy)
                    if dmg:
                        particles.add_damage(enemy.rect.centerx, enemy.rect.top, dmg)
                        if enemy.take_damage(dmg):
                            if game_kill_cb: game_kill_cb(enemy)
                            else: enemy.kill()
        self.boosted = False

    def draw_drones(self, surf, offset=(0,0)):
        for drone in self.drones:
            drone.draw(surf, offset)

    def fire(self, player, bullet_group, particles, enemies_ref, dmg_mult=1.0, judgment=None): pass
    def can_fire(self): return False


# -- Combo weapons --------------------------------------
class ClusterMissileWeapon(Weapon):
    def __init__(self): super().__init__('cluster_missile')

    def fire(self, player, bullet_group, particles, enemies_ref, dmg_mult=1.0, judgment=None):
        dmg, _ = self.get_damage(player, dmg_mult)
        x, y   = player.rect.centerx, player.rect.top
        count  = 3 if judgment=='PERFECT' else 2
        radius = int((80+(self.level-1)*25)*player.explosion_mult
                     *(1.5 if judgment=='PERFECT' else 1.0))
        offsets = {2:[-18,18], 3:[-28,0,28]}
        for ox in offsets.get(count, [0]):
            bullet_group.add(ClusterBullet(x+ox, y, dmg, radius, enemies_ref))


class SatelliteDroneWeapon(Weapon):
    def __init__(self):
        super().__init__('satellite_drone')
        self.drones  = []
        self.boosted = False
        self._build(1)

    def _build(self, lv):
        count  = lv+2
        radius = sy(80 + lv*12)
        dmg    = WEAPON_DATA['satellite_drone']['damage']+(lv-1)*6
        self.drones = [SatelliteDrone(i, count, dmg, radius) for i in range(count)]

    def level_up(self):
        ok = super().level_up()
        if ok: self._build(self.level)
        return ok

    def update_drones(self, player, enemies, particles, bullet_group, game_kill_cb=None):
        px, py = player.rect.centerx, player.rect.centery
        for drone in self.drones:
            drone.update(px, py, self.boosted)
            bullet = drone.try_shoot(enemies)
            if bullet: bullet_group.add(bullet)
            for enemy in enemies:
                if enemy.alive():
                    dmg = drone.try_hit(enemy)
                    if dmg:
                        particles.add_damage(enemy.rect.centerx, enemy.rect.top, dmg)
                        if enemy.take_damage(dmg):
                            if game_kill_cb: game_kill_cb(enemy)
                            else: enemy.kill()
        self.boosted = False

    def draw_drones(self, surf, offset=(0,0)):
        for drone in self.drones: drone.draw(surf, offset)

    def fire(self, player, bullet_group, particles, enemies_ref, dmg_mult=1.0, judgment=None):
        if judgment == 'PERFECT':
            for drone in self.drones: drone.shoot_timer = 0

    def can_fire(self): return False


class GrenadeShot(Weapon):
    def __init__(self): super().__init__('grenade_shot')

    def fire(self, player, bullet_group, particles, enemies_ref, dmg_mult=1.0, judgment=None):
        dmg, _ = self.get_damage(player, dmg_mult)
        x, y   = player.rect.centerx, player.rect.top
        count  = 5 if judgment=='PERFECT' else 3
        count += (self.level-1)
        if judgment == 'PERFECT':
            radius = int((130+(self.level-1)*25)*player.explosion_mult*1.5)
        elif judgment == 'GOOD':
            radius = int((130+(self.level-1)*25)*player.explosion_mult)
        else:
            radius = int(70*player.explosion_mult)
        spread = 45
        for i in range(count):
            a_deg = (-spread/2+spread/(count-1)*i) if count > 1 else 0
            a_rad = math.radians(a_deg-90)
            b = ExplosiveBullet(x, y, dmg, radius)
            b.vx = math.cos(a_rad)*4
            b.vy = math.sin(a_rad)*4
            bullet_group.add(b)


# -----------------------------------------------------
# Satellite Drone
# -----------------------------------------------------
class SatelliteDrone(OrbitDrone):
    SHOOT_INTERVAL = 60   # 기존 90f -> 60f (단독 활용도 향상)

    def __init__(self, index, total, damage, radius=80):
        super().__init__(index, total, damage, radius)
        self.shoot_timer = index*(self.SHOOT_INTERVAL//total)
        self.missile_dmg = damage*3

    def try_shoot(self, enemies_ref):
        self.shoot_timer -= 1
        if self.shoot_timer <= 0:
            self.shoot_timer = self.SHOOT_INTERVAL
            return GuidedBullet(int(self.x), int(self.y), self.missile_dmg, enemies_ref)
        return None

    def draw(self, surf, offset=(0,0)):
        ox, oy = offset
        cx, cy = int(self.x-ox), int(self.y-oy)
        pygame.draw.circle(surf, (100,255,180), (cx,cy), self.size+2)
        pygame.draw.circle(surf, WHITE,          (cx,cy), self.size-2)
        pygame.draw.line(surf, (100,255,180), (cx,cy), (cx,cy-self.size-4), 2)
        pygame.draw.circle(surf, YELLOW, (cx,cy-self.size-4), 3)


# -----------------------------------------------------
# Factory
# -----------------------------------------------------

# -----------------------------------------------------
# TorpedoBullet - 유도 펄스용 추적 어뢰
# -----------------------------------------------------
class TorpedoBullet(GuidedBullet):
    """GuidedBullet 파생 - Kla'ed 어뢰 스프라이트 + 빠른 속도"""
    def __init__(self, x, y, damage, enemies_ref):
        # GuidedBullet.__init__ 호출 없이 직접 초기화 - homing 이중 로드 방지
        pygame.sprite.Sprite.__init__(self)
        frames = _init_anim(self, 'torpedo_kla', anim_dur=4)
        if frames:
            self.image = frames[0].copy()
        else:
            W, H = sx(12), sy(28)
            self.image = pygame.Surface((W, H), pygame.SRCALPHA)
            pygame.draw.rect(self.image, (100, 180, 220), (0, 0, W, H), border_radius=3)
        self.rect        = self.image.get_rect(centerx=x, centery=y)
        self.damage      = damage
        self.enemies_ref = enemies_ref
        self.vx, self.vy = 0.0, -12.0
        self.speed       = 12.0
        self.turn        = 0.20
        self.piercing    = False
        self.hit_ids     = set()
        self.explosive_radius = 0


# -----------------------------------------------------
# WaveBullet - 펄스 버스트용 파동 투사체
# -----------------------------------------------------
class WaveBullet(pygame.sprite.Sprite):
    """Nautolan Wave 스프라이트 - 직선 이동 파동탄"""
    def __init__(self, x, y, vx, vy, damage):
        super().__init__()
        frames = _init_anim(self, 'wave_nau_p', anim_dur=3)
        if frames:
            self.image = frames[0].copy()
        else:
            w, h = sx(32), sy(28)
            self.image = pygame.Surface((w, h), pygame.SRCALPHA)
            pygame.draw.ellipse(self.image, (150, 255, 120, 200), (0, 0, w, h))
        self.rect   = self.image.get_rect(centerx=x, centery=y)
        self.vx, self.vy = float(vx), float(vy)
        self.damage = damage
        self.piercing        = False
        self.hit_ids         = set()
        self.explosive_radius = 0

    def update(self):
        _step_anim(self)
        self.rect.x += self.vx
        self.rect.y += self.vy
        if (self.rect.bottom < -10 or self.rect.top > HEIGHT + 10
                or self.rect.right < -10 or self.rect.left > WIDTH + 10):
            self.kill()


# -----------------------------------------------------
# PulseShot 조합 무기 3종
# -----------------------------------------------------
class GuidedPulseWeapon(Weapon):
    """PulseShot + Homing -> 유도 펄스 어뢰"""
    def __init__(self): super().__init__('guided_pulse')

    def fire(self, player, bullet_group, particles, enemies_ref, dmg_mult=1.0, judgment=None):
        dmg, _ = self.get_damage(player, dmg_mult)
        x, y   = player.rect.centerx, player.rect.top
        # 레벨에 따라 발사 수 증가, PERFECT 시 +2
        count   = self.level + (2 if judgment == 'PERFECT' else 0)
        offsets = {1:[0], 2:[-14,14], 3:[-22,0,22], 4:[-28,-9,9,28], 5:[-32,-16,0,16,32]}
        for ox in offsets.get(count, [0]):
            bullet_group.add(TorpedoBullet(x + ox, y, dmg, enemies_ref))


class PulseBurstWeapon(Weapon):
    """PulseShot + Spread -> 펄스 버스트 (파동 부채꼴)"""
    def __init__(self): super().__init__('pulse_burst')

    def fire(self, player, bullet_group, particles, enemies_ref, dmg_mult=1.0, judgment=None):
        dmg, _ = self.get_damage(player, dmg_mult)
        x, y   = player.rect.centerx, player.rect.top
        # PERFECT: 7발 / 일반: 4발, 레벨마다 +1
        base  = 7 if judgment == 'PERFECT' else 4
        count = base + (self.level - 1)
        spread = 70 if judgment == 'PERFECT' else 50
        spd    = 10
        for i in range(count):
            a_deg = (-spread/2 + spread/(count-1)*i) if count > 1 else 0
            a_rad = math.radians(a_deg - 90)
            vx = math.cos(a_rad) * spd
            vy = math.sin(a_rad) * spd
            bullet_group.add(WaveBullet(x, y, vx, vy, dmg))



# -----------------------------------------------------
# 기관포 (Auto Cannon)
# -----------------------------------------------------
class RocketBullet(pygame.sprite.Sprite):
    """무유도 로켓 투사체 - 폭발"""
    def __init__(self, x, y, vx, vy, damage, radius):
        super().__init__()
        # PROJ_SPECS에서 flip_v=True로 이미 방향(^) 보정됨
        frames = _init_anim(self, 'rocket_pod', anim_dur=4)
        if frames:
            self.image = frames[0].copy()
        else:
            w, h = sx(8), sy(18)
            self.image = pygame.Surface((w, h), pygame.SRCALPHA)
            pygame.draw.rect(self.image, (164, 132, 104), (0, 0, w, h), border_radius=3)
        self.rect             = self.image.get_rect(centerx=x, centery=y)
        self.vx, self.vy      = float(vx), float(vy)
        self.damage           = damage
        self.explosive_radius = radius
        self.piercing         = False
        self.hit_ids          = set()

    def update(self):
        _step_anim(self)
        self.rect.x += self.vx
        self.rect.y += self.vy
        if (self.rect.bottom < -10 or self.rect.top > HEIGHT + 10
                or self.rect.right < -10 or self.rect.left > WIDTH + 10):
            self.kill()


class RocketPodWeapon(Weapon):
    """무유도 로켓 포드 - 빠른 속도 + 소형 폭발"""
    def __init__(self): super().__init__('rocket_pod')

    def fire(self, player, bullet_group, particles, enemies_ref,
             dmg_mult=1.0, judgment=None):
        dmg, _ = self.get_damage(player, dmg_mult)
        x, y   = player.rect.centerx, player.rect.top
        # 폭발 반경 (레벨-player.explosion_mult 반영)
        radius = int((50 + (self.level-1)*15) * player.explosion_mult
                     * (1.4 if judgment == 'PERFECT' else 1.0))
        # 발사 수: 기본 2발, PERFECT 3발, 레벨마다 +1
        count   = (3 if judgment == 'PERFECT' else 2) + (self.level - 1)
        spread  = sx(16) * (self.level)
        offsets = {2: [-spread//2, spread//2],
                   3: [-spread, 0, spread],
                   4: [-spread*3//2, -spread//2, spread//2, spread*3//2]}
        for ox in offsets.get(count, [-spread//2, spread//2]):
            b = RocketBullet(x + ox, y, 0, -14, dmg, radius)
            bullet_group.add(b)

_WEAPON_CLS = {
    'pulse':           PulseWeapon,
    'spread':          SpreadWeapon,
    'homing':          HomingWeapon,
    'explosive':       ExplosiveWeapon,
    'orbit':           OrbitWeapon,
    'cluster_missile': ClusterMissileWeapon,
    'satellite_drone': SatelliteDroneWeapon,
    'grenade_shot':    GrenadeShot,
    # PulseShot 조합
    'guided_pulse':    GuidedPulseWeapon,
    'pulse_burst':     PulseBurstWeapon,
    # 신규 무기
    'rocket_pod':      RocketPodWeapon,
}

def create_weapon(wtype):
    return _WEAPON_CLS[wtype]()
